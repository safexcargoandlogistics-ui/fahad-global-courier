## Scope — 9 fixes across rate engine, booking, website, SEO and reports

### 1. Client Rate Master — show uploaded quotation
- Display current `quotation_url` (filename + open + delete + re-upload) in `ClientRateMaster.tsx`.
- Delete removes object from `rate-agreements` bucket and clears `quotation_url`.

### 2. Booking auto-pulls correct client rate
- In `Booking.tsx`, when client + service + destination changes, call `loadClientCard(client_id)` → `computeBilling(...)`.
- Fix service mapping: "Next Business Day" / "Standard Air" → `AIR` (currently mis-routes to OVERNIGHT). Only explicit "Overnight" maps to OVERNIGHT.
- Show breakdown (Freight, FOV, Insurance, ODA, Other, Total, Fuel%, Fuel, SubTotal, GST%, GST, Grand Total) with every field **editable** (manual override stored on shipment).

### 3. Worldwide cities & pincodes for Origin/Destination
- Add `src/data/worldCities.ts` (curated ~5k major cities w/ country) and reuse `COUNTRIES`.
- In Booking + Pincodes + Client Rate Master destination pickers, replace plain inputs with searchable Combobox (city → autofills state/country, pincode free entry).

### 4. Public website rates admin
- New tab in `ClientRateMaster.tsx` → "Public Website Rates" stored in `site_content` key `public_rates` (add/edit/delete city + per-kg + service).
- New public page `/rates` rendering the table from `site_content.public_rates`. Add link in Index header.

### 5. SEO + Google indexing fixes
- Add `react-helmet-async` per-route titles/descriptions/canonicals for `/`, `/track`, `/pincode-check`, `/rates`.
- Update `sitemap.xml` with `/rates` + lastmod.
- Ensure `index.html` canonical = `https://www.fahadglobal.com/` (already).
- Trigger Google Search Console site-verification flow for `https://www.fahadglobal.com/` (meta tag injected via Helmet in `Index.tsx`).

### 6. Public website — header company name uppercase + banner display
- `Index.tsx` header: render brand as `FAHAD GLOBAL LOGISTICS` (uppercase, tracking-wide).
- Fix banner image render: read `site_content.hero.banner_url`, render `<img>` with proper fallback; currently markup hides when url present but uses wrong key.

### 7. Reports — client-wise + status-wise pending/delivered
- Extend `MIS.tsx` with two filters (Client dropdown, Status dropdown) and grouped totals (Booked / In-Transit / OFD / Delivered / Pending / Undelivered).
- Export CSV.

### 8. DRS auto-print off
- In `DRS.tsx`, remove the `window.print()` call that fires on save; add explicit "Print DRS" button only.

### 9. Discoverability / first-time Google search
- Submit sitemap to Search Console via connector after verification.
- Add Organization + WebSite + BreadcrumbList JSON-LD with `sameAs` (FB/IG/LinkedIn placeholders editable from CMS).
- Add hreflang `en-IN`, og:image fallback already set.

### Files
- Edit: `ClientRateMaster.tsx`, `Booking.tsx`, `Pincodes.tsx`, `Index.tsx`, `MIS.tsx`, `DRS.tsx`, `useSiteContent.ts`, `App.tsx`, `main.tsx`, `index.html`, `public/sitemap.xml`, `src/lib/clientRates.ts`.
- Add: `src/data/worldCities.ts`, `src/pages/PublicRates.tsx`, helmet wiring.
- Migration: none (uses existing `site_content` + `client_rate_master`).

Confirm and I'll build it.