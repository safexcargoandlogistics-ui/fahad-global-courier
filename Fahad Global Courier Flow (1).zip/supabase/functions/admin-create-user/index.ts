import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const authHeader = req.headers.get("Authorization") ?? "";

    const userClient = createClient(url, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });

    const admin = createClient(url, serviceKey);
    const { data: roleRow } = await admin.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle();
    if (!roleRow) return new Response(JSON.stringify({ error: "Admin only" }), { status: 403, headers: { ...cors, "Content-Type": "application/json" } });

    const body = await req.json();
    const { action, email, password, full_name, phone, role, branch_id, target_user_id } = body;

    if (action === "create") {
      const { data: created, error } = await admin.auth.admin.createUser({
        email, password, email_confirm: true,
        user_metadata: { full_name, phone },
      });
      if (error) throw error;
      const uid = created.user!.id;
      await admin.from("profiles").upsert({ id: uid, full_name, phone, branch_id: branch_id || null });
      // remove default 'client' role inserted by trigger if a different role was requested
      if (role && role !== "client") {
        await admin.from("user_roles").delete().eq("user_id", uid);
        await admin.from("user_roles").insert({ user_id: uid, role });
      }
      return new Response(JSON.stringify({ ok: true, user_id: uid }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    if (action === "delete") {
      const { error } = await admin.auth.admin.deleteUser(target_user_id);
      if (error) throw error;
      return new Response(JSON.stringify({ ok: true }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    if (action === "update") {
      if (password) {
        const { error } = await admin.auth.admin.updateUserById(target_user_id, { password });
        if (error) throw error;
      }
      await admin.from("profiles").update({ full_name, phone, branch_id: branch_id || null }).eq("id", target_user_id);
      if (role) {
        await admin.from("user_roles").delete().eq("user_id", target_user_id);
        await admin.from("user_roles").insert({ user_id: target_user_id, role });
      }
      return new Response(JSON.stringify({ ok: true }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Unknown action" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e.message ?? String(e) }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
  }
});