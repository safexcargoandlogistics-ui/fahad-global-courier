import { template as pickupAssigned } from './pickup-assigned.tsx'
import { template as pickupReceived } from './pickup-received.tsx'

export type TemplateEntry = {
  component: any
  subject: string | ((data: any) => string)
  displayName?: string
  previewData?: any
  to?: string | ((data: any) => string)
}

export const TEMPLATES: Record<string, TemplateEntry> = {
  'pickup-assigned': pickupAssigned,
  'pickup-received': pickupReceived,
}