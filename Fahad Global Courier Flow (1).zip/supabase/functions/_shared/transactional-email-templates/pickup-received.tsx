import * as React from 'npm:react@18.3.1'
import { Html, Body, Container, Heading, Text, Section, Hr } from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  customerName?: string
  phone?: string
  email?: string
  pickupDate?: string
  pickupTime?: string
  pickupAddress?: string
  city?: string
  pincode?: string
  pieces?: number
  weight?: number
  remarks?: string
}

const PickupReceived = (p: Props) => (
  <Html>
    <Body style={{ backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }}>
      <Container style={{ maxWidth: 600, margin: '0 auto', padding: 24 }}>
        <Section style={{ background: '#0B1E5B', color: '#fff', padding: 16, borderRadius: 8 }}>
          <Heading style={{ color: '#D4AF37', margin: 0, fontSize: 20 }}>New Pickup Request</Heading>
        </Section>
        <Section style={{ background: '#f6f6f8', padding: 14, borderRadius: 6, marginTop: 14 }}>
          <Text style={{ margin: 0 }}><b>Name:</b> {p.customerName}</Text>
          <Text style={{ margin: 0 }}><b>Phone:</b> {p.phone}</Text>
          {p.email && <Text style={{ margin: 0 }}><b>Email:</b> {p.email}</Text>}
          <Text style={{ margin: 0 }}><b>Date / Time:</b> {p.pickupDate} {p.pickupTime || ''}</Text>
          <Text style={{ margin: 0 }}><b>Address:</b> {p.pickupAddress}</Text>
          <Text style={{ margin: 0 }}><b>City / Pincode:</b> {p.city} {p.pincode}</Text>
          <Text style={{ margin: 0 }}><b>Pieces / Approx Wt:</b> {p.pieces} · {p.weight} kg</Text>
          {p.remarks && <Text style={{ margin: 0 }}><b>Remarks:</b> {p.remarks}</Text>}
        </Section>
        <Hr />
        <Text style={{ fontSize: 12, color: '#666' }}>Login to admin → Pickup Requests to assign branch & rider.</Text>
      </Container>
    </Body>
  </Html>
)

export const template: TemplateEntry = {
  component: PickupReceived,
  displayName: 'New Pickup Received (Admin)',
  subject: (d: Props) => `New pickup request from ${d.customerName || 'customer'}`,
  previewData: { customerName: 'Ravi', phone: '9999999999', email: 'r@x.com', pickupDate: '24 May 2026', pickupTime: '10:00-12:00', pickupAddress: 'A-1, Khora', city: 'Ghaziabad', pincode: '201020', pieces: 2, weight: 5 },
}