import * as React from 'npm:react@18.3.1'
import { Html, Body, Container, Heading, Text, Section, Hr } from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  customerName?: string
  pickupDate?: string
  pickupAddress?: string
  rider?: string
  branch?: string
  status?: string
}

const PickupAssigned = (p: Props) => (
  <Html>
    <Body style={{ backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }}>
      <Container style={{ maxWidth: 560, margin: '0 auto', padding: 24 }}>
        <Section style={{ background: '#0B1E5B', color: '#fff', padding: 18, borderRadius: 8, textAlign: 'center' }}>
          <Heading style={{ color: '#D4AF37', margin: 0, fontSize: 22 }}>FAHAD GLOBAL LOGISTICS</Heading>
          <Text style={{ color: '#fff', margin: '4px 0 0', fontSize: 12 }}>Pickup Update</Text>
        </Section>
        <Heading style={{ fontSize: 18, marginTop: 24 }}>Hi {p.customerName || 'Customer'},</Heading>
        <Text>Your pickup request has been <b>{p.status || 'assigned'}</b>.</Text>
        <Section style={{ background: '#f6f6f8', padding: 14, borderRadius: 6, marginTop: 12 }}>
          <Text style={{ margin: 0 }}><b>Pickup Date:</b> {p.pickupDate}</Text>
          <Text style={{ margin: 0 }}><b>Address:</b> {p.pickupAddress}</Text>
          {p.branch && <Text style={{ margin: 0 }}><b>Branch:</b> {p.branch}</Text>}
          {p.rider && <Text style={{ margin: 0 }}><b>Rider:</b> {p.rider}</Text>}
        </Section>
        <Text style={{ marginTop: 16 }}>Our rider will reach your address as scheduled. You may track all updates on our website.</Text>
        <Hr />
        <Text style={{ fontSize: 12, color: '#666' }}>info@fahadglobal.com · www.fahadglobal.com</Text>
      </Container>
    </Body>
  </Html>
)

export const template: TemplateEntry = {
  component: PickupAssigned,
  displayName: 'Pickup Assigned',
  subject: (d: Props) => `Pickup ${d.status || 'assigned'} — FAHAD GLOBAL LOGISTICS`,
  previewData: { customerName: 'Ravi', pickupDate: '24 May 2026', pickupAddress: 'Khora Colony, Ghaziabad', rider: 'Aman', branch: 'Delhi Okhla', status: 'assigned' },
}