
-- ========== ROLES ==========
CREATE TYPE public.app_role AS ENUM ('admin', 'staff', 'client');
CREATE TYPE public.shipment_status AS ENUM ('booked','manifested','in_transit','out_for_delivery','delivered','undelivered','rto','cancelled');
CREATE TYPE public.shipment_mode AS ENUM ('domestic','international');
CREATE TYPE public.manifest_type AS ENUM ('outgoing','incoming');
CREATE TYPE public.payment_mode AS ENUM ('prepaid','topay','cod','credit');

-- ========== PROFILES ==========
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  client_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ========== USER ROLES ==========
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role=_role)
$$;

CREATE OR REPLACE FUNCTION public.is_staff_or_admin(_user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role IN ('admin','staff'))
$$;

-- Auto profile + default client role on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'phone');
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'client');
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ========== CLIENTS ==========
CREATE TABLE public.clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  contact_person TEXT,
  email TEXT,
  phone TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  pincode TEXT,
  gstin TEXT,
  credit_limit NUMERIC(12,2) DEFAULT 0,
  opening_balance NUMERIC(12,2) DEFAULT 0,
  user_id UUID REFERENCES auth.users ON DELETE SET NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

-- ========== RATE CARDS ==========
CREATE TABLE public.rate_cards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID REFERENCES public.clients ON DELETE CASCADE,
  mode public.shipment_mode NOT NULL DEFAULT 'domestic',
  zone TEXT NOT NULL,
  weight_from NUMERIC(8,3) NOT NULL DEFAULT 0,
  weight_to NUMERIC(8,3) NOT NULL DEFAULT 0.5,
  base_rate NUMERIC(10,2) NOT NULL DEFAULT 0,
  per_kg_rate NUMERIC(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.rate_cards ENABLE ROW LEVEL SECURITY;

-- ========== AWB sequence ==========
CREATE SEQUENCE public.awb_seq START 1;
CREATE OR REPLACE FUNCTION public.next_awb()
RETURNS TEXT LANGUAGE SQL VOLATILE AS $$
  SELECT 'FGL' || LPAD(nextval('public.awb_seq')::TEXT, 6, '0');
$$;

-- ========== SHIPMENTS ==========
CREATE TABLE public.shipments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  awb_number TEXT UNIQUE NOT NULL DEFAULT public.next_awb(),
  reference_no TEXT,
  booking_date DATE NOT NULL DEFAULT CURRENT_DATE,
  client_id UUID REFERENCES public.clients ON DELETE SET NULL,
  mode public.shipment_mode NOT NULL DEFAULT 'domestic',
  service_type TEXT,
  payment_mode public.payment_mode NOT NULL DEFAULT 'prepaid',
  -- sender
  sender_name TEXT NOT NULL,
  sender_phone TEXT,
  sender_address TEXT,
  sender_city TEXT,
  sender_pincode TEXT,
  -- receiver
  receiver_name TEXT NOT NULL,
  receiver_phone TEXT,
  receiver_address TEXT,
  receiver_city TEXT NOT NULL,
  receiver_state TEXT,
  receiver_pincode TEXT NOT NULL,
  receiver_country TEXT DEFAULT 'India',
  -- parcel
  pieces INT NOT NULL DEFAULT 1,
  actual_weight NUMERIC(8,3) NOT NULL DEFAULT 0,
  volumetric_weight NUMERIC(8,3) DEFAULT 0,
  chargeable_weight NUMERIC(8,3) NOT NULL DEFAULT 0,
  contents TEXT,
  declared_value NUMERIC(10,2) DEFAULT 0,
  -- charges
  freight NUMERIC(10,2) DEFAULT 0,
  fuel_charge NUMERIC(10,2) DEFAULT 0,
  other_charges NUMERIC(10,2) DEFAULT 0,
  gst NUMERIC(10,2) DEFAULT 0,
  total_amount NUMERIC(10,2) DEFAULT 0,
  cod_amount NUMERIC(10,2) DEFAULT 0,
  status public.shipment_status NOT NULL DEFAULT 'booked',
  remarks TEXT,
  created_by UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.shipments ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_shipments_client ON public.shipments(client_id);
CREATE INDEX idx_shipments_status ON public.shipments(status);
CREATE INDEX idx_shipments_date ON public.shipments(booking_date);

-- ========== MANIFESTS ==========
CREATE TABLE public.manifests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  manifest_no TEXT UNIQUE NOT NULL,
  manifest_type public.manifest_type NOT NULL,
  manifest_date DATE NOT NULL DEFAULT CURRENT_DATE,
  origin TEXT,
  destination TEXT,
  vehicle_no TEXT,
  driver_name TEXT,
  driver_phone TEXT,
  remarks TEXT,
  total_pieces INT DEFAULT 0,
  total_weight NUMERIC(10,3) DEFAULT 0,
  created_by UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.manifests ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.manifest_shipments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  manifest_id UUID NOT NULL REFERENCES public.manifests ON DELETE CASCADE,
  shipment_id UUID NOT NULL REFERENCES public.shipments ON DELETE CASCADE,
  UNIQUE(manifest_id, shipment_id)
);
ALTER TABLE public.manifest_shipments ENABLE ROW LEVEL SECURITY;

-- ========== DRS ==========
CREATE TABLE public.drs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  drs_no TEXT UNIQUE NOT NULL,
  drs_date DATE NOT NULL DEFAULT CURRENT_DATE,
  delivery_boy TEXT NOT NULL,
  delivery_boy_phone TEXT,
  area TEXT,
  remarks TEXT,
  total_pieces INT DEFAULT 0,
  created_by UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.drs ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.drs_shipments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  drs_id UUID NOT NULL REFERENCES public.drs ON DELETE CASCADE,
  shipment_id UUID NOT NULL REFERENCES public.shipments ON DELETE CASCADE,
  UNIQUE(drs_id, shipment_id)
);
ALTER TABLE public.drs_shipments ENABLE ROW LEVEL SECURITY;

-- ========== TRACKING ==========
CREATE TABLE public.tracking_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id UUID NOT NULL REFERENCES public.shipments ON DELETE CASCADE,
  status public.shipment_status NOT NULL,
  location TEXT,
  remarks TEXT,
  receiver_name TEXT,
  event_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users
);
ALTER TABLE public.tracking_events ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_tracking_shipment ON public.tracking_events(shipment_id);

-- ========== INVOICES ==========
CREATE TABLE public.invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_no TEXT UNIQUE NOT NULL,
  invoice_date DATE NOT NULL DEFAULT CURRENT_DATE,
  client_id UUID NOT NULL REFERENCES public.clients ON DELETE RESTRICT,
  period_from DATE,
  period_to DATE,
  subtotal NUMERIC(12,2) DEFAULT 0,
  gst NUMERIC(12,2) DEFAULT 0,
  total NUMERIC(12,2) DEFAULT 0,
  paid NUMERIC(12,2) DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'unpaid',
  notes TEXT,
  created_by UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.invoice_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id UUID NOT NULL REFERENCES public.invoices ON DELETE CASCADE,
  shipment_id UUID REFERENCES public.shipments ON DELETE SET NULL,
  description TEXT,
  amount NUMERIC(10,2) NOT NULL DEFAULT 0
);
ALTER TABLE public.invoice_items ENABLE ROW LEVEL SECURITY;

-- ========== LEDGER ==========
CREATE TABLE public.ledger_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES public.clients ON DELETE CASCADE,
  entry_date DATE NOT NULL DEFAULT CURRENT_DATE,
  description TEXT NOT NULL,
  reference TEXT,
  debit NUMERIC(12,2) DEFAULT 0,
  credit NUMERIC(12,2) DEFAULT 0,
  created_by UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.ledger_entries ENABLE ROW LEVEL SECURITY;

-- ========== RLS POLICIES ==========
-- profiles
CREATE POLICY "own profile read" ON public.profiles FOR SELECT USING (auth.uid()=id OR public.is_staff_or_admin(auth.uid()));
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE USING (auth.uid()=id);
CREATE POLICY "admin manage profiles" ON public.profiles FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- user_roles
CREATE POLICY "view own roles" ON public.user_roles FOR SELECT USING (auth.uid()=user_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin manage roles" ON public.user_roles FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- clients
CREATE POLICY "staff read clients" ON public.clients FOR SELECT USING (public.is_staff_or_admin(auth.uid()) OR user_id=auth.uid());
CREATE POLICY "staff write clients" ON public.clients FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));

-- rate_cards
CREATE POLICY "staff manage rates" ON public.rate_cards FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "client view own rates" ON public.rate_cards FOR SELECT USING (
  EXISTS(SELECT 1 FROM public.clients c WHERE c.id=client_id AND c.user_id=auth.uid())
);

-- shipments
CREATE POLICY "staff manage shipments" ON public.shipments FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "client view own shipments" ON public.shipments FOR SELECT USING (
  EXISTS(SELECT 1 FROM public.clients c WHERE c.id=client_id AND c.user_id=auth.uid())
);

-- manifests
CREATE POLICY "staff manage manifests" ON public.manifests FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "staff manage manifest_shipments" ON public.manifest_shipments FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));

-- drs
CREATE POLICY "staff manage drs" ON public.drs FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "staff manage drs_shipments" ON public.drs_shipments FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));

-- tracking — public read for tracking page
CREATE POLICY "public read tracking" ON public.tracking_events FOR SELECT USING (true);
CREATE POLICY "staff write tracking" ON public.tracking_events FOR INSERT WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "staff update tracking" ON public.tracking_events FOR UPDATE USING (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "staff delete tracking" ON public.tracking_events FOR DELETE USING (public.is_staff_or_admin(auth.uid()));

-- invoices
CREATE POLICY "staff manage invoices" ON public.invoices FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "client view own invoices" ON public.invoices FOR SELECT USING (
  EXISTS(SELECT 1 FROM public.clients c WHERE c.id=client_id AND c.user_id=auth.uid())
);
CREATE POLICY "staff manage invoice_items" ON public.invoice_items FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "client view own invoice items" ON public.invoice_items FOR SELECT USING (
  EXISTS(SELECT 1 FROM public.invoices i JOIN public.clients c ON c.id=i.client_id WHERE i.id=invoice_id AND c.user_id=auth.uid())
);

-- ledger
CREATE POLICY "staff manage ledger" ON public.ledger_entries FOR ALL USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "client view own ledger" ON public.ledger_entries FOR SELECT USING (
  EXISTS(SELECT 1 FROM public.clients c WHERE c.id=client_id AND c.user_id=auth.uid())
);

-- updated_at triggers
CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER trg_clients_updated BEFORE UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_shipments_updated BEFORE UPDATE ON public.shipments FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
