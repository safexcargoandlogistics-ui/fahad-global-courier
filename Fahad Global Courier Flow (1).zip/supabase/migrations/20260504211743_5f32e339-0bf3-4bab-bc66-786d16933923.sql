-- Add dimensions, POD, bill booking, transport mode to shipments
ALTER TABLE public.shipments
  ADD COLUMN IF NOT EXISTS length_cm numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS width_cm numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS height_cm numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS volumetric_divisor numeric DEFAULT 5000,
  ADD COLUMN IF NOT EXISTS transport_mode text DEFAULT 'Air',
  ADD COLUMN IF NOT EXISTS bill_booking boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS pod_url text,
  ADD COLUMN IF NOT EXISTS pod_received_by text,
  ADD COLUMN IF NOT EXISTS pod_at timestamptz,
  ADD COLUMN IF NOT EXISTS delivered_at timestamptz;

-- POD storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('pods','pods', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "pod public read" ON storage.objects FOR SELECT USING (bucket_id='pods');
CREATE POLICY "pod staff write" ON storage.objects FOR INSERT WITH CHECK (bucket_id='pods' AND public.is_staff_or_admin(auth.uid()));
CREATE POLICY "pod staff update" ON storage.objects FOR UPDATE USING (bucket_id='pods' AND public.is_staff_or_admin(auth.uid()));
CREATE POLICY "pod staff delete" ON storage.objects FOR DELETE USING (bucket_id='pods' AND public.is_staff_or_admin(auth.uid()));

-- Auto-promote the company email to admin on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'phone');
  IF lower(NEW.email) = 'info@fahadglobal.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'client');
  END IF;
  RETURN NEW;
END; $$;

-- Ensure trigger exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- If admin email already exists, promote it now
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role FROM auth.users WHERE lower(email)='info@fahadglobal.com'
ON CONFLICT DO NOTHING;