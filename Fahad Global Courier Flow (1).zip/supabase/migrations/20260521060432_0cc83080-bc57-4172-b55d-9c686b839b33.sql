ALTER TABLE public.branches
  ADD COLUMN IF NOT EXISTS pincode text;

ALTER TABLE public.public_tracking_shipments
  ADD COLUMN IF NOT EXISTS length_cm numeric,
  ADD COLUMN IF NOT EXISTS width_cm numeric,
  ADD COLUMN IF NOT EXISTS height_cm numeric,
  ADD COLUMN IF NOT EXISTS volumetric_weight numeric,
  ADD COLUMN IF NOT EXISTS volumetric_divisor numeric;

CREATE OR REPLACE FUNCTION public.sync_public_tracking_shipment()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  cur_city text; cur_name text; dest_city text;
BEGIN
  SELECT city, name INTO cur_city, cur_name FROM public.branches WHERE id = NEW.current_branch_id;
  SELECT city INTO dest_city FROM public.branches WHERE id = NEW.destination_branch_id;
  INSERT INTO public.public_tracking_shipments (
    shipment_id, awb_number, booking_date, status, sender_name, sender_city, sender_pincode,
    receiver_name, receiver_city, receiver_state, receiver_pincode, receiver_country,
    pieces, chargeable_weight, length_cm, width_cm, height_cm, volumetric_weight, volumetric_divisor,
    transport_mode, service_type, pod_url, pod_received_by,
    pod_at, delivered_at, current_branch_city, current_branch_name, destination_branch_city, updated_at
  ) VALUES (
    NEW.id, NEW.awb_number, NEW.booking_date, NEW.status::text, NEW.sender_name, NEW.sender_city, NEW.sender_pincode,
    NEW.receiver_name, NEW.receiver_city, NEW.receiver_state, NEW.receiver_pincode, NEW.receiver_country,
    NEW.pieces, NEW.chargeable_weight, NEW.length_cm, NEW.width_cm, NEW.height_cm, NEW.volumetric_weight, NEW.volumetric_divisor,
    NEW.transport_mode, NEW.service_type, NEW.pod_url, NEW.pod_received_by,
    NEW.pod_at, NEW.delivered_at, cur_city, cur_name, dest_city, now()
  )
  ON CONFLICT (shipment_id) DO UPDATE SET
    awb_number = EXCLUDED.awb_number, booking_date = EXCLUDED.booking_date, status = EXCLUDED.status,
    sender_name = EXCLUDED.sender_name, sender_city = EXCLUDED.sender_city, sender_pincode = EXCLUDED.sender_pincode,
    receiver_name = EXCLUDED.receiver_name, receiver_city = EXCLUDED.receiver_city,
    receiver_state = EXCLUDED.receiver_state, receiver_pincode = EXCLUDED.receiver_pincode,
    receiver_country = EXCLUDED.receiver_country, pieces = EXCLUDED.pieces,
    chargeable_weight = EXCLUDED.chargeable_weight,
    length_cm = EXCLUDED.length_cm,
    width_cm = EXCLUDED.width_cm,
    height_cm = EXCLUDED.height_cm,
    volumetric_weight = EXCLUDED.volumetric_weight,
    volumetric_divisor = EXCLUDED.volumetric_divisor,
    transport_mode = EXCLUDED.transport_mode, service_type = EXCLUDED.service_type,
    pod_url = EXCLUDED.pod_url, pod_received_by = EXCLUDED.pod_received_by,
    pod_at = EXCLUDED.pod_at, delivered_at = EXCLUDED.delivered_at,
    current_branch_city = EXCLUDED.current_branch_city, current_branch_name = EXCLUDED.current_branch_name,
    destination_branch_city = EXCLUDED.destination_branch_city, updated_at = now();
  RETURN NEW;
END;
$function$;

UPDATE public.public_tracking_shipments p
SET chargeable_weight = s.chargeable_weight,
    length_cm = s.length_cm,
    width_cm = s.width_cm,
    height_cm = s.height_cm,
    volumetric_weight = s.volumetric_weight,
    volumetric_divisor = s.volumetric_divisor
FROM public.shipments s
WHERE p.shipment_id = s.id;

INSERT INTO public.site_content (key, value, updated_at)
VALUES ('seo_settings', jsonb_build_object(
  'google_site_verification', '',
  'same_as', 'https://www.instagram.com/fahad_global_logistics?utm_source=qr&igsh=ZWkyYmUxNmh4bWQx'
), now())
ON CONFLICT (key) DO UPDATE SET
  value = jsonb_set(
    COALESCE(public.site_content.value, '{}'::jsonb),
    '{same_as}',
    to_jsonb(
      CASE
        WHEN COALESCE(public.site_content.value->>'same_as', '') ILIKE '%instagram.com/fahad_global_logistics%' THEN public.site_content.value->>'same_as'
        WHEN COALESCE(public.site_content.value->>'same_as', '') = '' THEN 'https://www.instagram.com/fahad_global_logistics?utm_source=qr&igsh=ZWkyYmUxNmh4bWQx'
        ELSE (public.site_content.value->>'same_as') || E'\nhttps://www.instagram.com/fahad_global_logistics?utm_source=qr&igsh=ZWkyYmUxNmh4bWQx'
      END
    )
  ),
  updated_at = now();