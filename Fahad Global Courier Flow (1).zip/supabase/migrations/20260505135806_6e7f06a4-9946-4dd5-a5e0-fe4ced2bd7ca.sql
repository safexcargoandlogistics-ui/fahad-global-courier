
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.is_staff_or_admin(uuid) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.user_branch_id(uuid) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.can_access_branch_record(uuid, uuid[]) TO authenticated, anon;
