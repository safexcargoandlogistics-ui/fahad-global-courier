-- Branches: contact fields + public read of active branches
ALTER TABLE public.branches
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS contact_person text;

DROP POLICY IF EXISTS "public read active branches" ON public.branches;
CREATE POLICY "public read active branches" ON public.branches
  FOR SELECT USING (active = true);

-- Shipments: invoice no, eway bill, distance
ALTER TABLE public.shipments
  ADD COLUMN IF NOT EXISTS invoice_no text,
  ADD COLUMN IF NOT EXISTS eway_bill_no text,
  ADD COLUMN IF NOT EXISTS eway_bill_data jsonb,
  ADD COLUMN IF NOT EXISTS distance_km numeric;

-- Public tracking: pincodes
ALTER TABLE public.public_tracking_shipments
  ADD COLUMN IF NOT EXISTS sender_pincode text,
  ADD COLUMN IF NOT EXISTS receiver_pincode text;

-- Refresh sync function to include sender_pincode
CREATE OR REPLACE FUNCTION public.sync_public_tracking_shipment()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  cur_city text; cur_name text; dest_city text;
BEGIN
  SELECT city, name INTO cur_city, cur_name FROM public.branches WHERE id = NEW.current_branch_id;
  SELECT city INTO dest_city FROM public.branches WHERE id = NEW.destination_branch_id;
  INSERT INTO public.public_tracking_shipments (
    shipment_id, awb_number, booking_date, status, sender_name, sender_city, sender_pincode,
    receiver_name, receiver_city, receiver_state, receiver_pincode, receiver_country,
    pieces, transport_mode, service_type, pod_url, pod_received_by,
    pod_at, delivered_at, current_branch_city, current_branch_name, destination_branch_city, updated_at
  ) VALUES (
    NEW.id, NEW.awb_number, NEW.booking_date, NEW.status::text, NEW.sender_name, NEW.sender_city, NEW.sender_pincode,
    NEW.receiver_name, NEW.receiver_city, NEW.receiver_state, NEW.receiver_pincode, NEW.receiver_country,
    NEW.pieces, NEW.transport_mode, NEW.service_type, NEW.pod_url, NEW.pod_received_by,
    NEW.pod_at, NEW.delivered_at, cur_city, cur_name, dest_city, now()
  )
  ON CONFLICT (shipment_id) DO UPDATE SET
    awb_number = EXCLUDED.awb_number, booking_date = EXCLUDED.booking_date, status = EXCLUDED.status,
    sender_name = EXCLUDED.sender_name, sender_city = EXCLUDED.sender_city, sender_pincode = EXCLUDED.sender_pincode,
    receiver_name = EXCLUDED.receiver_name, receiver_city = EXCLUDED.receiver_city,
    receiver_state = EXCLUDED.receiver_state, receiver_pincode = EXCLUDED.receiver_pincode,
    receiver_country = EXCLUDED.receiver_country, pieces = EXCLUDED.pieces,
    transport_mode = EXCLUDED.transport_mode, service_type = EXCLUDED.service_type,
    pod_url = EXCLUDED.pod_url, pod_received_by = EXCLUDED.pod_received_by,
    pod_at = EXCLUDED.pod_at, delivered_at = EXCLUDED.delivered_at,
    current_branch_city = EXCLUDED.current_branch_city, current_branch_name = EXCLUDED.current_branch_name,
    destination_branch_city = EXCLUDED.destination_branch_city, updated_at = now();
  RETURN NEW;
END;
$function$;

-- Backfill pincodes for existing tracking rows
UPDATE public.public_tracking_shipments p
SET sender_pincode = s.sender_pincode, receiver_pincode = s.receiver_pincode
FROM public.shipments s WHERE p.shipment_id = s.id;