
-- 1. Fix RLS: allow ALL staff/admin/manager to update shipments (any branch)
DROP POLICY IF EXISTS "staff update shipments any branch" ON public.shipments;
CREATE POLICY "staff update shipments any branch"
ON public.shipments FOR UPDATE
USING (public.is_staff_or_admin(auth.uid()))
WITH CHECK (public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff insert tracking" ON public.tracking_events;
-- already covered

-- 2. Trash for soft-delete recovery
CREATE TABLE IF NOT EXISTS public.shipments_trash (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_id uuid NOT NULL,
  awb_number text NOT NULL,
  shipment_data jsonb NOT NULL,
  tracking_data jsonb,
  manifest_links jsonb,
  drs_links jsonb,
  deleted_by uuid,
  deleted_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.shipments_trash ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "admin manage trash" ON public.shipments_trash;
CREATE POLICY "admin manage trash" ON public.shipments_trash FOR ALL
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

-- 3. AWB uniqueness (only enforce on active shipments — trash holds copies)
CREATE UNIQUE INDEX IF NOT EXISTS shipments_awb_unique ON public.shipments (awb_number);

-- 4. Helper: restore from trash (admin only)
CREATE OR REPLACE FUNCTION public.restore_shipment(_trash_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  t public.shipments_trash;
  new_id uuid;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::app_role) THEN
    RAISE EXCEPTION 'Only admin can restore';
  END IF;
  SELECT * INTO t FROM public.shipments_trash WHERE id = _trash_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Trash entry not found'; END IF;

  -- If AWB still exists in shipments, fail with hint
  IF EXISTS (SELECT 1 FROM public.shipments WHERE awb_number = t.awb_number) THEN
    RAISE EXCEPTION 'A shipment with AWB % already exists; delete it first or rename trashed AWB', t.awb_number;
  END IF;

  INSERT INTO public.shipments SELECT * FROM jsonb_populate_record(NULL::public.shipments, t.shipment_data) RETURNING id INTO new_id;

  IF t.tracking_data IS NOT NULL THEN
    INSERT INTO public.tracking_events
      SELECT * FROM jsonb_populate_recordset(NULL::public.tracking_events,
        (SELECT jsonb_agg(jsonb_set(e, '{shipment_id}', to_jsonb(new_id::text)))
         FROM jsonb_array_elements(t.tracking_data) e));
  END IF;

  DELETE FROM public.shipments_trash WHERE id = _trash_id;
  RETURN new_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.restore_shipment(uuid) TO authenticated;
