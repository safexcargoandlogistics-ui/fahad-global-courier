GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff_or_admin(uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.next_awb() TO anon, authenticated;

CREATE SEQUENCE IF NOT EXISTS public.client_code_seq START 1;

CREATE OR REPLACE FUNCTION public.next_client_code()
RETURNS text
LANGUAGE sql
VOLATILE
SET search_path TO 'public'
AS $$
  SELECT 'FGLC' || LPAD(nextval('public.client_code_seq')::text, 5, '0');
$$;

GRANT EXECUTE ON FUNCTION public.next_client_code() TO authenticated;

ALTER TABLE public.clients
ALTER COLUMN client_code SET DEFAULT public.next_client_code();