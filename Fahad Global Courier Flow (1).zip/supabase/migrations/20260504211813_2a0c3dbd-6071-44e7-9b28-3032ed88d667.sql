DROP POLICY IF EXISTS "pod public read" ON storage.objects;
-- Allow direct object reads via known path; staff can list/manage
CREATE POLICY "pod read by name" ON storage.objects
  FOR SELECT USING (bucket_id='pods' AND (public.is_staff_or_admin(auth.uid()) OR auth.role() = 'anon' OR auth.role() = 'authenticated'));