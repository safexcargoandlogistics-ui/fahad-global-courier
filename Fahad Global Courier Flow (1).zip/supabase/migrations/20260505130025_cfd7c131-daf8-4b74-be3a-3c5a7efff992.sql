CREATE OR REPLACE FUNCTION public.can_access_branch_record(_user_id uuid, VARIADIC _branch_ids uuid[])
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT public.has_role(_user_id, 'admin'::app_role)
    OR (
      public.has_role(_user_id, 'staff'::app_role)
      AND (
        public.user_branch_id(_user_id) IS NULL
        OR EXISTS (
          SELECT 1 FROM unnest(_branch_ids) AS b(id)
          WHERE b.id IS NULL OR b.id = public.user_branch_id(_user_id)
        )
      )
    )
$$;

REVOKE EXECUTE ON FUNCTION public.can_access_branch_record(uuid, uuid[]) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.can_access_branch_record(uuid, uuid[]) FROM anon;
REVOKE EXECUTE ON FUNCTION public.can_access_branch_record(uuid, uuid[]) FROM authenticated;

DROP POLICY IF EXISTS "staff manage shipments" ON public.shipments;
DROP POLICY IF EXISTS "client view own shipments" ON public.shipments;

CREATE POLICY "client view own shipments"
ON public.shipments
FOR SELECT
USING (EXISTS (SELECT 1 FROM public.clients c WHERE c.id = shipments.client_id AND c.user_id = auth.uid()));

CREATE POLICY "admin manage shipments"
ON public.shipments
FOR ALL
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "branch staff manage shipments"
ON public.shipments
FOR ALL
USING (public.can_access_branch_record(auth.uid(), origin_branch_id, destination_branch_id, current_branch_id))
WITH CHECK (public.can_access_branch_record(auth.uid(), origin_branch_id, destination_branch_id, current_branch_id));

DROP POLICY IF EXISTS "staff manage manifests" ON public.manifests;
CREATE POLICY "admin manage manifests"
ON public.manifests
FOR ALL
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "branch staff manage manifests"
ON public.manifests
FOR ALL
USING (public.can_access_branch_record(auth.uid(), origin_branch_id, destination_branch_id))
WITH CHECK (public.can_access_branch_record(auth.uid(), origin_branch_id, destination_branch_id));

DROP POLICY IF EXISTS "staff manage drs" ON public.drs;
CREATE POLICY "admin manage drs"
ON public.drs
FOR ALL
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "branch staff manage drs"
ON public.drs
FOR ALL
USING (public.can_access_branch_record(auth.uid(), branch_id))
WITH CHECK (public.can_access_branch_record(auth.uid(), branch_id));