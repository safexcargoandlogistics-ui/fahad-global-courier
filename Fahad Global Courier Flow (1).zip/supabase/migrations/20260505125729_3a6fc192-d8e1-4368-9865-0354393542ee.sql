CREATE TABLE IF NOT EXISTS public.branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_code text NOT NULL UNIQUE,
  name text NOT NULL,
  city text,
  state text,
  address text,
  phone text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "staff read branches" ON public.branches;
DROP POLICY IF EXISTS "admin manage branches" ON public.branches;

CREATE POLICY "staff read branches"
ON public.branches
FOR SELECT
USING (public.is_staff_or_admin(auth.uid()));

CREATE POLICY "admin manage branches"
ON public.branches
FOR ALL
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS branch_id uuid;

ALTER TABLE public.shipments
ADD COLUMN IF NOT EXISTS origin_branch_id uuid,
ADD COLUMN IF NOT EXISTS destination_branch_id uuid,
ADD COLUMN IF NOT EXISTS current_branch_id uuid,
ADD COLUMN IF NOT EXISTS received_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS received_by uuid;

ALTER TABLE public.manifests
ADD COLUMN IF NOT EXISTS origin_branch_id uuid,
ADD COLUMN IF NOT EXISTS destination_branch_id uuid;

ALTER TABLE public.drs
ADD COLUMN IF NOT EXISTS branch_id uuid;

CREATE INDEX IF NOT EXISTS idx_profiles_branch_id ON public.profiles(branch_id);
CREATE INDEX IF NOT EXISTS idx_shipments_origin_branch_id ON public.shipments(origin_branch_id);
CREATE INDEX IF NOT EXISTS idx_shipments_destination_branch_id ON public.shipments(destination_branch_id);
CREATE INDEX IF NOT EXISTS idx_shipments_current_branch_id ON public.shipments(current_branch_id);
CREATE INDEX IF NOT EXISTS idx_manifests_origin_branch_id ON public.manifests(origin_branch_id);
CREATE INDEX IF NOT EXISTS idx_manifests_destination_branch_id ON public.manifests(destination_branch_id);
CREATE INDEX IF NOT EXISTS idx_drs_branch_id ON public.drs(branch_id);

CREATE OR REPLACE FUNCTION public.user_branch_id(_user_id uuid)
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT branch_id FROM public.profiles WHERE id = _user_id LIMIT 1
$$;

DROP TRIGGER IF EXISTS touch_branches_updated_at ON public.branches;
CREATE TRIGGER touch_branches_updated_at
BEFORE UPDATE ON public.branches
FOR EACH ROW
EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.branches (branch_code, name, city, state, address, phone)
VALUES
  ('GZB-HO', 'Head Office - Ghaziabad', 'Ghaziabad', 'Uttar Pradesh', 'Shop No 01, Ground Floor, Main Thapar Gate Road, Vandana Vihar, Khora Colony, Ghaziabad, Uttar Pradesh 201020', '7352363283 / 9711522296'),
  ('DEL-OKH', 'Delhi Branch - Okhla', 'New Delhi', 'Delhi', 'F 30/5, Opp HDFC Bank, Okhla Industrial Estate Phase II, New Delhi 110020', '7352363283 / 9711522296'),
  ('MUM', 'Mumbai Branch', 'Mumbai', 'Maharashtra', 'Mumbai', '7352363283 / 9711522296'),
  ('HYD', 'Hyderabad Branch', 'Hyderabad', 'Telangana', 'Hyderabad', '7352363283 / 9711522296')
ON CONFLICT (branch_code) DO UPDATE SET
  name = EXCLUDED.name,
  city = EXCLUDED.city,
  state = EXCLUDED.state,
  address = EXCLUDED.address,
  phone = EXCLUDED.phone,
  updated_at = now();