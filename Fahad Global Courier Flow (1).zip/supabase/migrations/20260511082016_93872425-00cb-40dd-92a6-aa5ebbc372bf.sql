
CREATE TABLE IF NOT EXISTS public.site_content (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read site_content" ON public.site_content FOR SELECT USING (true);
CREATE POLICY "admin manage site_content" ON public.site_content FOR ALL USING (has_role(auth.uid(),'admin'::app_role)) WITH CHECK (has_role(auth.uid(),'admin'::app_role));

CREATE TABLE IF NOT EXISTS public.tracking_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid,
  awb_number text NOT NULL,
  action text NOT NULL CHECK (action IN ('reattempt','reschedule','self_collect','rto')),
  payload jsonb DEFAULT '{}'::jsonb,
  contact_phone text,
  contact_name text,
  status text NOT NULL DEFAULT 'pending',
  admin_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.tracking_actions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public insert tracking_actions" ON public.tracking_actions FOR INSERT WITH CHECK (true);
CREATE POLICY "staff read tracking_actions" ON public.tracking_actions FOR SELECT USING (is_staff_or_admin(auth.uid()));
CREATE POLICY "staff update tracking_actions" ON public.tracking_actions FOR UPDATE USING (is_staff_or_admin(auth.uid())) WITH CHECK (is_staff_or_admin(auth.uid()));
CREATE POLICY "admin delete tracking_actions" ON public.tracking_actions FOR DELETE USING (has_role(auth.uid(),'admin'::app_role));

CREATE TRIGGER trg_tracking_actions_updated BEFORE UPDATE ON public.tracking_actions FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_site_content_updated BEFORE UPDATE ON public.site_content FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
