CREATE OR REPLACE VIEW public.public_tracking_shipments
WITH (security_invoker = off)
AS
SELECT
  id,
  awb_number,
  booking_date,
  status,
  sender_name,
  sender_city,
  receiver_name,
  receiver_city,
  receiver_state,
  receiver_pincode,
  receiver_country,
  pieces,
  chargeable_weight,
  transport_mode,
  service_type,
  pod_url,
  pod_received_by,
  pod_at,
  delivered_at,
  updated_at
FROM public.shipments;

GRANT SELECT ON public.public_tracking_shipments TO anon, authenticated;