
DROP POLICY IF EXISTS "admin manage branches" ON public.branches;
CREATE POLICY "admin or manager manage branches" ON public.branches
  FOR ALL
  USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'branch_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'branch_manager'::app_role));
