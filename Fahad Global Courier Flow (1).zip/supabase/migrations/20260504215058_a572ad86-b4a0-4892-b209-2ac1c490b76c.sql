DROP VIEW IF EXISTS public.public_tracking_shipments;

CREATE TABLE IF NOT EXISTS public.public_tracking_shipments (
  shipment_id uuid PRIMARY KEY,
  awb_number text NOT NULL UNIQUE,
  booking_date date,
  status text,
  sender_name text,
  sender_city text,
  receiver_name text,
  receiver_city text,
  receiver_state text,
  receiver_pincode text,
  receiver_country text,
  pieces integer,
  chargeable_weight numeric,
  transport_mode text,
  service_type text,
  pod_url text,
  pod_received_by text,
  pod_at timestamptz,
  delivered_at timestamptz,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.public_tracking_shipments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public can track shipments" ON public.public_tracking_shipments;
CREATE POLICY "public can track shipments"
ON public.public_tracking_shipments
FOR SELECT
USING (true);

CREATE OR REPLACE FUNCTION public.sync_public_tracking_shipment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.public_tracking_shipments (
    shipment_id, awb_number, booking_date, status, sender_name, sender_city,
    receiver_name, receiver_city, receiver_state, receiver_pincode, receiver_country,
    pieces, chargeable_weight, transport_mode, service_type, pod_url, pod_received_by,
    pod_at, delivered_at, updated_at
  ) VALUES (
    NEW.id, NEW.awb_number, NEW.booking_date, NEW.status::text, NEW.sender_name, NEW.sender_city,
    NEW.receiver_name, NEW.receiver_city, NEW.receiver_state, NEW.receiver_pincode, NEW.receiver_country,
    NEW.pieces, NEW.chargeable_weight, NEW.transport_mode, NEW.service_type, NEW.pod_url, NEW.pod_received_by,
    NEW.pod_at, NEW.delivered_at, now()
  )
  ON CONFLICT (shipment_id) DO UPDATE SET
    awb_number = EXCLUDED.awb_number,
    booking_date = EXCLUDED.booking_date,
    status = EXCLUDED.status,
    sender_name = EXCLUDED.sender_name,
    sender_city = EXCLUDED.sender_city,
    receiver_name = EXCLUDED.receiver_name,
    receiver_city = EXCLUDED.receiver_city,
    receiver_state = EXCLUDED.receiver_state,
    receiver_pincode = EXCLUDED.receiver_pincode,
    receiver_country = EXCLUDED.receiver_country,
    pieces = EXCLUDED.pieces,
    chargeable_weight = EXCLUDED.chargeable_weight,
    transport_mode = EXCLUDED.transport_mode,
    service_type = EXCLUDED.service_type,
    pod_url = EXCLUDED.pod_url,
    pod_received_by = EXCLUDED.pod_received_by,
    pod_at = EXCLUDED.pod_at,
    delivered_at = EXCLUDED.delivered_at,
    updated_at = now();
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.sync_public_tracking_shipment() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS sync_public_tracking_shipments ON public.shipments;
CREATE TRIGGER sync_public_tracking_shipments
AFTER INSERT OR UPDATE ON public.shipments
FOR EACH ROW
EXECUTE FUNCTION public.sync_public_tracking_shipment();

INSERT INTO public.public_tracking_shipments (
  shipment_id, awb_number, booking_date, status, sender_name, sender_city,
  receiver_name, receiver_city, receiver_state, receiver_pincode, receiver_country,
  pieces, chargeable_weight, transport_mode, service_type, pod_url, pod_received_by,
  pod_at, delivered_at, updated_at
)
SELECT
  id, awb_number, booking_date, status::text, sender_name, sender_city,
  receiver_name, receiver_city, receiver_state, receiver_pincode, receiver_country,
  pieces, chargeable_weight, transport_mode, service_type, pod_url, pod_received_by,
  pod_at, delivered_at, now()
FROM public.shipments
ON CONFLICT (shipment_id) DO NOTHING;