CREATE TABLE IF NOT EXISTS public.client_rate_master (
  client_id uuid PRIMARY KEY,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  quotation_url text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);
ALTER TABLE public.client_rate_master ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff manage client_rate_master" ON public.client_rate_master
  FOR ALL USING (public.is_staff_or_admin(auth.uid()))
  WITH CHECK (public.is_staff_or_admin(auth.uid()));

CREATE POLICY "client view own rate master" ON public.client_rate_master
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.clients c
    WHERE c.id = client_rate_master.client_id AND c.user_id = auth.uid()
  ));

CREATE TRIGGER trg_client_rate_master_updated
  BEFORE UPDATE ON public.client_rate_master
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();