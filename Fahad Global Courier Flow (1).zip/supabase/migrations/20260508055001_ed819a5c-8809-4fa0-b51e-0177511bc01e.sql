
-- Sync trigger: keeps public_tracking_shipments in sync with shipments
DROP TRIGGER IF EXISTS trg_sync_public_tracking ON public.shipments;
CREATE TRIGGER trg_sync_public_tracking
AFTER INSERT OR UPDATE ON public.shipments
FOR EACH ROW EXECUTE FUNCTION public.sync_public_tracking_shipment();

-- Delete propagation: when shipment removed, clear public tracking row
CREATE OR REPLACE FUNCTION public.delete_public_tracking_shipment()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  DELETE FROM public.public_tracking_shipments WHERE shipment_id = OLD.id;
  RETURN OLD;
END; $$;
DROP TRIGGER IF EXISTS trg_del_public_tracking ON public.shipments;
CREATE TRIGGER trg_del_public_tracking
AFTER DELETE ON public.shipments
FOR EACH ROW EXECUTE FUNCTION public.delete_public_tracking_shipment();

-- When a manifest is created, mark linked shipments' current_branch_id = origin so tracking shows movement,
-- and add a function to revert shipments when a manifest is deleted (set status back to received_at_branch / booked).
CREATE OR REPLACE FUNCTION public.revert_shipments_on_manifest_delete()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE sid uuid;
BEGIN
  FOR sid IN SELECT shipment_id FROM public.manifest_shipments WHERE manifest_id = OLD.id LOOP
    -- revert to booked if currently manifested/in_transit
    UPDATE public.shipments SET status = 'booked'::shipment_status
    WHERE id = sid AND status IN ('manifested'::shipment_status, 'in_transit'::shipment_status);
    -- remove forwarding tracking events tied to this manifest by remarks pattern
    DELETE FROM public.tracking_events
    WHERE shipment_id = sid
      AND remarks ILIKE 'Forwarded to%'
      AND status IN ('manifested'::shipment_status, 'in_transit'::shipment_status);
  END LOOP;
  RETURN OLD;
END; $$;
DROP TRIGGER IF EXISTS trg_revert_on_manifest_del ON public.manifests;
CREATE TRIGGER trg_revert_on_manifest_del
BEFORE DELETE ON public.manifests
FOR EACH ROW EXECUTE FUNCTION public.revert_shipments_on_manifest_delete();

-- Pincode serviceability table
CREATE TABLE IF NOT EXISTS public.pincodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pincode text NOT NULL,
  city text,
  state text,
  branch_id uuid,
  serviceable boolean NOT NULL DEFAULT true,
  cod_available boolean NOT NULL DEFAULT false,
  tat_days integer DEFAULT 2,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(pincode)
);
ALTER TABLE public.pincodes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read pincodes" ON public.pincodes FOR SELECT USING (true);
CREATE POLICY "admin manage pincodes" ON public.pincodes FOR ALL
  USING (public.has_role(auth.uid(),'admin'::app_role) OR public.has_role(auth.uid(),'branch_manager'::app_role))
  WITH CHECK (public.has_role(auth.uid(),'admin'::app_role) OR public.has_role(auth.uid(),'branch_manager'::app_role));

-- Rate card: add origin/destination + agreement fields for location-wise pricing
ALTER TABLE public.rate_cards ADD COLUMN IF NOT EXISTS origin_city text;
ALTER TABLE public.rate_cards ADD COLUMN IF NOT EXISTS destination_city text;
ALTER TABLE public.rate_cards ADD COLUMN IF NOT EXISTS origin_pincode text;
ALTER TABLE public.rate_cards ADD COLUMN IF NOT EXISTS destination_pincode text;
ALTER TABLE public.rate_cards ADD COLUMN IF NOT EXISTS agreement_url text;
ALTER TABLE public.rate_cards ADD COLUMN IF NOT EXISTS notes text;

-- Storage bucket for rate agreements
INSERT INTO storage.buckets (id, name, public)
VALUES ('rate-agreements','rate-agreements', false)
ON CONFLICT (id) DO NOTHING;
CREATE POLICY "rate agreements staff read" ON storage.objects FOR SELECT
  USING (bucket_id='rate-agreements' AND public.is_staff_or_admin(auth.uid()));
CREATE POLICY "rate agreements staff write" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id='rate-agreements' AND public.is_staff_or_admin(auth.uid()));
CREATE POLICY "rate agreements staff update" ON storage.objects FOR UPDATE
  USING (bucket_id='rate-agreements' AND public.is_staff_or_admin(auth.uid()));
CREATE POLICY "rate agreements staff delete" ON storage.objects FOR DELETE
  USING (bucket_id='rate-agreements' AND public.is_staff_or_admin(auth.uid()));

-- Backfill public_tracking_shipments for existing shipments
INSERT INTO public.public_tracking_shipments (
  shipment_id, awb_number, booking_date, status, sender_name, sender_city,
  receiver_name, receiver_city, receiver_state, receiver_pincode, receiver_country,
  pieces, transport_mode, service_type, pod_url, pod_received_by,
  pod_at, delivered_at, current_branch_city, current_branch_name, destination_branch_city, updated_at
)
SELECT s.id, s.awb_number, s.booking_date, s.status::text, s.sender_name, s.sender_city,
  s.receiver_name, s.receiver_city, s.receiver_state, s.receiver_pincode, s.receiver_country,
  s.pieces, s.transport_mode, s.service_type, s.pod_url, s.pod_received_by,
  s.pod_at, s.delivered_at,
  bc.city, bc.name, bd.city, now()
FROM public.shipments s
LEFT JOIN public.branches bc ON bc.id = s.current_branch_id
LEFT JOIN public.branches bd ON bd.id = s.destination_branch_id
ON CONFLICT (shipment_id) DO UPDATE SET
  status = EXCLUDED.status,
  current_branch_city = EXCLUDED.current_branch_city,
  current_branch_name = EXCLUDED.current_branch_name,
  destination_branch_city = EXCLUDED.destination_branch_city,
  updated_at = now();
