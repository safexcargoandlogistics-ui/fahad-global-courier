REVOKE EXECUTE ON FUNCTION public.user_branch_id(uuid) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.user_branch_id(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.user_branch_id(uuid) FROM authenticated;