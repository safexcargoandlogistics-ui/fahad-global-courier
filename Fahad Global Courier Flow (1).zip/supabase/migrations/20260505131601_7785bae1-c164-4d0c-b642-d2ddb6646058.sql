-- Update is_staff_or_admin to include branch_manager (treated as staff for branch scope)
CREATE OR REPLACE FUNCTION public.is_staff_or_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role IN ('admin','staff','branch_manager'))
$$;

-- Mirror in private schema if exists
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_namespace WHERE nspname='private') THEN
    EXECUTE $f$
      CREATE OR REPLACE FUNCTION private.is_staff_or_admin(_user_id uuid)
      RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $i$
        SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role IN ('admin','staff','branch_manager'))
      $i$;
    $f$;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.can_access_branch_record(_user_id uuid, VARIADIC _branch_ids uuid[])
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT public.has_role(_user_id, 'admin'::app_role)
    OR (
      (public.has_role(_user_id, 'staff'::app_role) OR public.has_role(_user_id, 'branch_manager'::app_role))
      AND (
        public.user_branch_id(_user_id) IS NULL
        OR EXISTS (
          SELECT 1 FROM unnest(_branch_ids) AS b(id)
          WHERE b.id IS NULL OR b.id = public.user_branch_id(_user_id)
        )
      )
    )
$$;