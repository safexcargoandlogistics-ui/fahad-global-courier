
-- Website branches (separate from operational branches)
CREATE TABLE public.website_branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  city text,
  state text,
  address text,
  phone text,
  email text,
  contact_person text,
  map_url text,
  image_url text,
  display_order int NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.website_branches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read active website branches" ON public.website_branches FOR SELECT USING (active = true);
CREATE POLICY "admin manage website branches" ON public.website_branches FOR ALL
  USING (public.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));
CREATE TRIGGER trg_website_branches_updated BEFORE UPDATE ON public.website_branches
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Public storage bucket for website assets
INSERT INTO storage.buckets (id, name, public) VALUES ('website-assets', 'website-assets', true)
  ON CONFLICT (id) DO NOTHING;
CREATE POLICY "website-assets public read" ON storage.objects FOR SELECT USING (bucket_id = 'website-assets');
CREATE POLICY "website-assets admin write" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'website-assets' AND public.has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "website-assets admin update" ON storage.objects FOR UPDATE
  USING (bucket_id = 'website-assets' AND public.has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "website-assets admin delete" ON storage.objects FOR DELETE
  USING (bucket_id = 'website-assets' AND public.has_role(auth.uid(), 'admin'::app_role));

-- Fix pods bucket: ensure staff/admin can write
CREATE POLICY "pods public read" ON storage.objects FOR SELECT USING (bucket_id = 'pods');
CREATE POLICY "pods staff insert" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'pods' AND public.is_staff_or_admin(auth.uid()));
CREATE POLICY "pods staff update" ON storage.objects FOR UPDATE
  USING (bucket_id = 'pods' AND public.is_staff_or_admin(auth.uid()));
CREATE POLICY "pods staff delete" ON storage.objects FOR DELETE
  USING (bucket_id = 'pods' AND public.is_staff_or_admin(auth.uid()));

-- Undelivered reason on shipments and tracking events
ALTER TABLE public.shipments ADD COLUMN IF NOT EXISTS undelivered_reason text;
ALTER TABLE public.tracking_events ADD COLUMN IF NOT EXISTS undelivered_reason text;
