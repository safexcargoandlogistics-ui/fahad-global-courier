DROP POLICY IF EXISTS "pod read by name" ON storage.objects;
DROP POLICY IF EXISTS "pod staff write" ON storage.objects;
DROP POLICY IF EXISTS "pod staff update" ON storage.objects;
DROP POLICY IF EXISTS "pod staff delete" ON storage.objects;

CREATE POLICY "pod read by name" ON storage.objects
FOR SELECT USING (bucket_id = 'pods');

CREATE POLICY "pod staff write" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'pods' AND private.is_staff_or_admin(auth.uid()));

CREATE POLICY "pod staff update" ON storage.objects
FOR UPDATE USING (bucket_id = 'pods' AND private.is_staff_or_admin(auth.uid()));

CREATE POLICY "pod staff delete" ON storage.objects
FOR DELETE USING (bucket_id = 'pods' AND private.is_staff_or_admin(auth.uid()));