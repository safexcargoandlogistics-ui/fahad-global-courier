ALTER TABLE public.pickup_requests
  ALTER COLUMN user_id DROP NOT NULL,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS assigned_branch_id uuid,
  ADD COLUMN IF NOT EXISTS assigned_rider text,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz;

DROP POLICY IF EXISTS "anyone can submit pickup" ON public.pickup_requests;
CREATE POLICY "anyone can submit pickup"
  ON public.pickup_requests FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "public can read pickup by id" ON public.pickup_requests;
CREATE POLICY "public can read pickup by id"
  ON public.pickup_requests FOR SELECT
  USING (true);
