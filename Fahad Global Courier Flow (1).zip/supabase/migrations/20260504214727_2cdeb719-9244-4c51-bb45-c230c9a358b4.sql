CREATE SCHEMA IF NOT EXISTS private;

CREATE OR REPLACE FUNCTION private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION private.is_staff_or_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role IN ('admin','staff')
  )
$$;

GRANT USAGE ON SCHEMA private TO authenticated, anon;
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION private.is_staff_or_admin(uuid) TO authenticated, anon;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_staff_or_admin(uuid) FROM PUBLIC, anon, authenticated;

DROP POLICY IF EXISTS "staff read clients" ON public.clients;
DROP POLICY IF EXISTS "staff write clients" ON public.clients;
CREATE POLICY "staff read clients" ON public.clients FOR SELECT USING (private.is_staff_or_admin(auth.uid()) OR (user_id = auth.uid()));
CREATE POLICY "staff write clients" ON public.clients FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage drs" ON public.drs;
CREATE POLICY "staff manage drs" ON public.drs FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage drs_shipments" ON public.drs_shipments;
CREATE POLICY "staff manage drs_shipments" ON public.drs_shipments FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage invoice_items" ON public.invoice_items;
CREATE POLICY "staff manage invoice_items" ON public.invoice_items FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage invoices" ON public.invoices;
CREATE POLICY "staff manage invoices" ON public.invoices FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage ledger" ON public.ledger_entries;
CREATE POLICY "staff manage ledger" ON public.ledger_entries FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage manifest_shipments" ON public.manifest_shipments;
CREATE POLICY "staff manage manifest_shipments" ON public.manifest_shipments FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage manifests" ON public.manifests;
CREATE POLICY "staff manage manifests" ON public.manifests FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "admin manage profiles" ON public.profiles;
DROP POLICY IF EXISTS "own profile read" ON public.profiles;
CREATE POLICY "admin manage profiles" ON public.profiles FOR ALL USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "own profile read" ON public.profiles FOR SELECT USING ((auth.uid() = id) OR private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage rates" ON public.rate_cards;
CREATE POLICY "staff manage rates" ON public.rate_cards FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff manage shipments" ON public.shipments;
CREATE POLICY "staff manage shipments" ON public.shipments FOR ALL USING (private.is_staff_or_admin(auth.uid())) WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "staff delete tracking" ON public.tracking_events;
DROP POLICY IF EXISTS "staff update tracking" ON public.tracking_events;
DROP POLICY IF EXISTS "staff write tracking" ON public.tracking_events;
CREATE POLICY "staff delete tracking" ON public.tracking_events FOR DELETE USING (private.is_staff_or_admin(auth.uid()));
CREATE POLICY "staff update tracking" ON public.tracking_events FOR UPDATE USING (private.is_staff_or_admin(auth.uid()));
CREATE POLICY "staff write tracking" ON public.tracking_events FOR INSERT WITH CHECK (private.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "admin manage roles" ON public.user_roles;
DROP POLICY IF EXISTS "view own roles" ON public.user_roles;
CREATE POLICY "admin manage roles" ON public.user_roles FOR ALL USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "view own roles" ON public.user_roles FOR SELECT USING ((auth.uid() = user_id) OR private.has_role(auth.uid(), 'admin'::public.app_role));