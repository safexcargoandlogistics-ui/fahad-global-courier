CREATE OR REPLACE FUNCTION public.sync_public_tracking_shipment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.public_tracking_shipments (
    shipment_id, awb_number, booking_date, status, sender_name, sender_city,
    receiver_name, receiver_city, receiver_state, receiver_pincode, receiver_country,
    pieces, transport_mode, service_type, pod_url, pod_received_by,
    pod_at, delivered_at, updated_at
  ) VALUES (
    NEW.id, NEW.awb_number, NEW.booking_date, NEW.status::text, NEW.sender_name, NEW.sender_city,
    NEW.receiver_name, NEW.receiver_city, NEW.receiver_state, NEW.receiver_pincode, NEW.receiver_country,
    NEW.pieces, NEW.transport_mode, NEW.service_type, NEW.pod_url, NEW.pod_received_by,
    NEW.pod_at, NEW.delivered_at, now()
  )
  ON CONFLICT (shipment_id) DO UPDATE SET
    awb_number = EXCLUDED.awb_number,
    booking_date = EXCLUDED.booking_date,
    status = EXCLUDED.status,
    sender_name = EXCLUDED.sender_name,
    sender_city = EXCLUDED.sender_city,
    receiver_name = EXCLUDED.receiver_name,
    receiver_city = EXCLUDED.receiver_city,
    receiver_state = EXCLUDED.receiver_state,
    receiver_pincode = EXCLUDED.receiver_pincode,
    receiver_country = EXCLUDED.receiver_country,
    pieces = EXCLUDED.pieces,
    transport_mode = EXCLUDED.transport_mode,
    service_type = EXCLUDED.service_type,
    pod_url = EXCLUDED.pod_url,
    pod_received_by = EXCLUDED.pod_received_by,
    pod_at = EXCLUDED.pod_at,
    delivered_at = EXCLUDED.delivered_at,
    updated_at = now();
  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS sync_public_tracking_after_shipment_change ON public.shipments;
CREATE TRIGGER sync_public_tracking_after_shipment_change
AFTER INSERT OR UPDATE ON public.shipments
FOR EACH ROW
EXECUTE FUNCTION public.sync_public_tracking_shipment();