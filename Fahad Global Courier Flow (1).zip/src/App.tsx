import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import Track from "./pages/Track";
import AppLayout from "./components/layout/AppLayout";
import Dashboard from "./pages/app/Dashboard";
import Booking from "./pages/app/Booking";
import Shipments from "./pages/app/Shipments";
import Manifest from "./pages/app/Manifest";
import DRS from "./pages/app/DRS";
import Delivery from "./pages/app/Delivery";
import Clients from "./pages/app/Clients";
import Invoices from "./pages/app/Invoices";
import Ledger from "./pages/app/Ledger";
import Rates from "./pages/app/Rates";
import Users from "./pages/app/Users";
import MIS from "./pages/app/MIS";
import ClientPortal from "./pages/ClientPortal";
import Branches from "./pages/app/Branches";
import ReceiveManifest from "./pages/app/ReceiveManifest";
import Status from "./pages/app/Status";
import Trash from "./pages/app/Trash";
import MultiTrack from "./pages/app/MultiTrack";
import WebsiteBranches from "./pages/app/WebsiteBranches";
import Pincodes from "./pages/app/Pincodes";
import PincodeCheck from "./pages/PincodeCheck";
import PublicRates from "./pages/PublicRates";
import WebsiteCMS from "./pages/app/WebsiteCMS";
import TrackingActions from "./pages/app/TrackingActions";
import Quotation from "./pages/app/Quotation";
import ClientRateMaster from "./pages/app/ClientRateMaster";
import PODUpload from "./pages/app/PODUpload";
import Pickup from "./pages/Pickup";
import Pickups from "./pages/app/Pickups";
import Unsubscribe from "./pages/Unsubscribe";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/track" element={<Track />} />
            <Route path="/pincode-check" element={<PincodeCheck />} />
            <Route path="/rates" element={<PublicRates />} />
            <Route path="/pickup" element={<Pickup />} />
            <Route path="/unsubscribe" element={<Unsubscribe />} />
            <Route path="/portal" element={<ClientPortal />} />
            <Route path="/app" element={<AppLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="booking" element={<Booking />} />
              <Route path="shipments" element={<Shipments />} />
              <Route path="manifest/:type" element={<Manifest />} />
              <Route path="drs" element={<DRS />} />
              <Route path="delivery" element={<Delivery />} />
              <Route path="pod-upload" element={<PODUpload />} />
              <Route path="pickups" element={<Pickups />} />
              <Route path="clients" element={<Clients />} />
              <Route path="invoices" element={<Invoices />} />
              <Route path="ledger" element={<Ledger />} />
              <Route path="rates" element={<Rates />} />
              <Route path="quotation" element={<Quotation />} />
              <Route path="client-rates" element={<ClientRateMaster />} />
              <Route path="users" element={<Users />} />
              <Route path="mis" element={<MIS />} />
              <Route path="branches" element={<Branches />} />
              <Route path="website-branches" element={<WebsiteBranches />} />
              <Route path="website-cms" element={<WebsiteCMS />} />
              <Route path="tracking-actions" element={<TrackingActions />} />
              <Route path="pincodes" element={<Pincodes />} />
              <Route path="receive" element={<ReceiveManifest />} />
              <Route path="status" element={<Status />} />
              <Route path="trash" element={<Trash />} />
              <Route path="track" element={<MultiTrack />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
