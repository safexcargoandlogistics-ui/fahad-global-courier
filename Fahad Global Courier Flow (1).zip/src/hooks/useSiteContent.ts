import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export function useSiteContent<T = any>(key: string, defaults: T) {
  const [value, setValue] = useState<T>(defaults);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    (supabase as any).from("site_content").select("value").eq("key", key).maybeSingle().then(({ data }: any) => {
      if (!alive) return;
      if (data?.value !== undefined && data?.value !== null) {
        // Preserve arrays; only spread-merge for plain objects
        if (Array.isArray(defaults) || Array.isArray(data.value)) {
          setValue(Array.isArray(data.value) ? (data.value as T) : defaults);
        } else if (typeof data.value === "object") {
          setValue({ ...(defaults as any), ...(data.value as any) });
        } else {
          setValue(data.value as T);
        }
      }
      setLoading(false);
    });
    return () => { alive = false; };
  }, [key]);
  const save = useCallback(async (v: T) => {
    const { error } = await (supabase as any).from("site_content").upsert({ key, value: v, updated_at: new Date().toISOString() }, { onConflict: "key" });
    if (!error) setValue(v);
    return error;
  }, [key]);
  return { value, setValue, save, loading };
}

export const SITE_DEFAULTS = {
  header: {
    brand: "Fahad Global Logistics",
    tagline: "Domestic & International Courier",
    nav: [
      { label: "Home", url: "#home" },
      { label: "Services", url: "#services" },
      { label: "Network", url: "#network" },
      { label: "Branches", url: "#branches" },
      { label: "Rates", url: "/rates" },
      { label: "Track", url: "/track" },
      { label: "Contact", url: "#contact" },
    ],
  },
  hero: {
    badge: "India's trusted multi-modal courier partner",
    title_line1: "Move it Faster.",
    title_line2: "Track it Smarter.",
    subtitle: "Door-to-door pickup and delivery across India and 200+ countries — by Air, Sea, Rail and Road.",
    cta_primary: "Book a Pickup",
    cta_secondary: "Track Shipment",
    banner_url: "",
    slides: [] as { url: string; caption?: string }[],
    slide_interval_ms: 5000,
  },
  contact: {
    phone: "7352363283 / 9711522296",
    email: "info@fahadglobal.com",
    web: "www.fahadglobal.com",
    hours: "Mon–Sat 9:00 – 20:00",
    whatsapp: "917352363283",
    address: "Shop No 01, Ground Floor, Main Thapar Gate Road, Vandana Vihar, Khora Colony, Ghaziabad, UP 201020",
  },
  footer: {
    copyright: `© ${new Date().getFullYear()} Fahad Global Logistics. All rights reserved.`,
    gstin: "09AEXPF5632E1Z9",
    tagline: "Domestic & International Courier Services",
  },
  about: {
    title: "About Fahad Global Logistics",
    body: "Fahad Global Logistics is a trusted multi-modal courier and freight partner serving India and 200+ countries worldwide.",
  },
  track_page: {
    title: "Track Your Shipment",
    subtitle: "Enter one or more AWB numbers (comma, space or newline separated)",
  },
  public_rates: [
    { service: "Standard Air", destination: "Mumbai", rate: 90, min_weight: 5, tat: "1-2 Days", active: true },
    { service: "Surface", destination: "REST OF INDIA", rate: 50, min_weight: 20, tat: "4-6 Days", active: true },
  ],
  team: [] as { name: string; designation: string; photo?: string; bio?: string }[],
  theme: {
    primary_color: "#0B1E5B",
    accent_color: "#D4AF37",
    bg_color: "",
    body_font: "",
    heading_font: "",
    base_font_px: 16,
    show_team: true,
    show_partners: true,
    show_about: true,
    show_network: true,
    show_branches: true,
  },
  seo_settings: {
    google_site_verification: "",
    same_as: "",
  },
  partners: [
    { name: "DHL", logo: "" },
    { name: "FedEx", logo: "" },
    { name: "Aramex", logo: "" },
    { name: "UPS", logo: "" },
    { name: "Delhivery", logo: "" },
    { name: "DTDC", logo: "" },
    { name: "Blue Dart", logo: "" },
    { name: "TNT", logo: "" },
  ],
  services: [
    { icon: "Zap", title: "Same Day Delivery", desc: "Local same-day pickup and drop within city limits", logo: "", color: "from-amber-400 to-orange-600" },
    { icon: "Truck", title: "Next Business Day", desc: "Overnight delivery between major Indian cities", logo: "", color: "from-emerald-400 to-green-700" },
    { icon: "Plane", title: "Air Express", desc: "Pan-India air service with full track & POD", logo: "", color: "from-sky-400 to-indigo-600" },
    { icon: "Train", title: "Train / Road Surface", desc: "Cost-effective surface freight for heavy loads", logo: "", color: "from-rose-400 to-pink-600" },
    { icon: "Globe", title: "International Courier", desc: "Customs-cleared shipping to 200+ countries", logo: "", color: "from-cyan-400 to-blue-700" },
    { icon: "PackageCheck", title: "Bulk & Bill Booking", desc: "Corporate accounts with monthly invoicing & ledger", logo: "", color: "from-violet-400 to-purple-700" },
  ],
  invoice_settings: {
    company_name: "FAHAD GLOBAL LOGISTICS",
    address: "Shop No 01, Ground Floor, Main Thapar Gate Road, Vandana Vihar, Khora Colony, Ghaziabad, UP 201020",
    phone: "7352363283 / 9711522296",
    email: "info@fahadglobal.com",
    web: "www.fahadglobal.com",
    gstin: "09AEXPF5632E1Z9",
    pan: "AEXPF5632E",
    state: "UTTAR PRADESH",
    state_code: "09",
    udyam: "",
    sac: "996812",
    gst_pct: 18,
    cgst_pct: 9,
    sgst_pct: 9,
    igst_pct: 18,
    intra_state: false,
    due_days: "10 Days",
    bank_name: "HDFC Bank",
    bank_account: "",
    bank_branch: "",
    bank_ifsc: "",
    swift_code: "",
    declaration: "We declare that this invoice shows the actual price of the services described and that all particulars are true and correct.",
    computer_generated: "This is a Computer Generated Invoice. No signature required.",
    terms: [
      "Payment to be made by cheque/NEFT in favour of FAHAD GLOBAL LOGISTICS.",
      "Interest @ 18% p.a. will be charged on overdue invoices.",
      "Any disputes must be raised in writing within 7 days of invoice receipt.",
      "Subject to Ghaziabad Jurisdiction. E. & O.E.",
    ],
    primary_color: "#0B1E5B",
    accent_color: "#D4AF37",
    font_size: 8,
  },
};