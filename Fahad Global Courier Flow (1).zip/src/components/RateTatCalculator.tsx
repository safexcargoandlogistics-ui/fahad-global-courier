import { useMemo, useState } from "react";
import { Calculator, Clock, MapPin, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { SITE_DEFAULTS, useSiteContent } from "@/hooks/useSiteContent";
import { IndiaPostPicker } from "@/components/IndiaPostPicker";

const money = (v: number) => v.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function RateTatCalculator({ compact = false }: { compact?: boolean }) {
  const { value } = useSiteContent<any[]>("public_rates", SITE_DEFAULTS.public_rates as any);
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [weight, setWeight] = useState(1);
  const [L, setL] = useState(0);
  const [W, setW] = useState(0);
  const [H, setH] = useState(0);
  const [div, setDiv] = useState(5000);
  const [service, setService] = useState("all");
  const [searched, setSearched] = useState(false);

  const volWt = useMemo(() => {
    const v = (Number(L) * Number(W) * Number(H)) / (Number(div) || 5000);
    return v > 0 ? Math.round(v * 1000) / 1000 : 0;
  }, [L, W, H, div]);
  const chargeable = Math.max(Number(weight) || 0, volWt);

  const rows = useMemo(() => (Array.isArray(value) ? value : [])
    .filter((r: any) => r.active !== false)
    .filter((r: any) => service === "all" || String(r.service || "").toLowerCase() === service)
    .filter((r: any) => {
      const d = destination.trim().toLowerCase();
      if (!d) return true;
      const dest = String(r.destination || "").toLowerCase();
      return dest.includes(d) || d.includes(dest) || dest.includes("rest of india");
    }), [value, destination, service]);

  const services = useMemo(() => Array.from(new Set((Array.isArray(value) ? value : []).map((r: any) => String(r.service || "")).filter(Boolean))), [value]);
  const visibleRows = searched ? rows : rows.slice(0, compact ? 2 : 5);

  return (
    <Card className="border-primary/20 bg-card/95 shadow-xl">
      <CardContent className={compact ? "p-4" : "p-6"}>
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary"><Calculator className="h-5 w-5" /></div>
          <div>
            <h2 className="text-xl font-bold">Rate &amp; TAT Calculator</h2>
            <p className="text-xs text-muted-foreground">Approx public rate. Final billing follows client quotation.</p>
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label>Origin pincode / city</Label>
            <IndiaPostPicker value={origin} onSelect={(loc) => setOrigin(`${loc.city} - ${loc.pincode}`)} placeholder="Origin" />
          </div>
          <div className="space-y-1">
            <Label>Destination pincode / city</Label>
            <IndiaPostPicker value={destination} onSelect={(loc) => setDestination(`${loc.city} - ${loc.pincode}`)} placeholder="Destination" />
          </div>
          <div className="space-y-1">
            <Label>Actual weight (kg)</Label>
            <Input type="number" min="0.1" step="0.1" value={weight} onChange={(e) => setWeight(Number(e.target.value) || 0)} />
          </div>
          <div className="space-y-1">
            <Label>Service</Label>
            <select className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" value={service} onChange={(e) => setService(e.target.value)}>
              <option value="all">All services</option>
              {services.map((s) => <option key={s} value={s.toLowerCase()}>{s}</option>)}
            </select>
          </div>
          <div className="space-y-1 sm:col-span-2">
            <Label>Dimensions (cm) — L × W × H · Divisor</Label>
            <div className="grid grid-cols-4 gap-2">
              <Input type="number" min="0" placeholder="L" value={L || ""} onChange={(e) => setL(Number(e.target.value) || 0)} />
              <Input type="number" min="0" placeholder="W" value={W || ""} onChange={(e) => setW(Number(e.target.value) || 0)} />
              <Input type="number" min="0" placeholder="H" value={H || ""} onChange={(e) => setH(Number(e.target.value) || 0)} />
              <Input type="number" min="1000" step="500" value={div} onChange={(e) => setDiv(Number(e.target.value) || 5000)} />
            </div>
            <div className="text-[11px] text-muted-foreground">Volumetric: <b>{volWt} kg</b> · Chargeable used: <b>{chargeable} kg</b></div>
          </div>
        </div>
        <Button className="mt-4 w-full" onClick={() => setSearched(true)}><Search className="mr-2 h-4 w-4" />Check Rate &amp; TAT</Button>
        <div className="mt-4 space-y-2">
          {visibleRows.map((r: any, i: number) => {
            const billedWeight = Math.max(Number(chargeable || 0), Number(r.min_weight || 0));
            const amount = billedWeight * Number(r.rate || 0);
            return (
              <div key={`${r.service}-${r.destination}-${i}`} className="rounded-lg border bg-background/70 p-3 text-sm">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-semibold">{r.service} — {r.destination}</div>
                    <div className="mt-1 flex flex-wrap gap-3 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{r.tat || "Contact us"}</span>
                      <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />Min {r.min_weight || 0} kg</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-primary">₹{money(amount)}</div>
                    <div className="text-[11px] text-muted-foreground">₹{money(Number(r.rate || 0))}/kg</div>
                  </div>
                </div>
              </div>
            );
          })}
          {!visibleRows.length && <div className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">No rate found. REST OF INDIA rate will apply or contact support.</div>}
        </div>
      </CardContent>
    </Card>
  );
}