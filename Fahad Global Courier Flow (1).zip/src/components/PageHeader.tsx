import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { format } from "date-fns";

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  return (
    <div className="flex flex-col gap-3 rounded-md border bg-card p-4 shadow-sm md:flex-row md:items-center md:justify-between">
      <div>
        <h1 className="text-2xl font-bold tracking-normal">{title}</h1>
        {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3">
        <div className="rounded-md border bg-muted px-3 py-2 text-xs font-medium text-muted-foreground">{format(now, "dd MMM yyyy, HH:mm:ss")}</div>
        {action}
      </div>
    </div>
  );
}
