import { Helmet } from "react-helmet-async";
import { useSiteContent } from "@/hooks/useSiteContent";

const BASE = "https://www.fahadglobal.com";

export function SEO({ title, description, path = "/", jsonLd }: { title: string; description: string; path?: string; jsonLd?: Record<string, any> | Record<string, any>[] }) {
  const { value } = useSiteContent("seo_settings", { google_site_verification: "", same_as: "" });
  const canonical = `${BASE}${path === "/" ? "/" : path}`;
  const sameAs = String((value as any)?.same_as || "").split(/[\n,]+/).map((x) => x.trim()).filter(Boolean);
  const baseJson = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "FAHAD GLOBAL LOGISTICS",
    url: BASE,
    logo: `${BASE}/favicon.ico`,
    sameAs,
    contactPoint: [{ "@type": "ContactPoint", telephone: "+91-7352363283", contactType: "customer service", areaServed: "IN" }],
  };
  const schema = jsonLd ? (Array.isArray(jsonLd) ? [baseJson, ...jsonLd] : [baseJson, jsonLd]) : [baseJson];
  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={canonical} />
      <link rel="alternate" hrefLang="en-IN" href={canonical} />
      {(value as any)?.google_site_verification && <meta name="google-site-verification" content={(value as any).google_site_verification} />}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={canonical} />
      <meta property="og:type" content="website" />
      <script type="application/ld+json">{JSON.stringify(schema)}</script>
    </Helmet>
  );
}