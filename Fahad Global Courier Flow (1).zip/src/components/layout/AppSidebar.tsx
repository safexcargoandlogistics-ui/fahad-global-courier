import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard, Package, FileText, Truck, ClipboardCheck, Users, Receipt,
  BookOpen, MapPin, Settings, IndianRupee, BarChart3, PackageCheck, Activity, Building2, Trash2, Search, Globe, Map, Edit3, Bell, FileImage, PackagePlus
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, useSidebar,
} from "@/components/ui/sidebar";
import { useAuth } from "@/lib/auth";
import { Logo } from "@/components/Logo";

const ops = [
  { title: "Dashboard", url: "/app", icon: LayoutDashboard },
  { title: "New Booking", url: "/app/booking", icon: Package },
  { title: "Shipments", url: "/app/shipments", icon: FileText },
  { title: "Outgoing Manifest", url: "/app/manifest/outgoing", icon: Truck },
  { title: "Incoming Manifest", url: "/app/manifest/incoming", icon: Truck },
  { title: "Receive at Branch", url: "/app/receive", icon: PackageCheck },
  { title: "DRS", url: "/app/drs", icon: ClipboardCheck },
  { title: "Delivery Update", url: "/app/delivery", icon: MapPin },
  { title: "POD Upload", url: "/app/pod-upload", icon: FileImage },
  { title: "Pickup Requests", url: "/app/pickups", icon: PackagePlus },
  { title: "Multi-AWB Track", url: "/app/track", icon: Search },
];
const billing = [
  { title: "Invoices", url: "/app/invoices", icon: Receipt },
  { title: "Ledger", url: "/app/ledger", icon: BookOpen },
  { title: "Rate Cards", url: "/app/rates", icon: IndianRupee },
  { title: "Client Rate Master", url: "/app/client-rates", icon: IndianRupee },
  { title: "MIS Report", url: "/app/mis", icon: BarChart3 },
];
const admin = [
  { title: "Clients", url: "/app/clients", icon: Users },
  { title: "Users & Roles", url: "/app/users", icon: Settings },
  { title: "Recycle Bin", url: "/app/trash", icon: Trash2 },
  { title: "System Status", url: "/app/status", icon: Activity },
];
const managerNav = [
  { title: "Branches", url: "/app/branches", icon: Building2 },
  { title: "Pincodes", url: "/app/pincodes", icon: Map },
];
const adminWeb = [
  { title: "Website CMS", url: "/app/website-cms", icon: Edit3 },
  { title: "Website Branches", url: "/app/website-branches", icon: Globe },
  { title: "Customer Requests", url: "/app/tracking-actions", icon: Bell },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { pathname } = useLocation();
  const { isAdmin, isBranchManager } = useAuth();
  const isActive = (u: string) => pathname === u || (u !== "/app" && pathname.startsWith(u));

  const renderGroup = (label: string, items: typeof ops) => (
    <SidebarGroup>
      {!collapsed && <SidebarGroupLabel>{label}</SidebarGroupLabel>}
      <SidebarGroupContent>
        <SidebarMenu>
          {items.map((it) => (
            <SidebarMenuItem key={it.url}>
              <SidebarMenuButton asChild isActive={isActive(it.url)}>
                <NavLink to={it.url} end={it.url === "/app"}>
                  <it.icon className="h-4 w-4" />
                  {!collapsed && <span>{it.title}</span>}
                </NavLink>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  );

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border px-4 py-4">
        <div className="flex items-center gap-2">
          <Logo className="h-9 w-9 rounded bg-white p-1 shrink-0" />
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-bold text-sidebar-foreground">Fahad Global</span>
              <span className="text-[10px] uppercase tracking-wider text-sidebar-foreground/60">Logistics</span>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        {renderGroup("Operations", ops)}
        {renderGroup("Billing", billing)}
        {(isAdmin || isBranchManager) && renderGroup("Master", managerNav)}
        {isAdmin && renderGroup("Public Website", adminWeb)}
        {isAdmin && renderGroup("Administration", admin)}
      </SidebarContent>
    </Sidebar>
  );
}
