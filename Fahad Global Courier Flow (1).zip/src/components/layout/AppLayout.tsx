import { Outlet, Navigate, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { LogOut, Search } from "lucide-react";
import { format } from "date-fns";

export default function AppLayout() {
  const { user, loading, signOut, isStaff } = useAuth();
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  if (loading) return <div className="flex h-screen items-center justify-center text-muted-foreground">Loading…</div>;
  if (!user) return <Navigate to="/auth" replace />;
  if (!isStaff) return <Navigate to="/portal" replace />;

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        <div className="flex-1 flex flex-col">
          <header className="h-14 flex items-center justify-between border-b bg-card px-4 sticky top-0 z-10">
            <div className="flex items-center gap-2">
              <SidebarTrigger />
              <Link to="/track" className="hidden sm:flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
                <Search className="h-4 w-4" /> Track shipment
              </Link>
            </div>
            <div className="flex items-center gap-3">
              <span className="hidden lg:block text-xs text-muted-foreground font-mono">{format(now, "dd MMM yyyy, HH:mm:ss")}</span>
              <span className="hidden md:block text-sm text-muted-foreground">{user.email}</span>
              <Button variant="ghost" size="sm" onClick={signOut}><LogOut className="h-4 w-4 mr-1" />Logout</Button>
            </div>
          </header>
          <main className="flex-1 p-4 md:p-6"><Outlet /></main>
          <footer className="border-t bg-card text-xs text-muted-foreground py-2 px-4 text-center">
            © {new Date().getFullYear()} Fahad Global Logistics  |  GSTIN 09AEXPF5632E1Z9  |  info@fahadglobal.com  |  7352363283 / 9711522296
          </footer>
        </div>
      </div>
    </SidebarProvider>
  );
}
