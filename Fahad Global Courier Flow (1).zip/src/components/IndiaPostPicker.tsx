import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronsUpDown, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { INDIA_POST_LOCATIONS, IndiaPostLocation } from "@/lib/indiaPostLocations";
import { cn } from "@/lib/utils";

type Loc = IndiaPostLocation & { country?: string };

export function IndiaPostPicker({ value, onSelect, placeholder = "Search city / pincode worldwide" }: { value?: string; placeholder?: string; onSelect: (loc: Loc) => void }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [remote, setRemote] = useState<Loc[]>([]);
  const [loading, setLoading] = useState(false);
  const timer = useRef<any>(null);
  const label = value || placeholder;
  const locations = useMemo(() => INDIA_POST_LOCATIONS, []);

  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    const q = query.trim();
    if (q.length < 3) { setRemote([]); return; }
    setLoading(true);
    timer.current = setTimeout(async () => {
      try {
        const pinHit = /^\d{4,10}$/.test(q);
        const url = pinHit
          ? `https://nominatim.openstreetmap.org/search?postalcode=${encodeURIComponent(q)}&format=json&addressdetails=1&limit=15`
          : `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&addressdetails=1&limit=15`;
        const r = await fetch(url, { headers: { "Accept-Language": "en" } });
        const j: any[] = await r.json();
        const mapped: Loc[] = (j || []).map((x) => {
          const a = x.address || {};
          const city = a.city || a.town || a.village || a.county || a.state_district || a.suburb || x.display_name?.split(",")[0] || "";
          return { pincode: a.postcode || "", city, state: a.state || a.region || "", country: a.country || "", office: x.display_name };
        }).filter((l) => l.city);
        setRemote(mapped);
      } catch { setRemote([]); }
      finally { setLoading(false); }
    }, 450);
    return () => timer.current && clearTimeout(timer.current);
  }, [query]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button type="button" variant="outline" role="combobox" className="w-full justify-between font-normal">
          <span className="truncate">{label}</span>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[420px] max-w-[calc(100vw-2rem)] p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput placeholder="Type city, state, pincode (worldwide)…" value={query} onValueChange={setQuery} />
          <CommandList>
            <CommandEmpty>{loading ? (<span className="inline-flex items-center gap-2"><Loader2 className="h-3 w-3 animate-spin" />Searching worldwide…</span>) : query.length < 3 ? "Type at least 3 characters…" : "No match found."}</CommandEmpty>
            {remote.length > 0 && (
              <CommandGroup heading="Worldwide results">
                {remote.map((loc, i) => (
                  <CommandItem key={`r-${i}`} value={`r-${i}`} onSelect={() => { onSelect(loc); setOpen(false); setQuery(""); setRemote([]); }}>
                    <Check className={cn("mr-2 h-4 w-4 opacity-0")} />
                    <div className="min-w-0">
                      <div className="truncate font-medium">{loc.city}{loc.state ? `, ${loc.state}` : ""}{loc.country ? ` · ${loc.country}` : ""}</div>
                      <div className="text-xs text-muted-foreground truncate">{loc.pincode ? `${loc.pincode} · ` : ""}{loc.office}</div>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            <CommandGroup heading="Saved India locations">
              {locations.map((loc) => (
                <CommandItem key={loc.pincode} value={`${loc.pincode} ${loc.city} ${loc.state}`} onSelect={() => { onSelect(loc); setOpen(false); }}>
                  <Check className={cn("mr-2 h-4 w-4", value === loc.city ? "opacity-100" : "opacity-0")} />
                  <div className="min-w-0">
                    <div className="truncate font-medium">{loc.city}, {loc.state}</div>
                    <div className="text-xs text-muted-foreground">{loc.pincode}{loc.office ? ` · ${loc.office}` : ""}</div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}