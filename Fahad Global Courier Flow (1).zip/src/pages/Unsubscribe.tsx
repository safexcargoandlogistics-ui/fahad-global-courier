import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const SUPA_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPA_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

export default function Unsubscribe() {
  const token = new URLSearchParams(window.location.search).get("token") || "";
  const [state, setState] = useState<"loading" | "valid" | "invalid" | "already" | "done" | "error">("loading");
  useEffect(() => {
    if (!token) { setState("invalid"); return; }
    fetch(`${SUPA_URL}/functions/v1/handle-email-unsubscribe?token=${encodeURIComponent(token)}`, { headers: { apikey: SUPA_KEY } })
      .then((r) => r.json()).then((j) => {
        if (j?.valid) setState("valid");
        else if (j?.reason === "already_unsubscribed") setState("already");
        else setState("invalid");
      }).catch(() => setState("error"));
  }, [token]);

  const confirm = async () => {
    const r = await fetch(`${SUPA_URL}/functions/v1/handle-email-unsubscribe`, { method: "POST", headers: { "Content-Type": "application/json", apikey: SUPA_KEY }, body: JSON.stringify({ token }) });
    const j = await r.json();
    if (j?.success) setState("done"); else setState("error");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-muted/30">
      <Card className="max-w-md w-full"><CardContent className="pt-6 text-center space-y-4">
        <h1 className="text-2xl font-bold">Unsubscribe</h1>
        {state === "loading" && <p>Checking link…</p>}
        {state === "invalid" && <p className="text-destructive">Invalid or expired unsubscribe link.</p>}
        {state === "already" && <p>You're already unsubscribed.</p>}
        {state === "valid" && (<><p>Click below to stop receiving emails from us.</p><Button onClick={confirm}>Confirm Unsubscribe</Button></>)}
        {state === "done" && <p className="text-success">Done. You won't receive further emails.</p>}
        {state === "error" && <p className="text-destructive">Something went wrong. Please try again.</p>}
      </CardContent></Card>
    </div>
  );
}