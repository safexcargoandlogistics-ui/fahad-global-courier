import { useMemo, useState } from "react";
import { Navigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { toast } from "sonner";
import { Logo } from "@/components/Logo";
import { ShieldCheck, RefreshCw } from "lucide-react";

function makeCaptcha() {
  const a = Math.floor(Math.random() * 8) + 2;
  const b = Math.floor(Math.random() * 8) + 1;
  return { q: `${a} + ${b}`, ans: String(a + b) };
}

export default function AuthPage() {
  const { user, isStaff, loading: authLoading } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [captcha, setCaptcha] = useState(() => makeCaptcha());
  const [captchaInput, setCaptchaInput] = useState("");

  if (user && !authLoading) return <Navigate to={isStaff ? "/app" : "/portal"} replace />;

  const refreshCaptcha = () => { setCaptcha(makeCaptcha()); setCaptchaInput(""); };

  const signIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (captchaInput.trim() !== captcha.ans) {
      toast.error("Captcha incorrect"); refreshCaptcha(); return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) { toast.error(error.message); refreshCaptcha(); }
    else toast.success("Welcome back");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--gradient-dark-hero)" }}>
      <Card className="w-full max-w-md shadow-2xl border-white/10 bg-card/95 backdrop-blur">
        <CardHeader className="text-center">
          <Logo className="mx-auto mb-2 h-16 w-auto" />
          <CardTitle className="text-2xl">Fahad Global Logistics</CardTitle>
          <CardDescription>Software login for Admin, Staff and Clients</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={signIn} className="space-y-3">
            <div><Label>Email</Label><Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></div>
            <div><Label>Password</Label><Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></div>
            <div>
              <Label className="flex items-center gap-1"><ShieldCheck className="h-3.5 w-3.5 text-primary" /> Captcha — solve <span className="font-bold">{captcha.q}</span></Label>
              <div className="flex gap-2">
                <Input required value={captchaInput} onChange={(e) => setCaptchaInput(e.target.value)} placeholder="Answer" />
                <Button type="button" size="icon" variant="outline" onClick={refreshCaptcha} title="New captcha"><RefreshCw className="h-4 w-4" /></Button>
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={loading}>{loading ? "..." : "Sign In"}</Button>
          </form>

          <div className="mt-5 rounded-lg border bg-muted/40 p-3 text-xs text-muted-foreground space-y-1">
            <p className="font-semibold text-foreground">Need an account?</p>
            <p>Public sign-up is disabled. Please contact our admin team to request access:</p>
            <p>📞 <a href="tel:9711522296" className="text-primary">9711522296</a> / <a href="tel:7352363283" className="text-primary">7352363283</a></p>
            <p>✉️ <a href="mailto:info@fahadglobal.com" className="text-primary">info@fahadglobal.com</a></p>
          </div>

          <div className="mt-4 flex items-center justify-between text-sm">
            <Link to="/" className="text-muted-foreground hover:text-primary">← Website</Link>
            <Link to="/track" className="text-muted-foreground hover:text-primary">Track Shipment</Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
