import { useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, CheckCircle2, XCircle, Clock, IndianRupee } from "lucide-react";
import { Logo } from "@/components/Logo";
import { SEO } from "@/components/SEO";

export default function PincodeCheck() {
  const [origin, setOrigin] = useState("");
  const [dest, setDest] = useState("");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const check = async () => {
    if (!/^\d{6}$/.test(dest)) return;
    setLoading(true);
    const codes = origin && /^\d{6}$/.test(origin) ? [origin, dest] : [dest];
    const { data } = await (supabase as any).from("pincodes").select("*").in("pincode", codes);
    const dRow = (data ?? []).find((x: any) => x.pincode === dest);
    const oRow = (data ?? []).find((x: any) => x.pincode === origin);
    setResult({ origin: oRow, dest: dRow, destPin: dest, originPin: origin });
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <SEO title="Pincode Serviceability Check | FAHAD GLOBAL" description="Check courier service availability, transit time and COD support by destination pincode for FAHAD GLOBAL LOGISTICS." path="/pincode-check" />
      <header className="border-b bg-card">
        <div className="container flex h-14 items-center justify-between">
          <Link to="/" className="flex items-center gap-2"><Logo className="h-9 w-auto" /><span className="font-bold">Fahad Global Logistics</span></Link>
          <Link to="/track"><Button size="sm" variant="outline">Track Shipment</Button></Link>
        </div>
      </header>
      <div className="bg-gradient-to-b from-primary/5 to-transparent border-b">
        <div className="container max-w-3xl py-12 text-center">
          <MapPin className="mx-auto h-12 w-12 text-primary mb-3" />
          <h1 className="text-3xl md:text-4xl font-bold">Check Service Availability</h1>
          <p className="text-muted-foreground mt-2">Enter destination pincode to see if we deliver, transit time and COD availability.</p>
          <div className="grid sm:grid-cols-[1fr_1fr_auto] gap-3 mt-6 max-w-2xl mx-auto">
            <Input placeholder="Origin pincode (optional)" maxLength={6} value={origin} onChange={(e) => setOrigin(e.target.value.replace(/\D/g, ""))} />
            <Input placeholder="Destination pincode *" maxLength={6} value={dest} onChange={(e) => setDest(e.target.value.replace(/\D/g, ""))} />
            <Button onClick={check} disabled={loading || dest.length !== 6}>Check</Button>
          </div>
        </div>
      </div>
      <div className="container max-w-3xl py-8">
        {result && (
          <Card className="border-2">
            <CardHeader><CardTitle>Result for {result.destPin}</CardTitle></CardHeader>
            <CardContent>
              {!result.dest ? (
                <div className="flex items-center gap-3 text-destructive"><XCircle className="h-10 w-10" /><div><div className="text-xl font-bold">Pincode not found</div><div className="text-base text-foreground/80">This pincode is not in our serviceable list. Please contact us for special arrangements.</div></div></div>
              ) : !result.dest.serviceable ? (
                <div className="flex items-center gap-3 text-destructive"><XCircle className="h-10 w-10" /><div><div className="text-xl font-bold">Not Serviceable</div><div className="text-base text-foreground/80">{result.dest.city}, {result.dest.state}</div></div></div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-3 rounded-lg bg-primary/10 border border-primary/30 p-4 text-primary"><CheckCircle2 className="h-10 w-10" /><div><div className="text-2xl font-extrabold tracking-tight">Serviceable</div><div className="text-base font-semibold text-foreground">{result.dest.city}, {result.dest.state}</div></div></div>
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div className="rounded-md bg-primary/5 border border-primary/20 p-3"><Clock className="h-6 w-6 text-primary mx-auto mb-1" /><div className="text-sm font-medium text-foreground/70">Transit</div><div className="text-lg font-extrabold text-foreground">{result.dest.tat_days} day{result.dest.tat_days > 1 ? "s" : ""}</div></div>
                    <div className="rounded-md bg-primary/5 border border-primary/20 p-3"><IndianRupee className="h-6 w-6 text-primary mx-auto mb-1" /><div className="text-sm font-medium text-foreground/70">COD</div><div className="text-lg font-extrabold text-foreground">{result.dest.cod_available ? "Available" : "Prepaid only"}</div></div>
                    <div className="rounded-md bg-primary/5 border border-primary/20 p-3"><MapPin className="h-6 w-6 text-primary mx-auto mb-1" /><div className="text-sm font-medium text-foreground/70">Pincode</div><div className="text-lg font-extrabold font-mono text-foreground">{result.dest.pincode}</div></div>
                  </div>
                  {result.origin && <div className="text-base font-medium border-t pt-3">Origin: <span className="font-bold">{result.origin.city}, {result.origin.state}</span> {result.origin.serviceable ? <Badge className="ml-2">Serviceable</Badge> : <Badge variant="destructive" className="ml-2">Not serviceable</Badge>}</div>}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
