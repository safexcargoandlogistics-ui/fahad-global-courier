import { useEffect, useMemo, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { format } from "date-fns";
import { PackageSearch, Plane, Truck, MapPin, Copy, Share2, CheckCircle2, AlertTriangle, RotateCcw, Calendar, Building2, ArrowRight, Phone, ClipboardCheck, Box, Send, PackageCheck, Bike, FileImage } from "lucide-react";
import { toast } from "sonner";
import { Logo } from "@/components/Logo";
import confetti from "canvas-confetti";
import { SEO } from "@/components/SEO";
import { Checkbox } from "@/components/ui/checkbox";

const STAGES = [
  { key: "booked", label: "Booked", Icon: ClipboardCheck },
  { key: "manifested", label: "Manifested", Icon: Box },
  { key: "in_transit", label: "In Transit", Icon: Send },
  { key: "arrived", label: "Arrived", Icon: Building2 },
  { key: "out_for_delivery", label: "Out for Delivery", Icon: Bike },
  { key: "delivered", label: "Delivered", Icon: PackageCheck },
];
const stageIdx = (st: string) => {
  switch (st) {
    case "booked": return 0;
    case "manifested": return 1;
    case "in_transit": return 2;
    case "received_at_branch": return 3;
    case "out_for_delivery": return 4;
    case "delivered": return 5;
    case "undelivered":
    case "rto": return 4;
    default: return 0;
  }
};

export default function Track() {
  const [params, setParams] = useSearchParams();
  const [awb, setAwb] = useState(params.get("awb") ?? "");
  const [results, setResults] = useState<{ shipment: any; events: any[] }[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [podGate, setPodGate] = useState<string | null>(null);
  const [podChecked, setPodChecked] = useState(false);

  const openPod = (url: string) => {
    if (sessionStorage.getItem("pod-ok") === "1") { window.open(url, "_blank"); return; }
    setPodGate(url); setPodChecked(false);
  };
  const confirmPod = () => {
    if (!podChecked || !podGate) return;
    sessionStorage.setItem("pod-ok", "1");
    window.open(podGate, "_blank");
    setPodGate(null);
  };

  const search = async (raw: string) => {
    const list = Array.from(new Set(raw.split(/[\s,;\n]+/).map((x) => x.trim().toUpperCase()).filter(Boolean)));
    if (!list.length) return;
    setLoading(true); setSearched(true);
    const { data: ships } = await (supabase as any).from("public_tracking_shipments").select("*").in("awb_number", list);
    const out: any[] = [];
    for (const code of list) {
      const s = (ships ?? []).find((x: any) => x.awb_number === code);
      if (!s) { out.push({ shipment: { awb_number: code, _missing: true }, events: [] }); continue; }
      const { data: e } = await (supabase as any).from("tracking_events").select("status,location,event_at,remarks,undelivered_reason").eq("shipment_id", s.shipment_id).order("event_at", { ascending: false });
      const cleaned = (e ?? []).map((ev: any) => ({ ...ev, remarks: ev.remarks ? String(ev.remarks).replace(/\b(MF-[A-Z0-9-]+|DRS-[A-Z0-9-]+|manifest\s*\S*|drs\s*\S*)\b/gi, "").trim() : null }));
      out.push({ shipment: s, events: cleaned });
    }
    setResults(out);
    setLoading(false);
  };
  useEffect(() => { if (params.get("awb")) search(params.get("awb")!); /* eslint-disable-next-line */ }, []);

  // Confetti only once per AWB per session
  useEffect(() => {
    results.forEach((r) => {
      if (r.shipment?.status === "delivered") {
        const key = `fired-${r.shipment.awb_number}`;
        if (!sessionStorage.getItem(key)) {
          sessionStorage.setItem(key, "1");
          setTimeout(() => confetti({ particleCount: 160, spread: 110, origin: { y: 0.6 }, colors: ["#D4AF37", "#0B1E5B", "#22c55e", "#ffffff"] }), 400);
        }
      }
    });
  }, [results]);

  const copyLink = (a: string) => { navigator.clipboard.writeText(`${window.location.origin}/track?awb=${a}`); toast.success("Tracking link copied"); };

  return (
    <div className="min-h-screen relative" style={{ background: "linear-gradient(135deg, #0B1E5B 0%, #0a1342 50%, #0B1E5B 100%)" }}>
      <SEO title="Track Courier Shipment | FAHAD GLOBAL LOGISTICS" description="Track your FAHAD GLOBAL LOGISTICS courier shipment by AWB number with live booking, transit, out for delivery and delivery status." path="/track" />
      {/* World map dotted background */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.08]" style={{ backgroundImage: "radial-gradient(circle, #D4AF37 1px, transparent 1px)", backgroundSize: "22px 22px" }} />

      {/* Header */}
      <header className="relative border-b border-white/10 backdrop-blur-md bg-white/[0.03]">
        <div className="container flex h-14 items-center justify-between text-white">
          <Link to="/" className="flex items-center gap-2">
            <Logo className="h-9 w-auto" />
            <span className="font-bold">Fahad Global Logistics</span>
          </Link>
          <div className="flex gap-2">
            <Link to="/pincode-check"><Button size="sm" variant="outline" className="bg-white/5 border-white/20 text-white hover:bg-white/10">Pincode</Button></Link>
            <Link to="/auth"><Button size="sm" className="bg-[#D4AF37] text-[#0B1E5B] hover:bg-[#D4AF37]/90 font-semibold">Login</Button></Link>
          </div>
        </div>
      </header>

      {/* Hero search */}
      <div className="relative">
        <div className="container max-w-6xl py-10">
          <div className="text-center mb-6 text-white">
            <div className="inline-flex items-center justify-center h-14 w-14 rounded-2xl bg-[#D4AF37]/15 backdrop-blur border border-[#D4AF37]/30 mb-3"><PackageSearch className="h-7 w-7 text-[#D4AF37]" /></div>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Track Your Shipment</h1>
            <p className="text-sm text-white/60 mt-2">Enter one or more AWB numbers to see live status.</p>
          </div>
          <div className="mx-auto max-w-2xl">
            <div className="rounded-2xl border border-white/15 bg-white/[0.06] backdrop-blur-xl p-5 shadow-2xl">
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white/80"><PackageSearch className="h-4 w-4 text-[#D4AF37]" />Live Shipment Tracking</div>
              <div className="flex flex-col gap-2">
                <textarea className="min-h-[116px] rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/40 px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-[#D4AF37]" placeholder="FGL000001, FGL000002 …" value={awb} onChange={(e) => setAwb(e.target.value.toUpperCase())} />
                <Button className="h-12 px-8 bg-[#D4AF37] text-[#0B1E5B] hover:bg-[#D4AF37]/90 font-bold text-base rounded-xl" onClick={() => { setParams({ awb }); search(awb); }} disabled={loading}>Track</Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="container max-w-4xl pb-12 space-y-5 relative">
        {searched && !results.length && !loading && (
          <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur p-6 text-center text-white/70">No shipments found.</div>
        )}
        {results.map(({ shipment, events }) =>
          shipment._missing ? (
            <div key={shipment.awb_number} className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur p-6 text-center text-white/70 text-sm">
              No shipment found with AWB <span className="font-mono font-semibold text-white">{shipment.awb_number}</span>
            </div>
          ) : (
            <ShipmentCard key={shipment.awb_number} shipment={shipment} events={events} onCopy={() => copyLink(shipment.awb_number)} onPod={openPod} />
          )
        )}
      </div>
      <AlertDialog open={!!podGate} onOpenChange={(o) => !o && setPodGate(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Verify you're not a robot</AlertDialogTitle>
            <AlertDialogDescription>Please confirm to view the Proof of Delivery (POD).</AlertDialogDescription>
          </AlertDialogHeader>
          <label className="flex items-center gap-2 text-sm cursor-pointer p-3 rounded-md border bg-muted/50">
            <Checkbox checked={podChecked} onCheckedChange={(v) => setPodChecked(!!v)} />
            I'm not a robot
          </label>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction disabled={!podChecked} onClick={confirmPod}>View POD</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ShipmentCard({ shipment, events, onCopy, onPod }: { shipment: any; events: any[]; onCopy: () => void; onPod: (url: string) => void }) {
  const idx = stageIdx(shipment.status);
  const isDelivered = shipment.status === "delivered";
  const isFailed = shipment.status === "undelivered" || shipment.status === "rto";
  const transportIcon = (shipment.transport_mode || "").toLowerCase().includes("air") ? Plane : Truck;
  const TIcon = transportIcon;
  const pct = isDelivered ? 100 : isFailed ? (idx / (STAGES.length - 1)) * 100 : Math.max(2, (idx / (STAGES.length - 1)) * 100);

  return (
    <div className="rounded-3xl border border-white/15 bg-white/[0.07] backdrop-blur-xl overflow-hidden shadow-2xl text-white">
      {/* Top bar */}
      <div className="bg-gradient-to-r from-[#D4AF37]/20 to-transparent px-5 py-4 flex flex-wrap items-center justify-between gap-3 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center"><PackageSearch className="h-6 w-6 text-[#D4AF37]" /></div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-white/50">AWB Number</div>
            <div className="font-mono font-bold text-lg">{shipment.awb_number}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs font-medium">
            <span className="relative inline-flex h-2 w-2"><span className="absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75 animate-ping"></span><span className="relative rounded-full h-2 w-2 bg-[#D4AF37]"></span></span>
            <span className="uppercase tracking-wider text-[#D4AF37]">Live</span>
          </div>
          <Badge className={`capitalize text-xs px-3 py-1 ${isDelivered ? "bg-green-500/20 text-green-200 border border-green-400/40" : isFailed ? "bg-red-500/20 text-red-200 border border-red-400/40" : "bg-white/10 text-white border border-white/20"}`}>
            {isDelivered ? "Delivered 🎉 Hurray!" : shipment.status.replace(/_/g, " ")}
          </Badge>
          <Button size="sm" variant="outline" className="bg-white/5 border-white/20 text-white hover:bg-white/10 h-8 w-8 p-0" onClick={onCopy}><Copy className="h-3 w-3" /></Button>
          <Button size="sm" variant="outline" className="bg-white/5 border-white/20 text-white hover:bg-white/10 h-8 w-8 p-0" onClick={() => { navigator.share?.({ title: `Track ${shipment.awb_number}`, url: `${window.location.origin}/track?awb=${shipment.awb_number}` }).catch(onCopy); }}><Share2 className="h-3 w-3" /></Button>
        </div>
      </div>

      {/* Progress with moving icon */}
      <div className="px-5 pt-8 pb-5">
        {/* 3D bold rail */}
        <div className="relative">
          {/* base rail with inner shadow */}
          <div className="relative h-3 rounded-full bg-gradient-to-b from-black/40 to-white/10 shadow-[inset_0_2px_4px_rgba(0,0,0,0.6)] overflow-hidden">
            <div
              className={`absolute inset-y-0 left-0 transition-all duration-1000 ease-out rounded-full
                ${isDelivered
                  ? "bg-gradient-to-r from-emerald-300 via-green-400 to-emerald-500 shadow-[0_0_20px_rgba(74,222,128,0.7)]"
                  : isFailed
                  ? "bg-gradient-to-r from-red-400 to-red-600 shadow-[0_0_20px_rgba(239,68,68,0.6)]"
                  : "bg-gradient-to-r from-[#F5D26B] via-[#D4AF37] to-[#9C7E1C] shadow-[0_0_18px_rgba(212,175,55,0.7)]"}`}
              style={{ width: `${pct}%` }}
            >
              {!isDelivered && !isFailed && (
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-[shimmer_2s_linear_infinite]" style={{ backgroundSize: "200% 100%" }} />
              )}
            </div>
            {/* moving vehicle bubble */}
            <div className="absolute -top-2 transition-all duration-1000 ease-out" style={{ left: `calc(${pct}% - 16px)` }}>
              <div className={`h-8 w-8 rounded-full flex items-center justify-center shadow-2xl ring-2 ring-white/30
                ${isDelivered ? "bg-gradient-to-br from-emerald-300 to-green-600 text-white" : isFailed ? "bg-gradient-to-br from-red-400 to-red-700 text-white" : "bg-gradient-to-br from-[#F5D26B] to-[#9C7E1C] text-[#0B1E5B]"}`}>
                {isDelivered ? <CheckCircle2 className="h-5 w-5" /> : isFailed ? <AlertTriangle className="h-5 w-5" /> : <TIcon className="h-4 w-4" />}
              </div>
            </div>
          </div>
          {/* step icons + labels */}
          <div className="grid grid-cols-6 mt-5 gap-1">
            {STAGES.map((s, i) => {
              const done = !isFailed && i <= idx;
              const active = i === idx;
              const failedHere = isFailed && i === idx;
              return (
                <div key={s.key} className="flex flex-col items-center text-center">
                  <div className={`h-9 w-9 rounded-xl flex items-center justify-center transition-all
                    ${done ? "bg-gradient-to-br from-[#F5D26B] to-[#9C7E1C] text-[#0B1E5B] shadow-[0_4px_14px_rgba(212,175,55,0.5)] ring-1 ring-[#D4AF37]/60"
                          : failedHere ? "bg-gradient-to-br from-red-400 to-red-700 text-white shadow-lg"
                          : "bg-white/5 text-white/40 ring-1 ring-white/10"}
                    ${active && !isDelivered && !isFailed ? "scale-110 animate-pulse" : ""}`}>
                    <s.Icon className="h-4 w-4" />
                  </div>
                  <div className={`mt-1.5 text-[10px] uppercase tracking-wider font-extrabold leading-tight
                    ${done ? "text-[#D4AF37] drop-shadow-[0_0_6px_rgba(212,175,55,0.6)]"
                          : failedHere ? "text-red-300"
                          : "text-white/40"}`}>{s.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* From - To */}
      <div className="px-5 pb-5">
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] items-stretch gap-3 mt-2">
          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
            <div className="text-[10px] uppercase tracking-wider text-white/50">From</div>
            <div className="font-semibold text-lg mt-1">{shipment.sender_city || "—"}{shipment.sender_pincode ? ` - ${shipment.sender_pincode}` : ""}</div>
          </div>
          <ArrowRight className="hidden md:block self-center text-[#D4AF37]" />
          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
            <div className="text-[10px] uppercase tracking-wider text-white/50">To — {shipment.receiver_name || "—"}</div>
            <div className="font-semibold text-lg mt-1">{shipment.receiver_city || "—"}{shipment.receiver_pincode ? ` - ${shipment.receiver_pincode}` : ""}</div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-3 text-sm">
          <div className="rounded-xl bg-white/5 border border-white/10 p-2 text-center">
            <div className="text-[10px] uppercase text-white/50">Pieces</div>
            <div className="font-semibold">{shipment.pieces ?? "—"}</div>
          </div>
          <div className="rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 p-2 text-center">
            <div className="text-[10px] uppercase text-white/50 flex items-center justify-center gap-1"><MapPin className="h-3 w-3 text-[#D4AF37]" />Current</div>
            <div className="font-semibold text-[#D4AF37]">{shipment.current_branch_city || shipment.current_branch_name || (isDelivered ? shipment.receiver_city : "—")}</div>
          </div>
          <div className="rounded-xl bg-white/5 border border-white/10 p-2 text-center">
            <div className="text-[10px] uppercase text-white/50">Mode</div>
            <div className="font-semibold">{shipment.transport_mode || "—"}</div>
          </div>
        </div>
      </div>

      {/* Undelivered actions */}
      {isFailed && <UndeliveredActions shipment={shipment} />}

      {/* Delivered hero callout — clickable POD */}
      {isDelivered && (
        <div className="mx-5 mb-5">
          <div onClick={() => shipment.pod_url && onPod(shipment.pod_url)}
            className={`block rounded-2xl p-5 text-center bg-gradient-to-br from-emerald-400/30 via-green-500/20 to-emerald-700/30 border-2 border-emerald-400/50 shadow-[0_0_30px_rgba(74,222,128,0.35)] hover:shadow-[0_0_50px_rgba(74,222,128,0.55)] transition ${shipment.pod_url ? "cursor-pointer" : "cursor-default opacity-90"}`}>
            <div className="inline-flex items-center justify-center h-14 w-14 rounded-2xl bg-emerald-400/30 ring-2 ring-emerald-300/50 mb-2">
              <CheckCircle2 className="h-8 w-8 text-emerald-200" />
            </div>
            <div className="text-2xl md:text-3xl font-black text-emerald-100 tracking-tight uppercase drop-shadow-[0_2px_8px_rgba(34,197,94,0.7)]">Delivered</div>
            {shipment.pod_received_by && <div className="text-sm text-white/80 mt-1">Received by <span className="font-bold text-white">{shipment.pod_received_by}</span>{shipment.delivered_at && ` on ${format(new Date(shipment.delivered_at), "dd MMM yyyy, HH:mm")}`}</div>}
            {shipment.pod_url ? (
              <div className="mt-3 inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-emerald-500 to-green-700 text-white px-5 py-2.5 text-sm font-bold shadow-[0_6px_20px_rgba(16,185,129,0.45)] ring-2 ring-emerald-300/60 hover:shadow-[0_8px_28px_rgba(16,185,129,0.65)] transition">
                <FileImage className="h-4 w-4" /> View Proof of Delivery (POD)
              </div>
            ) : (
              <div className="mt-3 text-xs text-white/60 italic">POD upload pending</div>
            )}
          </div>
        </div>
      )}
      {!isDelivered && shipment.pod_url && (
        <div className="mx-5 mb-5 flex items-center justify-between rounded-xl border border-emerald-400/40 bg-gradient-to-br from-emerald-500/10 to-green-700/10 p-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-emerald-200"><CheckCircle2 className="h-4 w-4" /> Proof of Delivery available</div>
          <button onClick={() => onPod(shipment.pod_url)} className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-br from-emerald-500 to-green-700 text-white px-4 py-2 text-sm font-bold shadow-lg ring-1 ring-emerald-300/50 hover:shadow-xl transition"><FileImage className="h-4 w-4" />View POD</button>
        </div>
      )}

      {/* History */}
      <div className="px-5 pb-5">
        <div className="text-xs uppercase tracking-wider text-white/50 mb-3">Tracking History</div>
        {!events.length ? <div className="text-sm text-white/50">No updates yet.</div> : (
          <ol className="relative border-l-2 border-[#D4AF37]/30 ml-2 space-y-4">
            {events.map((e, i) => (
              <li key={i} className="ml-5">
                <span className={`absolute -left-[9px] flex h-4 w-4 items-center justify-center rounded-full ${i === 0 ? "bg-[#D4AF37] ring-4 ring-[#D4AF37]/20" : e.status === "delivered" ? "bg-green-400" : "bg-white/30"}`}>
                  {e.status === "delivered" && <CheckCircle2 className="h-2.5 w-2.5 text-[#0B1E5B]" />}
                </span>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3 backdrop-blur">
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-semibold capitalize">{e.status.replace(/_/g, " ")}</div>
                    <div className="text-xs text-white/50">{format(new Date(e.event_at), "dd MMM yyyy, HH:mm")}</div>
                  </div>
                  {e.location && <div className="text-sm flex items-center gap-1 text-white/70 mt-1"><MapPin className="h-3 w-3" />{e.location}</div>}
                  {e.undelivered_reason && <div className="text-sm mt-1 text-red-300 font-medium flex items-center gap-1"><AlertTriangle className="h-3 w-3" />Reason: {e.undelivered_reason}</div>}
                  {e.remarks && <div className="text-sm mt-1 text-white/80">{e.remarks}</div>}
                </div>
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  );
}

function UndeliveredActions({ shipment }: { shipment: any }) {
  const [resched, setResched] = useState(false);
  const [selfCollect, setSelfCollect] = useState(false);
  const [rtoOpen, setRtoOpen] = useState(false);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [phone, setPhone] = useState("");
  const [branches, setBranches] = useState<any[]>([]);

  const submit = async (action: string, payload: any = {}) => {
    const { error } = await (supabase as any).from("tracking_actions").insert({
      awb_number: shipment.awb_number,
      shipment_id: shipment.shipment_id,
      action, payload, contact_phone: phone || null,
    });
    if (error) { toast.error(error.message); return false; }
    return true;
  };
  const onReattempt = async () => { if (await submit("reattempt", { note: "Customer requested re-attempt" })) toast.success("Success! Re-attempt requested — our team will reach out."); };
  const onReschedule = async () => {
    if (!date) { toast.error("Pick a date"); return; }
    if (await submit("reschedule", { date, time, note: "Customer requested reschedule" })) { toast.success("Reschedule recorded"); setResched(false); }
  };
  const openSelfCollect = async () => {
    const { data } = await (supabase as any).from("website_branches").select("name,city,address,phone,map_url").eq("active", true);
    setBranches(data ?? []); setSelfCollect(true);
    submit("self_collect", { note: "Customer chose self-collect" });
  };
  const onRto = async () => { if (await submit("rto", { note: "Customer requested return to sender" })) { toast.success("RTO request submitted"); setRtoOpen(false); } };

  const nearest = useMemo(() => branches.find((b) => b.city?.toLowerCase() === (shipment.receiver_city || "").toLowerCase()) || branches[0], [branches, shipment.receiver_city]);

  return (
    <div className="mx-5 mb-4 rounded-xl border border-red-400/30 bg-red-500/10 p-4">
      <div className="text-sm font-semibold text-red-200 mb-1 flex items-center gap-2"><AlertTriangle className="h-4 w-4" />Delivery Failed — Choose an option:</div>
      <div className="text-xs text-white/60 mb-3">Your selection will be sent to our delivery team immediately.</div>
      <Input className="mb-3 bg-white/5 border-white/20 text-white placeholder:text-white/40" placeholder="Your contact phone (optional)" value={phone} onChange={(e) => setPhone(e.target.value)} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <Button onClick={onReattempt} className="bg-blue-500 hover:bg-blue-600 text-white"><RotateCcw className="h-3 w-3 mr-1" />Re-attempt</Button>
        <Button onClick={() => setResched(true)} className="bg-amber-500 hover:bg-amber-600 text-white"><Calendar className="h-3 w-3 mr-1" />Reschedule</Button>
        <Button onClick={openSelfCollect} className="bg-emerald-500 hover:bg-emerald-600 text-white"><Building2 className="h-3 w-3 mr-1" />Self-Collect</Button>
        <Button onClick={() => setRtoOpen(true)} variant="destructive"><AlertTriangle className="h-3 w-3 mr-1" />RTO</Button>
      </div>

      {/* Reschedule */}
      <Dialog open={resched} onOpenChange={setResched}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reschedule Delivery</DialogTitle></DialogHeader>
          <div className="grid gap-3 md:grid-cols-2">
            <div><label className="text-sm font-medium">Preferred Date</label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
            <div><label className="text-sm font-medium">Preferred Time</label><Input type="time" value={time} onChange={(e) => setTime(e.target.value)} /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setResched(false)}>Cancel</Button><Button onClick={onReschedule}>Confirm</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Self-collect */}
      <Dialog open={selfCollect} onOpenChange={setSelfCollect}>
        <DialogContent>
          <DialogHeader><DialogTitle>Self-Collect from Nearest Branch</DialogTitle></DialogHeader>
          {nearest ? (
            <div className="space-y-2 text-sm">
              <div className="font-semibold flex items-center gap-2"><Building2 className="h-4 w-4 text-primary" />{nearest.name}</div>
              <div className="text-muted-foreground">{nearest.address}</div>
              {nearest.phone && <div className="flex items-center gap-2"><Phone className="h-4 w-4" />{nearest.phone}</div>}
              {nearest.map_url && <a href={nearest.map_url} target="_blank" rel="noreferrer" className="text-primary hover:underline inline-block">Open in Maps →</a>}
              <div className="rounded-md bg-muted p-2 text-xs">Please carry valid ID proof and your AWB <span className="font-mono font-semibold">{shipment.awb_number}</span>.</div>
            </div>
          ) : <div className="text-sm text-muted-foreground">No branches configured yet. Call us at <span className="font-semibold">{shipment.receiver_phone || "+91 7352363283"}</span>.</div>}
          <DialogFooter><Button onClick={() => setSelfCollect(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* RTO */}
      <AlertDialog open={rtoOpen} onOpenChange={setRtoOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive">Return Shipment to Sender?</AlertDialogTitle>
            <AlertDialogDescription>This will cancel further delivery attempts and return AWB <span className="font-mono">{shipment.awb_number}</span> to the sender. Are you sure?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onRto} className="bg-destructive">Yes, Return to Sender</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}