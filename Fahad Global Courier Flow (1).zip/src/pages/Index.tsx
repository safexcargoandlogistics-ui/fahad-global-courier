import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Truck, Globe, Phone, Mail, MapPin, ShieldCheck, Clock, Plane, Train, Zap, Building2, Ship, Handshake, PackageCheck, Search, ArrowRight, Sparkles, Box, PackagePlus } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { useSiteContent, SITE_DEFAULTS } from "@/hooks/useSiteContent";
import { SEO } from "@/components/SEO";
import { RateTatCalculator } from "@/components/RateTatCalculator";

export default function Index() {
  const [awb, setAwb] = useState("");
  const nav = useNavigate();
  const [dbBranches, setDbBranches] = useState<any[]>([]);
  const [pinDest, setPinDest] = useState("");
  const [pinResult, setPinResult] = useState<any | "none" | null>(null);
  const { value: cmsHeader } = useSiteContent("header", SITE_DEFAULTS.header);
  const { value: cmsHero } = useSiteContent("hero", SITE_DEFAULTS.hero);
  const { value: cmsContact } = useSiteContent("contact", SITE_DEFAULTS.contact);
  const { value: cmsFooter } = useSiteContent("footer", SITE_DEFAULTS.footer);
  const { value: cmsPartners } = useSiteContent<any[]>("partners", SITE_DEFAULTS.partners as any);
  const { value: cmsAbout } = useSiteContent("about", SITE_DEFAULTS.about);
  const { value: cmsServices } = useSiteContent<any[]>("services", SITE_DEFAULTS.services as any);
  const slides: { url: string; caption?: string }[] = Array.isArray((cmsHero as any)?.slides) ? (cmsHero as any).slides : [];
  const [slideIdx, setSlideIdx] = useState(0);
  useEffect(() => {
    if (slides.length < 2) return;
    const id = setInterval(() => setSlideIdx((i) => (i + 1) % slides.length), Number((cmsHero as any)?.slide_interval_ms || 5000));
    return () => clearInterval(id);
  }, [slides.length, (cmsHero as any)?.slide_interval_ms]);
  useEffect(() => {
    (supabase as any).from("website_branches").select("name,city,state,address,phone,email,contact_person,map_url,image_url").eq("active", true).order("display_order").order("name").then(({ data }: any) => setDbBranches(data ?? []));
  }, []);
  const checkPin = async () => {
    if (!/^\d{6}$/.test(pinDest)) { setPinResult(null); return; }
    const { data } = await (supabase as any).from("pincodes").select("*").eq("pincode", pinDest).maybeSingle();
    setPinResult(data ?? "none");
  };

  const partners = [
    { name: "DHL", color: "text-yellow-400", bg: "bg-red-600" },
    { name: "FedEx", color: "text-purple-700", bg: "bg-white" },
    { name: "Aramex", color: "text-red-600", bg: "bg-white" },
    { name: "UPS", color: "text-yellow-500", bg: "bg-amber-900" },
    { name: "Delhivery", color: "text-red-500", bg: "bg-white" },
    { name: "DTDC", color: "text-blue-700", bg: "bg-white" },
    { name: "Blue Dart", color: "text-blue-800", bg: "bg-white" },
    { name: "TNT", color: "text-orange-500", bg: "bg-white" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEO title="FAHAD GLOBAL LOGISTICS | Courier & Cargo India" description="FAHAD GLOBAL LOGISTICS offers domestic and international courier, cargo, tracking, pickup, DRS and corporate billing services." path="/" jsonLd={{ "@context": "https://schema.org", "@type": "WebSite", name: "FAHAD GLOBAL LOGISTICS", url: "https://www.fahadglobal.com/", potentialAction: { "@type": "SearchAction", target: "https://www.fahadglobal.com/track?awb={search_term_string}", "query-input": "required name=search_term_string" } }} />
      {/* HEADER */}
      <header className="border-b border-white/10 sticky top-0 z-30 backdrop-blur-md bg-[hsl(222_60%_8%/0.85)] text-white">
        <div className="container flex h-16 items-center justify-between gap-2">
          <Link to="/" className="flex items-center gap-2 min-w-0">
            <Logo className="h-10 w-auto shrink-0" />
            <div className="leading-tight hidden sm:block">
              <div className="font-bold text-sm uppercase tracking-wider">FAHAD GLOBAL LOGISTICS</div>
              <div className="text-[10px] uppercase tracking-wider text-white/50">Domestic & International Courier</div>
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-white/80">
            {(cmsHeader as any).nav.map((n: any) => n.url.startsWith("/") ? (
              <Link key={n.label} to={n.url} className="hover:text-accent">{n.label}</Link>
            ) : (
              <a key={n.label} href={n.url} className="hover:text-accent">{n.label}</a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/track"><Button size="sm" variant="outline" className="hidden sm:inline-flex bg-white/5 border-white/20 text-white hover:bg-white/10">Rate &amp; TAT</Button></Link>
            <Link to="/auth"><Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90">Software Login</Button></Link>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section id="home" className="relative overflow-hidden text-white" style={{ background: "var(--gradient-dark-hero)" }}>
        {slides.length > 0 ? (
          <>
            {slides.map((s, i) => (
              <img key={i} src={s.url} alt={s.caption || `Banner ${i + 1}`} className={`absolute inset-0 h-full w-full object-cover object-center pointer-events-none transition-opacity duration-1000 ${i === slideIdx ? "opacity-70 md:opacity-55" : "opacity-0"}`} />
            ))}
            {slides.length > 1 && (
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                {slides.map((_, i) => (
                  <button key={i} aria-label={`Banner ${i + 1}`} onClick={() => setSlideIdx(i)} className={`h-2 rounded-full transition-all ${i === slideIdx ? "w-6 bg-accent" : "w-2 bg-white/40 hover:bg-white/70"}`} />
                ))}
              </div>
            )}
          </>
        ) : (cmsHero as any).banner_url ? (
          <img src={(cmsHero as any).banner_url} alt="FAHAD GLOBAL LOGISTICS courier banner" className="absolute inset-0 h-full w-full object-cover object-center opacity-70 pointer-events-none md:opacity-55" />
        ) : (
          <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
        )}
        {/* animated route line */}
        <svg className="absolute inset-x-0 top-1/2 -translate-y-1/2 w-full h-40 opacity-60 pointer-events-none" viewBox="0 0 1200 200" preserveAspectRatio="none">
          <path d="M-50 150 Q 300 20 600 100 T 1250 60" stroke="hsl(var(--neon-cyan))" strokeWidth="2" fill="none" className="animate-dash" />
        </svg>
        {/* floating icons */}
        <Plane className="hidden md:block absolute top-24 right-[8%] h-12 w-12 text-accent animate-floaty" />
        <Ship className="hidden md:block absolute bottom-16 left-[6%] h-10 w-10 text-cyan-300 animate-floaty" style={{ animationDelay: "1s" }} />
        <Truck className="hidden md:block absolute top-[55%] right-[35%] h-8 w-8 text-white/40 animate-floaty" style={{ animationDelay: "2s" }} />

        <div className="absolute inset-0 bg-[hsl(222_60%_8%/0.42)] md:bg-[hsl(222_60%_8%/0.52)]" />
        <div className="container relative py-16 md:py-24 grid md:grid-cols-12 gap-8 items-center min-h-[calc(100svh-4rem)] md:min-h-[620px]">
          <div className="md:col-span-7">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-medium backdrop-blur"><Sparkles className="h-3.5 w-3.5 text-accent" /> India's trusted multi-modal courier partner</span>
            <h1 className="mt-5 text-5xl md:text-7xl font-black leading-[1.02] tracking-tight">
              {(cmsHero as any).title_line1 || "Move it Faster."}<br/>
              <span className="text-accent text-glow">{(cmsHero as any).title_line2 || "Track it Smarter."}</span>
            </h1>
            <p className="mt-5 text-lg text-white/70 max-w-xl">{(cmsHero as any).subtitle}</p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/pickup"><Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 shadow-[0_8px_30px_-8px_hsl(var(--neon-orange)/0.6)]"><PackagePlus className="mr-1.5 h-4 w-4" />{(cmsHero as any).cta_primary || "Book a Pickup"} <ArrowRight className="ml-1.5 h-4 w-4" /></Button></Link>
              <Link to="/track"><Button size="lg" variant="outline" className="bg-white/5 border-white/25 text-white hover:bg-white/10">{(cmsHero as any).cta_secondary || "Track Shipment"}</Button></Link>
            </div>

            <div className="mt-10 grid grid-cols-3 gap-3 max-w-lg">
              {[
                { k: "200+", v: "Countries" },
                { k: "2", v: "Branches" },
                { k: "24/7", v: "Live Tracking" },
              ].map((s) => (
                <div key={s.v} className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur">
                  <div className="text-2xl font-bold text-accent">{s.k}</div>
                  <div className="text-[11px] uppercase tracking-wider text-white/60">{s.v}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="md:col-span-5">
            <div className="relative rounded-2xl border border-white/15 bg-gradient-to-br from-white/10 to-white/[0.02] p-1 backdrop-blur-xl shadow-2xl neon-border">
              <div className="rounded-2xl bg-[hsl(222_60%_9%/0.85)] p-6">
                <div className="flex items-center gap-2 text-sm text-white/70 mb-3">
                  <Search className="h-4 w-4 text-accent" /> Live Shipment Tracking
                </div>
                <div className="flex flex-col gap-2">
                  <textarea
                    placeholder="Enter one or more AWB e.g. FGL000001, FGL000002"
                    value={awb}
                    onChange={(e) => setAwb(e.target.value)}
                    className="min-h-[60px] rounded-md bg-white/5 border border-white/15 text-white placeholder:text-white/40 focus-visible:ring-2 focus-visible:ring-accent px-3 py-2 text-sm"
                  />
                  <Button onClick={() => awb && nav(`/track?awb=${encodeURIComponent(awb)}`)} className="bg-accent text-accent-foreground hover:bg-accent/90">Track</Button>
                  <p className="text-[11px] text-white/50">Multiple AWB? Separate with comma, space or new line.</p>
                </div>
                <div className="mt-5 grid grid-cols-3 gap-2 text-center text-[11px] text-white/60">
                  {["Booked", "In-Transit", "Delivered"].map((s, i) => (
                    <div key={s} className="rounded-lg border border-white/10 bg-white/5 py-2">
                      <span className={`inline-block h-2 w-2 rounded-full mr-1.5 ${i === 1 ? "bg-accent animate-pulse-dot" : "bg-cyan-400"}`} />
                      {s}
                    </div>
                  ))}
                </div>
                <p className="mt-4 text-[11px] text-white/50">Live data is connected directly to our courier software.</p>
              </div>
            </div>
          </div>
        </div>

        {/* moving marquee */}
        <div className="relative overflow-hidden border-y border-white/10 bg-black/30 py-3">
          <div className="flex gap-12 whitespace-nowrap animate-slide text-white/40 uppercase text-xs tracking-[0.3em]">
            {Array.from({ length: 2 }).map((_, k) => (
              <div key={k} className="flex gap-12">
                <span>✈ Air Express</span><span>🚂 Rail Cargo</span><span>🚢 Sea Freight</span><span>🚚 Road Express</span><span>🌐 International</span><span>📦 Same Day</span><span>💼 Bill Booking</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="container py-20">
        <div className="text-center mb-12">
          <span className="inline-block text-xs uppercase tracking-[0.3em] text-accent font-semibold">What we do</span>
          <h2 className="text-4xl font-bold mt-2">Logistics built for <span className="text-primary">every shipment</span></h2>
          <p className="text-muted-foreground mt-3 max-w-xl mx-auto">From a single envelope to multi-tonne corporate consignments — we have the right service.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-5">
          {(Array.isArray(cmsServices) && cmsServices.length ? cmsServices : SITE_DEFAULTS.services).map((f: any, idx: number) => {
            const ICONS: Record<string, any> = { Zap, Truck, Plane, Train, Globe, PackageCheck, Ship, Building2, Box };
            const IconComp = ICONS[f.icon] || PackageCheck;
            const color = f.color || "from-primary to-accent";
            return (
              <div key={(f.title || "svc") + idx} className="group relative rounded-2xl border bg-card p-6 shadow-sm hover:shadow-xl transition overflow-hidden">
                <div className={`absolute -right-12 -top-12 h-36 w-36 rounded-full bg-gradient-to-br ${color} opacity-10 group-hover:opacity-25 transition`} />
                {f.logo ? (
                  <img src={f.logo} alt={f.title} className="relative h-14 w-14 object-contain rounded-xl bg-white border p-1 shadow-lg" />
                ) : (
                  <div className={`relative inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${color} text-white shadow-lg`}>
                    <IconComp className="h-6 w-6" />
                  </div>
                )}
                <h3 className="font-semibold mt-4 text-lg">{f.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{f.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* NETWORK */}
      <section id="network" className="relative py-20 text-white overflow-hidden" style={{ background: "var(--gradient-dark-hero)" }}>
        <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
        <div className="container relative">
          <div className="text-center mb-12">
            <span className="inline-block text-xs uppercase tracking-[0.3em] text-accent font-semibold">Multi-Modal</span>
            <h2 className="text-4xl font-bold mt-2">By Air. By Sea. By Rail. By Road.</h2>
            <p className="text-white/60 mt-3">One partner — every mode of transport.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
            <Link to="/track" className="group relative rounded-2xl border border-white/10 bg-white/[0.06] p-6 text-center hover:bg-white/[0.10] transition">
              <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-600 text-white shadow-xl group-hover:scale-110 transition"><Search className="h-8 w-8" /></div>
              <div className="font-semibold">Track Shipment</div>
              <div className="text-xs text-white/50 mt-1">Live AWB status</div>
            </Link>
            <Link to="/track" className="group relative rounded-2xl border border-white/10 bg-white/[0.06] p-6 text-center hover:bg-white/[0.10] transition">
              <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-700 text-white shadow-xl group-hover:scale-110 transition"><Clock className="h-8 w-8" /></div>
              <div className="font-semibold">Rate &amp; TAT Calculator</div>
              <div className="text-xs text-white/50 mt-1">Rate + delivery time</div>
            </Link>
            {[
              { icon: Plane, label: "By Air", sub: "1–3 days", color: "from-sky-400 to-indigo-600" },
              { icon: Ship, label: "By Sea", sub: "Bulk freight", color: "from-cyan-400 to-blue-700" },
              { icon: Train, label: "By Rail", sub: "Cost saving", color: "from-amber-400 to-orange-600" },
              { icon: Truck, label: "By Road", sub: "Door-to-door", color: "from-emerald-400 to-green-700" },
            ].map((m) => (
              <div key={m.label} className="group relative rounded-2xl border border-white/10 bg-white/[0.04] p-6 text-center hover:bg-white/[0.08] transition">
                <div className={`mx-auto mb-3 h-16 w-16 rounded-2xl bg-gradient-to-br ${m.color} flex items-center justify-center text-white shadow-xl group-hover:scale-110 transition`}>
                  <m.icon className="h-8 w-8" />
                </div>
                <div className="font-semibold">{m.label}</div>
                <div className="text-xs text-white/50 mt-1">{m.sub}</div>
              </div>
            ))}
          </div>
          <div className="mt-6 mx-auto max-w-2xl text-foreground">
            <RateTatCalculator compact />
          </div>
        </div>
      </section>

      {/* PARTNERS */}
      <section className="bg-muted/40 py-16 border-y">
        <div className="container">
          <div className="text-center mb-8">
            <Handshake className="mx-auto h-8 w-8 text-primary mb-2" />
            <h2 className="text-3xl font-bold">Our Delivery Partners</h2>
            <p className="text-muted-foreground mt-2">We work with India's & world's most trusted courier networks</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 lg:grid-cols-8 gap-3">
            {((cmsPartners as any[])?.length ? (cmsPartners as any[]) : partners).map((p: any, i: number) => (
              <div key={p.name + i} className={`rounded-lg border bg-white h-20 flex items-center justify-center font-extrabold text-base text-foreground shadow-sm hover:shadow-lg hover:scale-105 transition overflow-hidden ${p.color ?? ""}`}>
                {p.logo ? <img src={p.logo} alt={p.name} className="max-h-14 max-w-[80%] object-contain" /> : p.name}
              </div>
            ))}
          </div>
          <p className="text-center text-xs text-muted-foreground mt-4">All listed brands are trademarks of their respective owners. They are our delivery partners for last-mile and international routing.</p>
        </div>
      </section>

      {/* ABOUT US */}
      <section id="about" className="container py-20">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <span className="inline-block text-xs uppercase tracking-[0.3em] text-accent font-semibold">Who we are</span>
            <h2 className="text-4xl font-bold mt-2">{(cmsAbout as any).title}</h2>
          </div>
          <div className="prose prose-neutral max-w-none text-muted-foreground whitespace-pre-line text-[15px] leading-relaxed">
            {(cmsAbout as any).body}
          </div>
        </div>
      </section>

      {/* BRANCHES */}
      <section id="branches" className="container py-20">
        <div className="text-center mb-12">
          <span className="inline-block text-xs uppercase tracking-[0.3em] text-accent font-semibold">Reach us</span>
          <h2 className="text-4xl font-bold mt-2">Our Branch Network</h2>
          <p className="text-muted-foreground mt-2">Live list of branches managed from our admin panel.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(dbBranches.length ? dbBranches : [
            { name: "Head Office", city: "Ghaziabad", state: "UP", address: "Shop No 01, Ground Floor, Main Thapar Gate Road, Vandana Vihar, Khora Colony, Ghaziabad, UP 201020", phone: "7352363283 / 9711522296", email: "info@fahadglobal.com" },
            { name: "Delhi Branch", city: "New Delhi", state: "Delhi", address: "F 30/5, Opp HDFC Bank, Okhla Industrial Estate Phase II, New Delhi 110020", phone: "7352363283 / 9711522296", email: "info@fahadglobal.com" },
          ]).map((b: any, i: number) => (
            <div key={`${b.name}-${i}`} className="rounded-2xl border bg-card p-6 shadow-sm hover:shadow-xl transition">
              {b.image_url && <img src={b.image_url} alt={b.name} className="w-full h-32 object-cover rounded-lg mb-3" />}
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Building2 className="h-5 w-5" /></div>
                <div>
                  <div className="font-bold text-lg">{b.name}</div>
                  <div className="text-xs text-muted-foreground">{[b.city, b.state].filter(Boolean).join(", ")}</div>
                </div>
              </div>
              {b.address && <p className="text-sm text-muted-foreground mt-3 flex items-start gap-2"><MapPin className="h-4 w-4 mt-0.5 shrink-0 text-primary" /> {b.address}</p>}
              {b.contact_person && <p className="text-sm mt-2 flex items-center gap-2"><span className="text-xs uppercase text-muted-foreground">Contact:</span> {b.contact_person}</p>}
              {b.phone && <p className="text-sm text-muted-foreground mt-1 flex items-center gap-2"><Phone className="h-4 w-4 text-primary" /> {b.phone}</p>}
              {b.email && <p className="text-sm text-muted-foreground mt-1 flex items-center gap-2"><Mail className="h-4 w-4 text-primary" /> {b.email}</p>}
              {b.map_url && <a href={b.map_url} target="_blank" rel="noreferrer" className="text-sm text-primary hover:underline mt-2 inline-block">View on Map →</a>}
            </div>
          ))}
        </div>
        <div className="mt-10 max-w-2xl mx-auto rounded-2xl border bg-gradient-to-br from-primary/5 to-accent/5 p-6">
          <div className="text-center mb-4">
            <h3 className="text-xl font-bold">Check Pincode Serviceability</h3>
            <p className="text-sm text-muted-foreground">Enter destination pincode to check delivery availability, transit time and COD.</p>
          </div>
          <div className="flex gap-2">
            <Input placeholder="Enter 6-digit pincode" maxLength={6} value={pinDest} onChange={(e) => setPinDest(e.target.value.replace(/\D/g, ""))} />
            <Button onClick={checkPin}>Check</Button>
            <Link to="/pincode-check"><Button variant="outline">Full Check</Button></Link>
          </div>
          {pinResult === "none" && <p className="text-sm text-destructive mt-3">❌ Pincode not in our serviceable list. Contact us for special arrangements.</p>}
          {pinResult && pinResult !== "none" && (
            <div className={`mt-3 rounded-md p-3 text-sm ${pinResult.serviceable ? "bg-success/10 text-success-foreground" : "bg-destructive/10"}`}>
              {pinResult.serviceable ? "✅ Serviceable" : "❌ Not Serviceable"} — {pinResult.city}, {pinResult.state} • TAT {pinResult.tat_days}d • COD {pinResult.cod_available ? "Available" : "No"}
            </div>
          )}
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="relative py-20 text-white" style={{ background: "var(--gradient-dark-hero)" }}>
        <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
        <div className="container relative grid md:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-4xl font-bold">Let's move your shipment.</h2>
            <p className="text-white/70 mt-3">Need a pickup or have a query? Our team is ready to help.</p>
            <div className="mt-6 space-y-3 text-sm">
              <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-accent" /> {(cmsContact as any).phone}</p>
              <p className="flex items-center gap-2"><Mail className="h-4 w-4 text-accent" /> {(cmsContact as any).email}</p>
              <p className="flex items-center gap-2"><Globe className="h-4 w-4 text-accent" /> {(cmsContact as any).web}</p>
              <p className="flex items-center gap-2"><Clock className="h-4 w-4 text-accent" /> {(cmsContact as any).hours}</p>
              <p className="flex items-start gap-2"><MapPin className="h-4 w-4 text-accent mt-0.5 shrink-0" /> {(cmsContact as any).address}</p>
            </div>
          </div>
          <Card className="bg-white/5 border-white/15 backdrop-blur text-white">
            <CardContent className="pt-6 space-y-3">
              <h3 className="font-semibold">Quick Pickup Request</h3>
              <p className="text-sm text-white/70">Login to your account to schedule pickups and manage shipments.</p>
              <div className="flex gap-2">
                <Link to="/auth" className="flex-1"><Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">Customer Login</Button></Link>
                <Link to="/auth" className="flex-1"><Button variant="outline" className="w-full bg-white/5 border-white/20 text-white hover:bg-white/10">Staff / Admin</Button></Link>
              </div>
              <p className="text-xs text-white/50">Or call us directly to book your shipment.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t bg-card">
        <div className="container py-10 grid md:grid-cols-4 gap-6 text-sm">
          <div>
            <Logo className="h-12 w-auto mb-2" />
            <div className="font-bold">{(cmsHeader as any).brand}</div>
            <p className="text-muted-foreground text-xs mt-1">{(cmsFooter as any).tagline}</p>
            <p className="text-muted-foreground text-xs mt-2">GSTIN: {(cmsFooter as any).gstin}</p>
          </div>
          <div>
            <div className="font-semibold mb-2">Head Office</div>
            <p className="text-muted-foreground text-xs flex items-start gap-1"><MapPin className="h-3.5 w-3.5 mt-0.5 shrink-0" />Shop No 01, Ground Floor, Main Thapar Gate Road, Vandana Vihar, Khora Colony, Ghaziabad, UP 201020</p>
          </div>
          <div>
            <div className="font-semibold mb-2">Delhi Branch</div>
            <p className="text-muted-foreground text-xs flex items-start gap-1"><MapPin className="h-3.5 w-3.5 mt-0.5 shrink-0" />F 30/5, Opp HDFC Bank, Okhla Industrial Estate Phase II, New Delhi 110020</p>
          </div>
          <div className="space-y-1.5">
            <div className="font-semibold mb-2">Contact</div>
            <p className="flex items-center gap-2 text-muted-foreground text-xs"><Phone className="h-3.5 w-3.5" /> {(cmsContact as any).phone}</p>
            <p className="flex items-center gap-2 text-muted-foreground text-xs"><Mail className="h-3.5 w-3.5" /> {(cmsContact as any).email}</p>
            <p className="flex items-center gap-2 text-muted-foreground text-xs"><Globe className="h-3.5 w-3.5" /> {(cmsContact as any).web}</p>
          </div>
        </div>
        <div className="border-t py-4 text-center text-xs text-muted-foreground">{(cmsFooter as any).copyright}</div>
      </footer>
    </div>
  );
}
