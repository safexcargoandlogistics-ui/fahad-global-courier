import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { Checkbox } from "@/components/ui/checkbox";
import { generateAwbDocket, generateStickerLabel } from "@/lib/awbLabel";
import { PageHeader } from "@/components/PageHeader";
import { COUNTRIES } from "@/data/countries";
import { DEFAULT_CARD, ClientRateCard, computeBilling, loadClientCard, detectService as detectServiceCard } from "@/lib/clientRates";
import { IndiaPostPicker } from "@/components/IndiaPostPicker";
import { lookupIndiaPostPincode } from "@/lib/indiaPostLocations";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const SERVICE_OPTIONS = [
  "Local Standard",
  "Local Next Business Day",
  "Local SameDay",
  "Next Business Day",
  "SameDay",
  "Overnight",
  "Road Express",
  "Standard Air",
  "Express",
  "Economy",
];
const TRANSPORT_MODES = ["Air", "Train", "Road", "Sea"];

const empty = {
  awb_number: "", reference_no: "", client_id: "", mode: "domestic", transport_mode: "Air", service_type: "Standard Air", payment_mode: "prepaid", bill_booking: false,
  origin_branch_id: "", destination_branch_id: "", current_branch_id: "",
  sender_name: "", sender_phone: "", sender_address: "", sender_city: "", sender_pincode: "",
  receiver_name: "", receiver_phone: "", receiver_address: "", receiver_city: "", receiver_state: "", receiver_pincode: "", receiver_country: "India",
  pieces: 1, length_cm: 0, width_cm: 0, height_cm: 0, volumetric_divisor: 5000,
  actual_weight: 0, volumetric_weight: 0, chargeable_weight: 0, contents: "", declared_value: 0,
  freight: 0, rate_per_kg: 0, zone_label: "", fov_charge: 0, insurance_charge: 0, oth_charge: 0, oda_charge: 0, fuel_charge: 0, fuel_pct: 40, gst_pct: 18, fov_applied: true, oda_applied: false, insurance_applied: false, other_charges: 0, gst: 0, total_amount: 0, sub_total: 0, charges_total: 0, cod_amount: 0, remarks: "",
  invoice_no: "", eway_bill_no: "", eway_bill_data: null as any, distance_km: 0,
};
type Box = { l: number; w: number; h: number; wt: number; qty: number };
const blankBox = (): Box => ({ l: 0, w: 0, h: 0, wt: 0, qty: 1 });
const nowLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };

export default function Booking() {
  const [f, setF] = useState<any>(empty);
  const [boxes, setBoxes] = useState<Box[]>([blankBox()]);
  const [bookingAt, setBookingAt] = useState<string>(nowLocal());
  const [clients, setClients] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [awbStyle, setAwbStyle] = useState<"digital" | "manual">("digital");
  const [awbCheck, setAwbCheck] = useState<{ checking: boolean; exists: boolean | null }>({ checking: false, exists: null });
  const [chargeableManual, setChargeableManual] = useState(false);
  const [totalManual, setTotalManual] = useState(false);
  const [rateManual, setRateManual] = useState(false);
  const [ewayLoading, setEwayLoading] = useState(false);
  const [pinLookup, setPinLookup] = useState(false);
  const [clientCard, setClientCard] = useState<ClientRateCard>(DEFAULT_CARD);
  const [intlOpen, setIntlOpen] = useState(false);
  const [intl, setIntl] = useState<any>({ network: "DHL", reference: "", network_awb: "", tracking_link: "", invoice_value: "", incoterm: "DDP", hs_code: "", commodity: "" });
  const nav = useNavigate();

  useEffect(() => {
    supabase.from("clients").select("id,name,client_code,contact_person,phone,address,city,state,pincode,gstin").eq("active", true).order("name").then(({ data }) => setClients(data ?? []));
    (supabase as any).from("branches").select("id,branch_code,name,city").eq("active", true).order("name").then(({ data }: any) => setBranches(data ?? []));
  }, []);

  // Auto-open international dialog when mode switches to international
  useEffect(() => {
    if (f.mode === "international" && !f.eway_bill_data?.international) {
      setIntlOpen(true);
    }
  }, [f.mode]);

  // Pick or auto-create a branch from a worldwide city/pincode and assign it to a side
  const pickWorldwideBranch = async (side: "origin" | "destination", loc: { city: string; state?: string; pincode?: string; country?: string }) => {
    const code = (loc.pincode || loc.city || "BR").toString().replace(/\s+/g, "").toUpperCase().slice(0, 18) || `BR${Date.now()}`;
    let existing: any = null;
    if (loc.pincode) {
      const { data } = await (supabase as any).from("branches").select("id,branch_code,name,city").eq("pincode", loc.pincode).maybeSingle();
      existing = data;
    }
    if (!existing) {
      const { data } = await (supabase as any).from("branches").select("id,branch_code,name,city").eq("city", loc.city).maybeSingle();
      existing = data;
    }
    let branchId = existing?.id as string | undefined;
    if (!branchId) {
      const ins = await (supabase as any).from("branches").insert({
        branch_code: code,
        name: `${loc.city} Branch`,
        city: loc.city, state: loc.state || "", pincode: loc.pincode || "",
        address: [loc.city, loc.state, loc.country].filter(Boolean).join(", "),
        active: true,
      }).select("id,branch_code,name,city").single();
      if (ins.error) { toast.error(ins.error.message); return; }
      branchId = ins.data.id;
      setBranches((prev) => [...prev, ins.data]);
    } else {
      setBranches((prev) => prev.find((b) => b.id === existing.id) ? prev : [...prev, existing]);
    }
    if (side === "origin") set("origin_branch_id", branchId!);
    else set("destination_branch_id", branchId!);
    toast.success(`${side === "origin" ? "Origin" : "Destination"}: ${loc.city}${loc.pincode ? ` - ${loc.pincode}` : ""}`);
  };

  // Auto-fill sender details when a client is picked
  useEffect(() => {
    if (!f.client_id) return;
    const c = clients.find((x) => x.id === f.client_id);
    if (!c) return;
    setF((p: any) => ({
      ...p,
      sender_name: p.sender_name || c.name || "",
      sender_phone: p.sender_phone || c.phone || "",
      sender_address: p.sender_address || c.address || "",
      sender_city: p.sender_city || c.city || "",
      sender_pincode: p.sender_pincode || c.pincode || "",
    }));
  }, [f.client_id, clients]);

  // Load this client's rate master (per-customer quotation)
  useEffect(() => {
    if (!f.client_id) { setClientCard(DEFAULT_CARD); return; }
    setTotalManual(false);
    setRateManual(false);
    loadClientCard(f.client_id).then(setClientCard);
  }, [f.client_id]);

  useEffect(() => {
    const div = Number(f.volumetric_divisor) || 5000;
    // Aggregate strictly from box rows
    const totalActual = boxes.reduce((a, b) => a + (b.wt * (b.qty || 1)), 0);
    const totalPieces = boxes.reduce((a, b) => a + (b.qty || 1), 0) || 1;
    const totalLBH = boxes.reduce((a, b) => a + (b.l * b.w * b.h * (b.qty || 1)), 0);
    const maxL = Math.max(0, ...boxes.map((b) => Number(b.l || 0)));
    const maxW = Math.max(0, ...boxes.map((b) => Number(b.w || 0)));
    const maxH = Math.max(0, ...boxes.map((b) => Number(b.h || 0)));
    const totalVol = totalLBH / div;
    const volRounded = Math.round(totalVol * 1000) / 1000;
    const service = detectServiceCard(f.service_type);
    // Use the client's quotation (or DEFAULT_CARD if none saved). Exact city match,
    // otherwise REST OF INDIA fallback — handled inside computeBilling.
    const cube = totalLBH > 0 ? Math.cbrt(totalLBH) : 0;
    const r = computeBilling(clientCard, {
      service,
      city: f.receiver_city,
      state: f.receiver_state,
      actualWeight: totalActual,
      lengthCm: cube, widthCm: cube, heightCm: cube,
      declaredValue: Number(f.declared_value || 0),
      fovApplied: !!f.fov_applied,
      odaApplied: !!f.oda_applied,
      insuranceApplied: !!f.insurance_applied,
      otherCharges: Number(f.oth_charge || 0),
      fuelPctOverride: f.fuel_pct ? Number(f.fuel_pct) : undefined,
      gstPctOverride: f.gst_pct ? Number(f.gst_pct) : undefined,
      rateOverride: rateManual ? Number(f.rate_per_kg || 0) || undefined : undefined,
    });
    // Override volumetric with exact L×B×H/divisor (autoBill recomputes via cube root for spec parity)
    const cw = chargeableManual ? Number(f.chargeable_weight || r.billableWeight) : Math.max(r.billableWeight, volRounded);
    setF((p: any) => ({
      ...p,
      pieces: totalPieces,
      length_cm: maxL,
      width_cm: maxW,
      height_cm: maxH,
      actual_weight: totalActual,
      volumetric_weight: volRounded,
      chargeable_weight: cw,
      zone_label: `${r.zone}${r.matched === "rest-of-india" ? " (REST OF INDIA)" : ""}`,
      rate_per_kg: totalManual ? p.rate_per_kg : r.rate,
      freight: totalManual ? p.freight : r.freight,
      fov_charge: totalManual ? p.fov_charge : r.fov,
      insurance_charge: totalManual ? p.insurance_charge : r.insurance,
      oda_charge: totalManual ? p.oda_charge : r.oda,
      charges_total: totalManual ? p.charges_total : r.total,
      fuel_charge: totalManual ? p.fuel_charge : r.fuel,
      sub_total: totalManual ? p.sub_total : r.subTotal,
      other_charges: r.fov + r.insurance + r.oda + Number(f.oth_charge || 0),
      gst: totalManual ? p.gst : r.gst,
      total_amount: totalManual ? p.total_amount : r.grandTotal.toFixed(2),
    }));
  }, [f.volumetric_divisor, f.transport_mode, f.service_type, f.receiver_city, f.receiver_state, f.declared_value, f.oth_charge, f.fov_applied, f.oda_applied, f.insurance_applied, f.fuel_pct, f.gst_pct, f.rate_per_kg, chargeableManual, totalManual, rateManual, boxes, clientCard]);

  // Pincode lookup (postalpincode.in free API) — fills city/state on entering pincode
  const lookupPincode = async (pin: string, target: "sender" | "receiver") => {
    if (!/^\d{6}$/.test(pin)) return;
    setPinLookup(true);
    try {
      const po = await lookupIndiaPostPincode(pin);
      if (po) {
        if (target === "sender") setF((p: any) => ({ ...p, sender_city: po.city || p.sender_city }));
        else setF((p: any) => ({ ...p, receiver_city: po.city || p.receiver_city, receiver_state: po.state || p.receiver_state }));
      }
    } catch (e) { /* ignore */ }
    setPinLookup(false);
  };

  // Real pincode→pincode distance via zippopotam.us geocoding + Haversine (×1.3 road factor)
  useEffect(() => {
    const a = (f.sender_pincode || "").trim();
    const b = (f.receiver_pincode || "").trim();
    if (!/^\d{6}$/.test(a) || !/^\d{6}$/.test(b)) return;
    if (a === b) { setF((p: any) => ({ ...p, distance_km: 5 })); return; }
    let cancelled = false;
    (async () => {
      try {
        const [r1, r2] = await Promise.all([
          fetch(`https://api.zippopotam.us/in/${a}`).then((r) => r.ok ? r.json() : null).catch(() => null),
          fetch(`https://api.zippopotam.us/in/${b}`).then((r) => r.ok ? r.json() : null).catch(() => null),
        ]);
        const p1 = r1?.places?.[0]; const p2 = r2?.places?.[0];
        if (!p1 || !p2 || cancelled) return;
        const lat1 = +p1.latitude, lon1 = +p1.longitude, lat2 = +p2.latitude, lon2 = +p2.longitude;
        const toRad = (d: number) => d * Math.PI / 180;
        const R = 6371;
        const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1);
        const ah = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
        const crow = 2 * R * Math.asin(Math.sqrt(ah));
        const km = Math.round(crow * 1.3); // road factor
        if (!cancelled) setF((p: any) => ({ ...p, distance_km: km }));
      } catch { /* ignore */ }
    })();
    return () => { cancelled = true; };
  }, [f.sender_pincode, f.receiver_pincode]);

  const lookupEway = async () => {
    const code = (f.eway_bill_no || "").trim();
    if (!/^\d{12}$/.test(code)) { toast.error("E-Way Bill must be 12 digits"); return; }
    setEwayLoading(true);
    // Government E-Way API requires GSP credentials — we capture the number and basic metadata; enrichment can be added later.
    setF((p: any) => ({ ...p, eway_bill_data: { ewb_no: code, captured_at: new Date().toISOString() } }));
    setEwayLoading(false);
    toast.success("E-Way Bill number saved. Auto-enrichment requires GSP credentials.");
  };

  // Live duplicate AWB check while admin types a manual AWB
  useEffect(() => {
    const code = (f.awb_number || "").trim().toUpperCase();
    if (!code || awbStyle !== "manual") { setAwbCheck({ checking: false, exists: null }); return; }
    setAwbCheck({ checking: true, exists: null });
    const t = setTimeout(async () => {
      const { data } = await supabase.from("shipments").select("id").eq("awb_number", code).maybeSingle();
      setAwbCheck({ checking: false, exists: !!data });
    }, 350);
    return () => clearTimeout(t);
  }, [f.awb_number, awbStyle]);

  const set = (k: string, v: any) => setF((p: any) => ({ ...p, [k]: v }));
  const n = (v: any) => Number(v || 0);
  const manualCharge = (patch: Record<string, any>) => {
    setTotalManual(true);
    setF((p: any) => {
      const x = { ...p, ...patch };
      const charges = patch.charges_total !== undefined ? n(x.charges_total) : n(x.freight) + n(x.fov_charge) + n(x.insurance_charge) + n(x.oda_charge) + n(x.oth_charge);
      const fuel = patch.fuel_charge !== undefined ? n(x.fuel_charge) : charges * (n(x.fuel_pct) / 100);
      const sub = patch.sub_total !== undefined ? n(x.sub_total) : charges + fuel;
      const gst = patch.gst !== undefined ? n(x.gst) : sub * (n(x.gst_pct) / 100);
      return { ...x, charges_total: +charges.toFixed(2), fuel_charge: +fuel.toFixed(2), sub_total: +sub.toFixed(2), gst: +gst.toFixed(2), total_amount: +(sub + gst).toFixed(2), other_charges: +(n(x.fov_charge) + n(x.insurance_charge) + n(x.oda_charge) + n(x.oth_charge)).toFixed(2) };
    });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true);
    const payload: any = { ...f };
    delete payload.fov_charge; delete payload.oth_charge; delete payload.oda_charge; delete payload.insurance_charge;
    delete payload.fuel_pct; delete payload.gst_pct; delete payload.fov_applied; delete payload.oda_applied; delete payload.insurance_applied;
    delete payload.rate_per_kg; delete payload.zone_label; delete payload.sub_total; delete payload.charges_total;
    if (awbStyle === "digital" || !payload.awb_number) delete payload.awb_number;
    if (awbStyle === "manual" && awbCheck.exists) { toast.error("This AWB is already booked"); setSaving(false); return; }
    if (!payload.client_id) delete payload.client_id;
    if (!payload.origin_branch_id) delete payload.origin_branch_id;
    if (!payload.destination_branch_id) delete payload.destination_branch_id;
    payload.current_branch_id = payload.origin_branch_id || payload.current_branch_id || null;
    const { data: { user } } = await supabase.auth.getUser();
    payload.created_by = user?.id;
    const ts = new Date(bookingAt);
    payload.booking_date = ts.toISOString().slice(0,10);
    const { data, error } = await supabase.from("shipments").insert(payload).select().single();
    if (error) {
      const msg = error.message?.includes("shipments_awb_unique") ? "This AWB number is already booked" : error.message;
      toast.error(msg); setSaving(false); return;
    }
    await supabase.from("tracking_events").insert({ shipment_id: data.id, status: "booked", location: data.sender_city, remarks: "Shipment booked", created_by: user?.id, event_at: ts.toISOString() });
    toast.success(`Booked ${data.awb_number}`);
    nav("/app/shipments");
    return data;
  };

  const submitAndPrint = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true);
    const payload: any = { ...f };
    delete payload.fov_charge; delete payload.oth_charge; delete payload.oda_charge; delete payload.insurance_charge;
    delete payload.fuel_pct; delete payload.gst_pct; delete payload.fov_applied; delete payload.oda_applied; delete payload.insurance_applied;
    delete payload.rate_per_kg; delete payload.zone_label; delete payload.sub_total; delete payload.charges_total;
    if (awbStyle === "digital" || !payload.awb_number) delete payload.awb_number;
    if (awbStyle === "manual" && awbCheck.exists) { toast.error("This AWB is already booked"); setSaving(false); return; }
    if (!payload.client_id) delete payload.client_id;
    if (!payload.origin_branch_id) delete payload.origin_branch_id;
    if (!payload.destination_branch_id) delete payload.destination_branch_id;
    payload.current_branch_id = payload.origin_branch_id || payload.current_branch_id || null;
    const { data: { user } } = await supabase.auth.getUser();
    payload.created_by = user?.id;
    const ts = new Date(bookingAt);
    payload.booking_date = ts.toISOString().slice(0, 10);
    const { data, error } = await supabase.from("shipments").insert(payload).select().single();
    if (error) {
      const msg = error.message?.includes("shipments_awb_unique") ? "This AWB number is already booked" : error.message;
      toast.error(msg); setSaving(false); return;
    }
    await supabase.from("tracking_events").insert({ shipment_id: data.id, status: "booked", location: data.sender_city, remarks: "Shipment booked", created_by: user?.id, event_at: ts.toISOString() });
    toast.success(`Booked ${data.awb_number} — printing…`);
    try { await generateAwbDocket(data); await generateStickerLabel(data); } catch (err) { console.error(err); }
    nav("/app/shipments");
  };

  return (
    <form onSubmit={submit} className="space-y-4 max-w-6xl">
      <PageHeader title="New Shipment Booking" subtitle="Branch-wise booking with auto weight, rate and GST calculation" />

      <Card><CardHeader><CardTitle>Shipment Details</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-4">
          <div className="md:col-span-2">
            <Label>AWB Number</Label>
            <div className="flex gap-2 mb-1">
              <label className="flex items-center gap-1 text-xs cursor-pointer"><Checkbox checked={awbStyle === "digital"} onCheckedChange={() => setAwbStyle("digital")} /> Digital (auto)</label>
              <label className="flex items-center gap-1 text-xs cursor-pointer"><Checkbox checked={awbStyle === "manual"} onCheckedChange={() => setAwbStyle("manual")} /> Manual docket</label>
            </div>
            <Input value={f.awb_number} onChange={(e) => set("awb_number", e.target.value.toUpperCase())} placeholder={awbStyle === "digital" ? "Will be auto-generated" : "Enter manual docket no"} disabled={awbStyle === "digital"} />
            {awbStyle === "manual" && f.awb_number && (
              <div className={`text-xs mt-1 ${awbCheck.exists ? "text-destructive" : awbCheck.exists === false ? "text-success" : "text-muted-foreground"}`}>
                {awbCheck.checking ? "Checking…" : awbCheck.exists ? "❌ Already booked" : awbCheck.exists === false ? "✅ Available" : ""}
              </div>
            )}
          </div>
          <div><Label>Reference No</Label><Input value={f.reference_no} onChange={(e) => set("reference_no", e.target.value)} /></div>
          <div><Label>Booking Date & Time (back-date allowed)</Label><Input type="datetime-local" value={bookingAt} onChange={(e) => setBookingAt(e.target.value)} /></div>
          <div><Label>Invoice No</Label><Input value={f.invoice_no} onChange={(e) => set("invoice_no", e.target.value)} placeholder="INV/2026/00001" /></div>
          <div className="md:col-span-2">
            <Label>E-Way Bill No (12 digits)</Label>
            <div className="flex gap-2">
              <Input value={f.eway_bill_no} onChange={(e) => set("eway_bill_no", e.target.value.replace(/\D/g, "").slice(0, 12))} placeholder="123456789012" />
              <Button type="button" variant="outline" onClick={lookupEway} disabled={ewayLoading}>{ewayLoading ? "…" : "Capture"}</Button>
            </div>
            {f.eway_bill_data?.ewb_no && <div className="text-xs text-success mt-1">EWB captured: {f.eway_bill_data.ewb_no}</div>}
          </div>
          <div><Label>Client</Label>
            <Select value={f.client_id} onValueChange={(v) => set("client_id", v)}>
              <SelectTrigger><SelectValue placeholder="Select client" /></SelectTrigger>
              <SelectContent>{clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.client_code} — {c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Mode</Label>
            <Select value={f.mode} onValueChange={(v) => set("mode", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="domestic">Domestic</SelectItem><SelectItem value="international">International</SelectItem></SelectContent>
            </Select>
          </div>
          <div><Label>Transport</Label>
            <Select value={f.transport_mode} onValueChange={(v) => set("transport_mode", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{TRANSPORT_MODES.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Service</Label>
            <Select value={f.service_type} onValueChange={(v) => { setTotalManual(false); setRateManual(false); set("service_type", v); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{SERVICE_OPTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Origin Branch</Label>
            <Select value={f.origin_branch_id} onValueChange={(v) => set("origin_branch_id", v)}>
              <SelectTrigger><SelectValue placeholder="Select branch" /></SelectTrigger>
              <SelectContent>{branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.branch_code} — {b.city}</SelectItem>)}</SelectContent>
            </Select>
            <div className="mt-1"><IndiaPostPicker placeholder="…or pick any city worldwide" onSelect={(loc) => pickWorldwideBranch("origin", loc)} /></div>
          </div>
          <div>
            <Label>Destination Branch</Label>
            <Select value={f.destination_branch_id} onValueChange={(v) => set("destination_branch_id", v)}>
              <SelectTrigger><SelectValue placeholder="Select branch" /></SelectTrigger>
              <SelectContent>{branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.branch_code} — {b.city}</SelectItem>)}</SelectContent>
            </Select>
            <div className="mt-1"><IndiaPostPicker placeholder="…or pick any city worldwide" onSelect={(loc) => pickWorldwideBranch("destination", loc)} /></div>
          </div>
          <div><Label>Payment</Label>
            <Select value={f.payment_mode} onValueChange={(v) => set("payment_mode", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="prepaid">Prepaid</SelectItem>
                <SelectItem value="topay">To Pay</SelectItem>
                <SelectItem value="cod">COD</SelectItem>
                <SelectItem value="credit">Credit</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end gap-2 md:col-span-4">
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <Checkbox checked={f.bill_booking} onCheckedChange={(v) => set("bill_booking", !!v)} /> Bill Booking (add to client invoice)
            </label>
            {f.mode === "international" && (
              <Button type="button" variant="outline" size="sm" onClick={() => setIntlOpen(true)}>
                International Details {f.eway_bill_data?.international ? "✓" : ""}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={intlOpen} onOpenChange={setIntlOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>International Shipment Details</DialogTitle></DialogHeader>
          <div className="grid gap-3">
            <div><Label>Network</Label>
              <Select value={intl.network} onValueChange={(v) => setIntl({ ...intl, network: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{["DHL","FEDEX","ARAMEX","UPS","TNT","Delhivery International","Other"].map((n) => <SelectItem key={n} value={n}>{n}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Reference No</Label><Input value={intl.reference} onChange={(e) => setIntl({ ...intl, reference: e.target.value })} /></div>
              <div><Label>Network AWB</Label><Input value={intl.network_awb} onChange={(e) => setIntl({ ...intl, network_awb: e.target.value })} /></div>
              <div className="col-span-2"><Label>Tracking URL</Label><Input value={intl.tracking_link} onChange={(e) => setIntl({ ...intl, tracking_link: e.target.value })} placeholder="https://" /></div>
              <div><Label>Invoice Value (USD)</Label><Input type="number" value={intl.invoice_value} onChange={(e) => setIntl({ ...intl, invoice_value: e.target.value })} /></div>
              <div><Label>Incoterm</Label>
                <Select value={intl.incoterm} onValueChange={(v) => setIntl({ ...intl, incoterm: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["DDP","DDU","DAP","EXW","FOB","CIF"].map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>HS Code</Label><Input value={intl.hs_code} onChange={(e) => setIntl({ ...intl, hs_code: e.target.value })} /></div>
              <div><Label>Commodity</Label><Input value={intl.commodity} onChange={(e) => setIntl({ ...intl, commodity: e.target.value })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIntlOpen(false)}>Cancel</Button>
            <Button onClick={() => { setF((p: any) => ({ ...p, eway_bill_data: { ...(p.eway_bill_data || {}), international: intl } })); setIntlOpen(false); toast.success("International details saved"); }}>Save Details</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="grid gap-4 md:grid-cols-2">
        <Card><CardHeader><CardTitle>Sender</CardTitle></CardHeader>
          <CardContent className="grid gap-3">
            <Input required placeholder="Name *" value={f.sender_name} onChange={(e) => set("sender_name", e.target.value)} />
            <Input placeholder="Phone" value={f.sender_phone} onChange={(e) => set("sender_phone", e.target.value)} />
            <Textarea placeholder="Address" value={f.sender_address} onChange={(e) => set("sender_address", e.target.value)} />
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1"><IndiaPostPicker value={f.sender_city} onSelect={(loc) => setF((p: any) => ({ ...p, sender_city: loc.city, sender_pincode: loc.pincode }))} /><Input placeholder="City" value={f.sender_city} onChange={(e) => set("sender_city", e.target.value)} /></div>
              <Input placeholder="Pincode" value={f.sender_pincode} onChange={(e) => { set("sender_pincode", e.target.value); if (/^\d{6}$/.test(e.target.value)) lookupPincode(e.target.value, "sender"); }} />
            </div>
          </CardContent></Card>
        <Card><CardHeader><CardTitle>Receiver</CardTitle></CardHeader>
          <CardContent className="grid gap-3">
            <Input required placeholder="Name *" value={f.receiver_name} onChange={(e) => set("receiver_name", e.target.value)} />
            <Input placeholder="Phone" value={f.receiver_phone} onChange={(e) => set("receiver_phone", e.target.value)} />
            <Textarea placeholder="Address" value={f.receiver_address} onChange={(e) => set("receiver_address", e.target.value)} />
            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1"><IndiaPostPicker value={f.receiver_city} onSelect={(loc) => { setTotalManual(false); setRateManual(false); setF((p: any) => ({ ...p, receiver_city: loc.city, receiver_state: loc.state, receiver_pincode: loc.pincode })); }} /><Input required placeholder="City *" value={f.receiver_city} onChange={(e) => { setTotalManual(false); setRateManual(false); set("receiver_city", e.target.value); }} /></div>
              <Input placeholder="State" value={f.receiver_state} onChange={(e) => set("receiver_state", e.target.value)} />
              <Input required placeholder="Pin *" value={f.receiver_pincode} onChange={(e) => { set("receiver_pincode", e.target.value); if (/^\d{6}$/.test(e.target.value)) lookupPincode(e.target.value, "receiver"); }} />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Destination Country (worldwide)</label>
              <select className="w-full h-10 rounded-md border bg-background px-3 text-sm" value={f.receiver_country} onChange={(e) => { const v = e.target.value; set("receiver_country", v); if (v && v !== "India") set("mode", "international"); else set("mode", "domestic"); }}>
                {COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </CardContent></Card>
      </div>

      <Card><CardHeader><CardTitle>Parcel</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-6">
          <div><Label>Pieces (auto)</Label><Input type="number" min={1} readOnly value={f.pieces} /></div>
          <div><Label>Actual Wt (auto)</Label><Input type="number" step="0.001" readOnly value={f.actual_weight} /></div>
          <div><Label>Divisor</Label><Input type="number" value={f.volumetric_divisor} onChange={(e) => set("volumetric_divisor", +e.target.value)} /></div>
          <div className="md:col-span-3"></div>
          <div className="md:col-span-6 border rounded-md p-3 bg-muted/30">
            <div className="flex items-center justify-between mb-2">
              <Label className="text-sm font-semibold">Box Dimensions (press Enter on Wt to add next box)</Label>
              <Button type="button" size="sm" variant="outline" onClick={() => setBoxes([...boxes, blankBox()])}>+ Add Box</Button>
            </div>
            <div className="grid gap-1">
              <div className="grid grid-cols-12 gap-2 text-[10px] text-muted-foreground"><div className="col-span-1">#</div><div className="col-span-2">L cm</div><div className="col-span-2">W cm</div><div className="col-span-2">H cm</div><div className="col-span-2">Wt kg</div><div className="col-span-2">Qty</div><div className="col-span-1"></div></div>
              {boxes.map((b, i) => (
                <div key={i} className="grid grid-cols-12 gap-2">
                  <div className="col-span-1 text-sm font-mono pt-2">{i + 1}</div>
                  <Input className="col-span-2 h-8" type="number" step="0.01" value={b.l} onChange={(e) => setBoxes(boxes.map((x, k) => k === i ? { ...x, l: +e.target.value } : x))} />
                  <Input className="col-span-2 h-8" type="number" step="0.01" value={b.w} onChange={(e) => setBoxes(boxes.map((x, k) => k === i ? { ...x, w: +e.target.value } : x))} />
                  <Input className="col-span-2 h-8" type="number" step="0.01" value={b.h} onChange={(e) => setBoxes(boxes.map((x, k) => k === i ? { ...x, h: +e.target.value } : x))} />
                  <Input className="col-span-2 h-8" type="number" step="0.001" value={b.wt} onChange={(e) => setBoxes(boxes.map((x, k) => k === i ? { ...x, wt: +e.target.value } : x))}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); if (i === boxes.length - 1) setBoxes([...boxes, blankBox()]); } }} />
                  <Input className="col-span-2 h-8" type="number" min={1} value={b.qty} onChange={(e) => setBoxes(boxes.map((x, k) => k === i ? { ...x, qty: +e.target.value } : x))} />
                  <Button type="button" size="icon" variant="ghost" className="col-span-1 h-8" onClick={() => setBoxes(boxes.length > 1 ? boxes.filter((_, k) => k !== i) : boxes)}>×</Button>
                </div>
              ))}
            </div>
          </div>
          <div><Label>Volumetric Wt</Label><Input readOnly value={f.volumetric_weight} /></div>
          <div>
            <div className="flex items-center justify-between"><Label>Chargeable Wt</Label>
              <label className="flex items-center gap-1 text-[10px] cursor-pointer"><Checkbox checked={chargeableManual} onCheckedChange={(v) => setChargeableManual(!!v)} /> Manual</label>
            </div>
            <Input type="number" step="0.001" readOnly={!chargeableManual} className="font-bold" value={f.chargeable_weight} onChange={(e) => set("chargeable_weight", +e.target.value)} />
          </div>
          <div><Label>Declared Value</Label><Input type="number" step="0.01" value={f.declared_value} onChange={(e) => set("declared_value", +e.target.value)} /></div>
          <div><Label>Distance (km)</Label><Input type="number" step="0.1" value={f.distance_km} onChange={(e) => set("distance_km", +e.target.value)} placeholder="auto" /></div>
          <div className="md:col-span-6"><Label>Contents</Label><Input value={f.contents} onChange={(e) => set("contents", e.target.value)} /></div>
        </CardContent></Card>

      <Card><CardHeader><CardTitle>Charges</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-6">
          <div className="md:col-span-6 flex items-center justify-end">
            <label className="flex items-center gap-2 text-xs cursor-pointer"><Checkbox checked={totalManual} onCheckedChange={(v) => setTotalManual(!!v)} /> Manual rate / total (disable auto-calc)</label>
          </div>
          <div className="md:col-span-6 flex flex-wrap gap-4 text-xs">
            <label className="flex items-center gap-1 cursor-pointer"><Checkbox checked={!!f.fov_applied} onCheckedChange={(v) => set("fov_applied", !!v)} /> FOV Applicable</label>
            <label className="flex items-center gap-1 cursor-pointer"><Checkbox checked={!!f.oda_applied} onCheckedChange={(v) => set("oda_applied", !!v)} /> ODA Applicable</label>
            <label className="flex items-center gap-1 cursor-pointer"><Checkbox checked={!!f.insurance_applied} onCheckedChange={(v) => set("insurance_applied", !!v)} /> Insurance</label>
            <div className="text-muted-foreground">Zone / Match: <span className="font-semibold text-foreground">{f.zone_label || "—"}</span></div>
            <div className="text-muted-foreground">Rate ₹/kg: <span className="font-semibold text-foreground">{Number(f.rate_per_kg||0).toFixed(2)}</span></div>
          </div>
          <div><Label>Rate ₹/kg <span className="text-[10px] text-muted-foreground">(manual override)</span></Label><Input type="number" step="0.01" value={f.rate_per_kg} onChange={(e) => { setRateManual(true); setTotalManual(false); set("rate_per_kg", +e.target.value); }} /></div>
          <div><Label>Freight</Label><Input type="number" step="0.01" value={f.freight} onChange={(e) => manualCharge({ freight: +e.target.value })} /></div>
          <div><Label>FOV (Risk)</Label><Input type="number" step="0.01" value={f.fov_charge} onChange={(e) => manualCharge({ fov_charge: +e.target.value })} /></div>
          <div><Label>Insurance</Label><Input type="number" step="0.01" value={f.insurance_charge} onChange={(e) => manualCharge({ insurance_charge: +e.target.value })} /></div>
          <div><Label>OTH (Other)</Label><Input type="number" step="0.01" value={f.oth_charge} onChange={(e) => totalManual ? manualCharge({ oth_charge: +e.target.value }) : set("oth_charge", +e.target.value)} /></div>
          <div><Label>ODA</Label><Input type="number" step="0.01" value={f.oda_charge} onChange={(e) => manualCharge({ oda_charge: +e.target.value })} /></div>
          <div><Label>Total (F+FOV+Ins+ODA+OTH)</Label><Input type="number" step="0.01" className="font-semibold" value={Number(f.charges_total||0).toFixed(2)} onChange={(e) => manualCharge({ charges_total: +e.target.value })} /></div>
          <div><Label>Fuel %</Label><Input type="number" step="0.01" value={f.fuel_pct} onChange={(e) => totalManual ? manualCharge({ fuel_pct: +e.target.value }) : set("fuel_pct", +e.target.value)} /></div>
          <div><Label>Fuel ₹</Label><Input type="number" step="0.01" value={f.fuel_charge} onChange={(e) => manualCharge({ fuel_charge: +e.target.value })} /></div>
          <div><Label>Sub Total</Label><Input type="number" step="0.01" className="font-semibold" value={Number(f.sub_total||0).toFixed(2)} onChange={(e) => manualCharge({ sub_total: +e.target.value })} /></div>
          <div><Label>GST %</Label><Input type="number" step="0.01" value={f.gst_pct} onChange={(e) => totalManual ? manualCharge({ gst_pct: +e.target.value }) : set("gst_pct", +e.target.value)} /></div>
          <div><Label>GST ₹</Label><Input type="number" step="0.01" value={f.gst} onChange={(e) => manualCharge({ gst: +e.target.value })} /></div>
          <div><Label>COD Amount</Label><Input type="number" step="0.01" value={f.cod_amount} onChange={(e) => set("cod_amount", +e.target.value)} /></div>
          <div className="md:col-span-2"><Label>Grand Total (editable)</Label><Input type="number" step="0.01" className="font-bold text-lg text-primary" value={f.total_amount} onChange={(e) => { setTotalManual(true); set("total_amount", e.target.value); }} /></div>
          <div className="md:col-span-6"><Label>Remarks</Label><Textarea value={f.remarks} onChange={(e) => set("remarks", e.target.value)} /></div>
          <div className="md:col-span-6 flex flex-wrap justify-end gap-2 pt-2 border-t">
            <Button type="submit" size="lg" disabled={saving}>{saving ? "Saving…" : "Save Booking"}</Button>
            <Button type="button" size="lg" variant="secondary" disabled={saving} onClick={(e) => submitAndPrint(e as any)}>{saving ? "…" : "Save & Print Docket + Sticker"}</Button>
          </div>
        </CardContent></Card>
    </form>
  );
}
