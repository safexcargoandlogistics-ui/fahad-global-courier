import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trash2, Plus, Download, Calculator } from "lucide-react";
import { DEFAULT_QUOTATION, generateQuotationPDF, computeFreight, type QuotationData } from "@/lib/quotationPdf";
import { PageHeader } from "@/components/PageHeader";
import { toast } from "sonner";

export default function Quotation() {
  const [q, setQ] = useState<QuotationData>({ ...DEFAULT_QUOTATION });
  const upd = <K extends keyof QuotationData>(k: K, v: QuotationData[K]) => setQ(p => ({ ...p, [k]: v }));

  // Live demo calculator
  const [demo, setDemo] = useState({ mode: "AIR" as "AIR"|"SURFACE"|"LOCAL", city: "Mumbai", actualKg: 10, l: 30, b: 20, h: 15, declaredValue: 5000 });

  const result = useMemo(() => {
    let ratePerKg = q.airRestRate, minW = q.airMinWeight, volDiv = q.volAirDiv;
    if (demo.mode === "AIR") {
      const c = q.airCities.find(c => c.city.toLowerCase() === demo.city.toLowerCase());
      ratePerKg = c?.rate ?? q.airRestRate;
      minW = q.airMinWeight; volDiv = q.volAirDiv;
    } else if (demo.mode === "SURFACE") {
      const z = q.surfaceZones.find(z => z.locations.toLowerCase().includes(demo.city.toLowerCase()));
      ratePerKg = z?.rate ?? 50; minW = q.surfaceMinWeight; volDiv = q.volSurfaceDiv;
    } else {
      const c = q.localCities.find(c => c.city.toLowerCase() === demo.city.toLowerCase());
      ratePerKg = c?.rate ?? 50; minW = 0.5; volDiv = q.volAirDiv;
    }
    const f = computeFreight({ mode: demo.mode as any, actualKg: demo.actualKg, l: demo.l, b: demo.b, h: demo.h, ratePerKg, minWeight: minW, volDiv });
    const fov = q.fovEnabled ? Math.max(demo.declaredValue * q.fovPct / 100, q.fovMin) : 0;
    const ins = q.insuranceEnabled ? Math.max(demo.declaredValue * q.insurancePct / 100, q.insuranceMin) : 0;
    const fuel = f.freight * q.fuelPct / 100;
    const sub = f.freight + fov + ins + fuel;
    const gst = sub * q.gstPct / 100;
    return { ...f, ratePerKg, fov, ins, fuel, sub, gst, grand: sub + gst };
  }, [demo, q]);

  const addRow = <K extends keyof QuotationData>(key: K, row: any) => upd(key, [...(q[key] as any[]), row] as any);
  const delRow = <K extends keyof QuotationData>(key: K, i: number) => upd(key, (q[key] as any[]).filter((_, idx) => idx !== i) as any);
  const editRow = <K extends keyof QuotationData>(key: K, i: number, patch: any) => upd(key, (q[key] as any[]).map((r, idx) => idx === i ? { ...r, ...patch } : r) as any);

  return (
    <div className="space-y-4 p-4">
      <PageHeader title="Quotation Builder" subtitle="Client-wise quotation matching Fahad Global format. Everything editable." />
      <div className="flex gap-2">
        <Button onClick={() => generateQuotationPDF(q)} className="gap-2"><Download className="h-4 w-4" />Download PDF</Button>
        <Button variant="outline" onClick={() => { setQ({ ...DEFAULT_QUOTATION }); toast.success("Reset to defaults"); }}>Reset</Button>
      </div>

      <Tabs defaultValue="client">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="client">Client</TabsTrigger>
          <TabsTrigger value="intro">Intro & Services</TabsTrigger>
          <TabsTrigger value="terms">Terms</TabsTrigger>
          <TabsTrigger value="air">AIR Rates</TabsTrigger>
          <TabsTrigger value="surface">Surface</TabsTrigger>
          <TabsTrigger value="metro">Metro & Local</TabsTrigger>
          <TabsTrigger value="charges">Charges</TabsTrigger>
          <TabsTrigger value="calc">Freight Calculator</TabsTrigger>
        </TabsList>

        <TabsContent value="client">
          <Card><CardContent className="grid md:grid-cols-2 gap-3 pt-4">
            <div><Label>Date</Label><Input value={q.date} onChange={e=>upd("date", e.target.value)} /></div>
            <div><Label>Company Name</Label><Input value={q.companyName} onChange={e=>upd("companyName", e.target.value)} /></div>
            <div className="md:col-span-2"><Label>Address</Label><Textarea value={q.address} onChange={e=>upd("address", e.target.value)} /></div>
            <div><Label>Kind Attn (Name + Phone)</Label><Input value={q.kindAttn} onChange={e=>upd("kindAttn", e.target.value)} /></div>
            <div><Label>GSTIN/UIN</Label><Input value={q.gstin} onChange={e=>upd("gstin", e.target.value)} /></div>
            <div><Label>PAN/IT NO</Label><Input value={q.pan} onChange={e=>upd("pan", e.target.value)} /></div>
            <div><Label>State Name</Label><Input value={q.stateName} onChange={e=>upd("stateName", e.target.value)} /></div>
            <div><Label>Place of Supply</Label><Input value={q.placeOfSupply} onChange={e=>upd("placeOfSupply", e.target.value)} /></div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="intro">
          <Card><CardContent className="space-y-3 pt-4">
            <div><Label>Intro Paragraph</Label><Textarea rows={6} value={q.intro} onChange={e=>upd("intro", e.target.value)} /></div>
            <div>
              <div className="flex items-center justify-between mb-2"><Label>Service Offerings</Label>
                <Button size="sm" variant="outline" onClick={() => upd("serviceOfferings", [...q.serviceOfferings, "New service"])}><Plus className="h-3 w-3"/>Add</Button>
              </div>
              {q.serviceOfferings.map((s, i) => (
                <div key={i} className="flex gap-2 mb-2">
                  <Input value={s} onChange={e => upd("serviceOfferings", q.serviceOfferings.map((x,j)=>j===i?e.target.value:x))} />
                  <Button size="icon" variant="ghost" onClick={() => upd("serviceOfferings", q.serviceOfferings.filter((_,j)=>j!==i))}><Trash2 className="h-4 w-4"/></Button>
                </div>
              ))}
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="terms">
          <Card><CardContent className="space-y-4 pt-4">
            {(["tat","commercialTerms","paymentTerms"] as const).map(key => (
              <div key={key}>
                <div className="flex items-center justify-between mb-2"><Label className="capitalize">{key.replace(/([A-Z])/g," $1")}</Label>
                  <Button size="sm" variant="outline" onClick={() => upd(key, [...(q[key] as string[]), "New item"])}><Plus className="h-3 w-3"/>Add</Button>
                </div>
                {(q[key] as string[]).map((s,i) => (
                  <div key={i} className="flex gap-2 mb-2">
                    <Input value={s} onChange={e => upd(key, (q[key] as string[]).map((x,j)=>j===i?e.target.value:x))} />
                    <Button size="icon" variant="ghost" onClick={() => upd(key, (q[key] as string[]).filter((_,j)=>j!==i))}><Trash2 className="h-4 w-4"/></Button>
                  </div>
                ))}
              </div>
            ))}
            <div><Label>Liability Clause</Label><Textarea rows={4} value={q.liability} onChange={e=>upd("liability", e.target.value)} /></div>
            <div><Label>Claims Policy</Label><Textarea rows={3} value={q.claims} onChange={e=>upd("claims", e.target.value)} /></div>
            <div><Label>Onboarding</Label><Textarea rows={3} value={q.onboarding} onChange={e=>upd("onboarding", e.target.value)} /></div>
            <div>
              <div className="flex items-center justify-between mb-2"><Label>Extra Terms</Label>
                <Button size="sm" variant="outline" onClick={() => upd("extraTerms", [...q.extraTerms, ""])}><Plus className="h-3 w-3"/>Add</Button>
              </div>
              {q.extraTerms.map((s,i)=>(
                <div key={i} className="flex gap-2 mb-2">
                  <Input value={s} onChange={e=>upd("extraTerms", q.extraTerms.map((x,j)=>j===i?e.target.value:x))} />
                  <Button size="icon" variant="ghost" onClick={()=>upd("extraTerms", q.extraTerms.filter((_,j)=>j!==i))}><Trash2 className="h-4 w-4"/></Button>
                </div>
              ))}
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="air">
          <Card><CardHeader><CardTitle className="flex items-center justify-between text-base">AIR Cities
            <Button size="sm" variant="outline" onClick={() => addRow("airCities", { city: "New City", rate: 100 })}><Plus className="h-3 w-3"/>Add City</Button>
          </CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {q.airCities.map((c,i)=>(
              <div key={i} className="flex gap-2 items-end">
                <div className="flex-1"><Label>City</Label><Input value={c.city} onChange={e=>editRow("airCities", i, { city: e.target.value })}/></div>
                <div className="w-32"><Label>Rate ₹/kg</Label><Input type="number" value={c.rate} onChange={e=>editRow("airCities", i, { rate: +e.target.value })}/></div>
                <Button size="icon" variant="ghost" onClick={()=>delRow("airCities", i)}><Trash2 className="h-4 w-4"/></Button>
              </div>
            ))}
            <div className="grid grid-cols-2 gap-3 pt-3 border-t">
              <div><Label>Min Chargeable Weight (kg)</Label><Input type="number" value={q.airMinWeight} onChange={e=>upd("airMinWeight", +e.target.value)} /></div>
              <div><Label>Rest of India Rate ₹/kg</Label><Input type="number" value={q.airRestRate} onChange={e=>upd("airRestRate", +e.target.value)} /></div>
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="surface">
          <Card><CardHeader><CardTitle className="flex items-center justify-between text-base">Surface Zones
            <Button size="sm" variant="outline" onClick={() => addRow("surfaceZones", { region: "New", locations: "", rate: 40, tat: "3-5 Days" })}><Plus className="h-3 w-3"/>Add Zone</Button>
          </CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {q.surfaceZones.map((z,i)=>(
              <div key={i} className="grid grid-cols-12 gap-2 items-end">
                <div className="col-span-2"><Label>Region</Label><Input value={z.region} onChange={e=>editRow("surfaceZones", i, { region: e.target.value })}/></div>
                <div className="col-span-6"><Label>Locations</Label><Input value={z.locations} onChange={e=>editRow("surfaceZones", i, { locations: e.target.value })}/></div>
                <div className="col-span-1"><Label>Rate</Label><Input type="number" value={z.rate} onChange={e=>editRow("surfaceZones", i, { rate: +e.target.value })}/></div>
                <div className="col-span-2"><Label>TAT</Label><Input value={z.tat} onChange={e=>editRow("surfaceZones", i, { tat: e.target.value })}/></div>
                <Button size="icon" variant="ghost" onClick={()=>delRow("surfaceZones", i)}><Trash2 className="h-4 w-4"/></Button>
              </div>
            ))}
            <div className="pt-3 border-t"><Label>Min Chargeable Weight (kg)</Label><Input type="number" value={q.surfaceMinWeight} onChange={e=>upd("surfaceMinWeight", +e.target.value)} /></div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="metro">
          <Card><CardHeader><CardTitle className="text-base">Metro Same-Day / Overnight</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <Button size="sm" variant="outline" onClick={() => addRow("metro", { weight: "", sameDay: "", overnight: "" })}><Plus className="h-3 w-3"/>Add Tier</Button>
            {q.metro.map((m,i)=>(
              <div key={i} className="grid grid-cols-12 gap-2 items-end">
                <div className="col-span-5"><Label>Weight Slab</Label><Input value={m.weight} onChange={e=>editRow("metro", i, { weight: e.target.value })}/></div>
                <div className="col-span-3"><Label>Same Day</Label><Input value={m.sameDay} onChange={e=>editRow("metro", i, { sameDay: e.target.value })}/></div>
                <div className="col-span-3"><Label>Overnight</Label><Input value={m.overnight} onChange={e=>editRow("metro", i, { overnight: e.target.value })}/></div>
                <Button size="icon" variant="ghost" onClick={()=>delRow("metro", i)}><Trash2 className="h-4 w-4"/></Button>
              </div>
            ))}
            <div className="grid grid-cols-3 gap-3 pt-3 border-t">
              <div><Label>Min Weight (kg)</Label><Input type="number" value={q.metroMinWeight} onChange={e=>upd("metroMinWeight", +e.target.value)} /></div>
              <div><Label>Airlines Direct Charge ₹</Label><Input type="number" value={q.airlinesDirect} onChange={e=>upd("airlinesDirect", +e.target.value)} /></div>
              <div><Label>Metro Cities List</Label><Input value={q.metroCities} onChange={e=>upd("metroCities", e.target.value)} /></div>
            </div>
          </CardContent></Card>

          <Card className="mt-4"><CardHeader><CardTitle className="text-base">Local NCR Rates</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => { addRow("localCities", { city: "New", rate: 50 }); addRow("localPriorityRates", { city: "New", rate: 200 }); }}><Plus className="h-3 w-3"/>Add City</Button>
            </div>
            {q.localCities.map((c,i)=>(
              <div key={i} className="grid grid-cols-12 gap-2 items-end">
                <div className="col-span-5"><Label>City</Label><Input value={c.city} onChange={e=>{editRow("localCities", i, { city: e.target.value }); editRow("localPriorityRates", i, { city: e.target.value });}}/></div>
                <div className="col-span-3"><Label>Standard ₹</Label><Input type="number" value={c.rate} onChange={e=>editRow("localCities", i, { rate: +e.target.value })}/></div>
                <div className="col-span-3"><Label>Priority ₹</Label><Input type="number" value={q.localPriorityRates[i]?.rate || 0} onChange={e=>editRow("localPriorityRates", i, { rate: +e.target.value })}/></div>
                <Button size="icon" variant="ghost" onClick={()=>{delRow("localCities", i); delRow("localPriorityRates", i);}}><Trash2 className="h-4 w-4"/></Button>
              </div>
            ))}
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="charges">
          <Card><CardContent className="space-y-4 pt-4">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div><Label className="text-base">Insurance (Optional)</Label><p className="text-xs text-muted-foreground">If insured through Fahad Global</p></div>
              <Switch checked={q.insuranceEnabled} onCheckedChange={v=>upd("insuranceEnabled", v)} />
            </div>
            {q.insuranceEnabled && (
              <div className="grid grid-cols-2 gap-3 pl-4">
                <div><Label>Insurance %</Label><Input type="number" step="0.1" value={q.insurancePct} onChange={e=>upd("insurancePct", +e.target.value)}/></div>
                <div><Label>Min Rs.</Label><Input type="number" value={q.insuranceMin} onChange={e=>upd("insuranceMin", +e.target.value)}/></div>
              </div>
            )}
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div><Label className="text-base">FOV (Optional)</Label><p className="text-xs text-muted-foreground">If consignor insures the consignment</p></div>
              <Switch checked={q.fovEnabled} onCheckedChange={v=>upd("fovEnabled", v)} />
            </div>
            {q.fovEnabled && (
              <div className="grid grid-cols-2 gap-3 pl-4">
                <div><Label>FOV %</Label><Input type="number" step="0.1" value={q.fovPct} onChange={e=>upd("fovPct", +e.target.value)}/></div>
                <div><Label>Min Rs.</Label><Input type="number" value={q.fovMin} onChange={e=>upd("fovMin", +e.target.value)}/></div>
              </div>
            )}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 pt-3 border-t">
              <div><Label>Fuel %</Label><Input type="number" value={q.fuelPct} onChange={e=>upd("fuelPct", +e.target.value)}/></div>
              <div><Label>ODA ₹/kg</Label><Input type="number" value={q.odaPerKg} onChange={e=>upd("odaPerKg", +e.target.value)}/></div>
              <div><Label>ODA Min ₹</Label><Input type="number" value={q.odaMin} onChange={e=>upd("odaMin", +e.target.value)}/></div>
              <div><Label>Vol Divisor (AIR)</Label><Input type="number" value={q.volAirDiv} onChange={e=>upd("volAirDiv", +e.target.value)}/></div>
              <div><Label>Vol Divisor (SURFACE)</Label><Input type="number" value={q.volSurfaceDiv} onChange={e=>upd("volSurfaceDiv", +e.target.value)}/></div>
              <div><Label>GST %</Label><Input type="number" value={q.gstPct} onChange={e=>upd("gstPct", +e.target.value)}/></div>
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="calc">
          <Card><CardHeader><CardTitle className="text-base flex items-center gap-2"><Calculator className="h-4 w-4"/>Live Freight Calculator</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div><Label>Mode</Label>
                <select className="h-10 w-full rounded-md border border-input bg-background px-3" value={demo.mode} onChange={e=>setDemo({...demo, mode: e.target.value as any})}>
                  <option value="AIR">AIR</option><option value="SURFACE">SURFACE</option><option value="LOCAL">LOCAL</option>
                </select>
              </div>
              <div><Label>Destination City</Label><Input value={demo.city} onChange={e=>setDemo({...demo, city: e.target.value})}/></div>
              <div><Label>Actual Weight (kg)</Label><Input type="number" value={demo.actualKg} onChange={e=>setDemo({...demo, actualKg: +e.target.value})}/></div>
              <div><Label>Declared Value ₹</Label><Input type="number" value={demo.declaredValue} onChange={e=>setDemo({...demo, declaredValue: +e.target.value})}/></div>
              <div><Label>L (cm)</Label><Input type="number" value={demo.l} onChange={e=>setDemo({...demo, l: +e.target.value})}/></div>
              <div><Label>B (cm)</Label><Input type="number" value={demo.b} onChange={e=>setDemo({...demo, b: +e.target.value})}/></div>
              <div><Label>H (cm)</Label><Input type="number" value={demo.h} onChange={e=>setDemo({...demo, h: +e.target.value})}/></div>
            </div>
            <div className="rounded-lg border bg-muted/30 p-4 space-y-1 text-sm font-mono">
              <div className="flex justify-between"><span>Rate ₹/kg</span><span className="font-bold">₹ {result.ratePerKg}</span></div>
              <div className="flex justify-between"><span>Volumetric Weight</span><span>{result.volumetric} kg</span></div>
              <div className="flex justify-between text-primary"><span>Chargeable Weight (max)</span><span className="font-bold">{result.chargeable} kg</span></div>
              <hr className="my-2"/>
              <div className="flex justify-between"><span>Freight</span><span>₹ {result.freight.toFixed(2)}</span></div>
              {q.fovEnabled && <div className="flex justify-between"><span>FOV ({q.fovPct}%)</span><span>₹ {result.fov.toFixed(2)}</span></div>}
              {q.insuranceEnabled && <div className="flex justify-between"><span>Insurance ({q.insurancePct}%)</span><span>₹ {result.ins.toFixed(2)}</span></div>}
              <div className="flex justify-between"><span>Fuel ({q.fuelPct}%)</span><span>₹ {result.fuel.toFixed(2)}</span></div>
              <div className="flex justify-between font-semibold"><span>Sub Total</span><span>₹ {result.sub.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>GST ({q.gstPct}%)</span><span>₹ {result.gst.toFixed(2)}</span></div>
              <div className="flex justify-between text-base font-bold text-primary border-t pt-1"><span>Grand Total</span><span>₹ {result.grand.toFixed(2)}</span></div>
            </div>
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}