import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Trash2 } from "lucide-react";

export default function Users() {
  const { isAdmin } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [nu, setNu] = useState({ email: "", password: "", full_name: "", phone: "", role: "staff", branch_id: "" });
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const { data: profiles } = await supabase.from("profiles").select("id,full_name,phone,branch_id");
    const { data: roles } = await supabase.from("user_roles").select("user_id,role");
    setUsers((profiles ?? []).map((p) => ({ ...p, roles: (roles ?? []).filter((r) => r.user_id === p.id).map((r) => r.role) })));
    const { data: b } = await (supabase as any).from("branches").select("id,branch_code,city,name").order("name");
    setBranches(b ?? []);
  };
  useEffect(() => { if (isAdmin) load(); }, [isAdmin]);

  const createUser = async () => {
    if (!nu.email || !nu.password) { toast.error("Email and password required"); return; }
    setBusy(true);
    const { data, error } = await supabase.functions.invoke("admin-create-user", {
      body: { action: "create", ...nu, branch_id: nu.branch_id || null },
    });
    setBusy(false);
    if (error || (data as any)?.error) { toast.error((data as any)?.error || error?.message || "Failed"); return; }
    toast.success("User created");
    setNu({ email: "", password: "", full_name: "", phone: "", role: "staff", branch_id: "" });
    load();
  };

  const deleteUser = async (uid: string) => {
    if (!confirm("Permanently delete user?")) return;
    const { data, error } = await supabase.functions.invoke("admin-create-user", { body: { action: "delete", target_user_id: uid } });
    if (error || (data as any)?.error) return toast.error((data as any)?.error || error?.message || "Failed");
    toast.success("User deleted"); load();
  };

  const updateUserRole = async (uid: string, role: string) => {
    const { data, error } = await supabase.functions.invoke("admin-create-user", { body: { action: "update", target_user_id: uid, role } });
    if (error || (data as any)?.error) return toast.error((data as any)?.error || error?.message || "Failed");
    toast.success("Role updated"); load();
  };

  const resetPassword = async (uid: string) => {
    const pw = prompt("Enter new password (min 6 chars):");
    if (!pw) return;
    const { data, error } = await supabase.functions.invoke("admin-create-user", { body: { action: "update", target_user_id: uid, password: pw } });
    if (error || (data as any)?.error) return toast.error((data as any)?.error || error?.message || "Failed");
    toast.success("Password reset");
  };

  const setUserBranch = async (uid: string, bid: string) => {
    const { error } = await supabase.from("profiles").update({ branch_id: bid || null }).eq("id", uid);
    if (error) toast.error(error.message); else { toast.success("Branch updated"); load(); }
  };

  const removeRole = async (uid: string, r: string) => {
    if (!confirm(`Remove role "${r}" from user?`)) return;
    const { error } = await supabase.from("user_roles").delete().eq("user_id", uid).eq("role", r as any);
    if (error) return toast.error(error.message);
    toast.success("Role removed"); load();
  };

  if (!isAdmin) return <div className="text-muted-foreground">Admin only</div>;

  return (
    <div className="space-y-4">
      <PageHeader title="Users & Roles" subtitle="Assign roles and branches for staff and managers" />
      <Card><CardHeader><CardTitle>Create New User (Admin / Staff / Branch Manager / Client)</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-4">
          <div><Label>Full Name / Branch Person *</Label><Input value={nu.full_name} onChange={(e) => setNu({ ...nu, full_name: e.target.value })} placeholder="Delhi Branch / Ramesh" /></div>
          <div><Label>Email *</Label><Input type="email" value={nu.email} onChange={(e) => setNu({ ...nu, email: e.target.value })} placeholder="delhi@fahadglobal.com" /></div>
          <div><Label>Password *</Label><Input type="text" value={nu.password} onChange={(e) => setNu({ ...nu, password: e.target.value })} placeholder="min 6 chars" /></div>
          <div><Label>Phone</Label><Input value={nu.phone} onChange={(e) => setNu({ ...nu, phone: e.target.value })} /></div>
          <div><Label>Role</Label>
            <Select value={nu.role} onValueChange={(v) => setNu({ ...nu, role: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="branch_manager">Branch Manager</SelectItem>
                <SelectItem value="staff">Staff</SelectItem>
                <SelectItem value="client">Client</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2"><Label>Branch</Label>
            <Select value={nu.branch_id} onValueChange={(v) => setNu({ ...nu, branch_id: v })}>
              <SelectTrigger><SelectValue placeholder="(none)" /></SelectTrigger>
              <SelectContent>{branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.branch_code} — {b.city}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="flex items-end"><Button onClick={createUser} disabled={busy} className="w-full">{busy ? "Creating…" : "Create User"}</Button></div>
        </CardContent></Card>
      <Card><CardContent className="p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left"><tr><th className="p-3">Name</th><th>Phone</th><th>Roles</th><th>Branch</th><th className="p-3">Actions</th></tr></thead>
          <tbody>{users.map((u) => (
            <tr key={u.id} className="border-t">
              <td className="p-3">{u.full_name ?? "—"}<div className="font-mono text-[10px] text-muted-foreground">{u.id.slice(0,8)}…</div></td>
              <td>{u.phone ?? "—"}</td>
              <td className="space-x-1">{u.roles.map((r: string) => (
                <Badge key={r} variant="secondary" className="cursor-pointer" onClick={() => removeRole(u.id, r)} title="Click to remove">{r} ✕</Badge>
              ))}</td>
              <td>
                <Select value={u.branch_id ?? ""} onValueChange={(v) => setUserBranch(u.id, v)}>
                  <SelectTrigger className="h-8 w-[180px]"><SelectValue placeholder="(none)" /></SelectTrigger>
                  <SelectContent>{branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.branch_code} — {b.city}</SelectItem>)}</SelectContent>
                </Select>
              </td>
              <td className="p-3 space-x-1 whitespace-nowrap">
                <Select onValueChange={(v) => updateUserRole(u.id, v)}>
                  <SelectTrigger className="h-8 w-[140px] inline-flex"><SelectValue placeholder="Set Role" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="branch_manager">Branch Manager</SelectItem>
                    <SelectItem value="staff">Staff</SelectItem>
                    <SelectItem value="client">Client</SelectItem>
                  </SelectContent>
                </Select>
                <Button size="sm" variant="outline" onClick={() => resetPassword(u.id)}>Reset PW</Button>
                <Button size="sm" variant="destructive" onClick={() => deleteUser(u.id)}><Trash2 className="h-3 w-3" /></Button>
              </td>
            </tr>
          ))}</tbody>
        </table>
      </CardContent></Card>
      <p className="text-xs text-muted-foreground">Public sign-up is disabled. Only admins create users from this panel.</p>
    </div>
  );
}
