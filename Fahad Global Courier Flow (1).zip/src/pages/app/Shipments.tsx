import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Printer, Tag, Pencil, Trash2 } from "lucide-react";
import { generateAwbDocket, generateStickerLabel } from "@/lib/awbLabel";
import { useAuth } from "@/lib/auth";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Shipments() {
  const { isAdmin } = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [clientId, setClientId] = useState<string>("all");
  const [clients, setClients] = useState<any[]>([]);
  const [editing, setEditing] = useState<any | null>(null);
  const [showTrash, setShowTrash] = useState(true);

  const load = async () => {
    let qb = supabase.from("shipments").select("*, clients(name,client_code)").order("created_at", { ascending: false }).limit(200);
    if (q) qb = qb.or(`awb_number.ilike.%${q}%,receiver_name.ilike.%${q}%,receiver_city.ilike.%${q}%`);
    if (clientId && clientId !== "all") qb = qb.eq("client_id", clientId);
    const { data } = await qb;
    let merged: any[] = (data ?? []).map((r) => ({ ...r, _trashed: false }));
    if (showTrash && isAdmin) {
      const { data: tr } = await (supabase as any).from("shipments_trash").select("*").order("deleted_at", { ascending: false }).limit(200);
      const trashRows = (tr ?? []).map((t: any) => ({ ...(t.shipment_data || {}), id: t.id, _trashed: true, _trash_id: t.id, _deleted_at: t.deleted_at, awb_number: t.awb_number }));
      const filtered = q ? trashRows.filter((r: any) => r.awb_number?.toLowerCase().includes(q.toLowerCase()) || r.receiver_name?.toLowerCase().includes(q.toLowerCase()) || r.receiver_city?.toLowerCase().includes(q.toLowerCase())) : trashRows;
      merged = [...merged, ...filtered];
    }
    setRows(merged);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [showTrash, clientId]);
  useEffect(() => { supabase.from("clients").select("id,name,client_code").eq("active", true).order("name").then(({ data }) => setClients(data ?? [])); }, []);

  const restoreTrash = async (r: any) => {
    const { error } = await (supabase as any).rpc("restore_shipment", { _trash_id: r._trash_id });
    if (error) return toast.error(error.message);
    toast.success("Restored from trash"); load();
  };
  const purgeTrash = async (r: any) => {
    if (!confirm(`Permanently delete trashed AWB ${r.awb_number}? This cannot be undone.`)) return;
    const { error } = await (supabase as any).from("shipments_trash").delete().eq("id", r._trash_id);
    if (error) return toast.error(error.message);
    toast.success("Permanently deleted"); load();
  };

  const remove = async (r: any) => {
    if (!confirm(`Delete shipment ${r.awb_number}? This will remove all tracking events, manifests and DRS links.`)) return;
    // Backup to trash before delete
    const { data: full } = await supabase.from("shipments").select("*").eq("id", r.id).single();
    const { data: events } = await supabase.from("tracking_events").select("*").eq("shipment_id", r.id);
    const { data: ml } = await supabase.from("manifest_shipments").select("*").eq("shipment_id", r.id);
    const { data: dl } = await supabase.from("drs_shipments").select("*").eq("shipment_id", r.id);
    const { data: { user } } = await supabase.auth.getUser();
    const { error: trashErr } = await (supabase as any).from("shipments_trash").insert({
      original_id: r.id, awb_number: r.awb_number,
      shipment_data: full, tracking_data: events, manifest_links: ml, drs_links: dl, deleted_by: user?.id,
    });
    if (trashErr) return toast.error("Backup failed: " + trashErr.message);
    await supabase.from("tracking_events").delete().eq("shipment_id", r.id);
    await supabase.from("manifest_shipments").delete().eq("shipment_id", r.id);
    await supabase.from("drs_shipments").delete().eq("shipment_id", r.id);
    await (supabase as any).from("public_tracking_shipments").delete().eq("shipment_id", r.id);
    const { error } = await supabase.from("shipments").delete().eq("id", r.id);
    if (error) return toast.error(error.message);
    toast.success("Moved to Trash. Restore from Trash page."); load();
  };

  const saveEdit = async () => {
    if (!editing) return;
    const { id, clients, ...rest } = editing;
    const { error } = await supabase.from("shipments").update(rest).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Shipment updated"); setEditing(null); load();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Shipments</h1>
        <div className="flex gap-2 items-center">
          {isAdmin && <label className="flex items-center gap-1 text-xs"><input type="checkbox" checked={showTrash} onChange={(e) => setShowTrash(e.target.checked)} /> Show deleted (trash)</label>}
          <Link to="/app/booking"><Button>+ New</Button></Link>
        </div>
      </div>
      <div className="flex gap-2">
        <Input placeholder="Search AWB / receiver / city" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load()} />
        <Select value={clientId} onValueChange={setClientId}>
          <SelectTrigger className="w-64"><SelectValue placeholder="Filter by client" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All clients</SelectItem>
            {clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.client_code} — {c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button onClick={load} variant="outline">Search</Button>
      </div>
      <Card><CardContent className="p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left"><tr>
            <th className="p-3">AWB</th><th>Date</th><th>Client</th><th>Receiver</th><th>City</th><th>Wt</th><th>Status</th><th className="p-3">Actions</th><th className="text-right p-3">Amount</th>
          </tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={(r._trashed ? "t-" : "") + r.id} className={`border-t hover:bg-muted/30 ${r._trashed ? "bg-destructive/5 opacity-80" : ""}`}>
                <td className="p-3 font-mono">
                  {r._trashed ? <span className="text-destructive">{r.awb_number}</span> : <Link to={`/track?awb=${r.awb_number}`} className="text-primary hover:underline">{r.awb_number}</Link>}
                  {r._trashed && <Badge variant="destructive" className="ml-2 text-[10px]">DELETED</Badge>}
                </td>
                <td>{r.booking_date}</td>
                <td>{r.clients?.name ?? "—"}</td>
                <td>{r.receiver_name}</td>
                <td>{r.receiver_city}</td>
                <td>{r.chargeable_weight}</td>
                <td><Badge variant="secondary" className="capitalize">{(r.status ?? "—").replace(/_/g, " ")}</Badge></td>
                <td className="p-3 space-x-1 whitespace-nowrap">
                  {!r._trashed && <>
                    <Button size="sm" variant="outline" onClick={() => generateAwbDocket(r)}><Printer className="h-3 w-3 mr-1" />Docket</Button>
                    <Button size="sm" variant="outline" onClick={() => generateStickerLabel(r)}><Tag className="h-3 w-3 mr-1" />Sticker</Button>
                    {isAdmin && <>
                      <Button size="sm" variant="outline" onClick={() => setEditing(r)}><Pencil className="h-3 w-3" /></Button>
                      <Button size="sm" variant="destructive" onClick={() => remove(r)}><Trash2 className="h-3 w-3" /></Button>
                    </>}
                  </>}
                  {r._trashed && isAdmin && <>
                    <Button size="sm" variant="outline" onClick={() => restoreTrash(r)}>Restore</Button>
                    <Button size="sm" variant="destructive" onClick={() => purgeTrash(r)}>Purge</Button>
                  </>}
                </td>
                <td className="text-right p-3">₹{Number(r.total_amount).toFixed(2)}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={9} className="p-6 text-center text-muted-foreground">No shipments</td></tr>}
          </tbody>
        </table>
      </CardContent></Card>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Edit Shipment {editing?.awb_number}</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3 md:grid-cols-3">
              <div><Label>AWB</Label><Input value={editing.awb_number} onChange={(e) => setEditing({ ...editing, awb_number: e.target.value })} /></div>
              <div><Label>Booking Date</Label><Input type="date" value={editing.booking_date ?? ""} onChange={(e) => setEditing({ ...editing, booking_date: e.target.value })} /></div>
              <div><Label>Status</Label><Input value={editing.status} onChange={(e) => setEditing({ ...editing, status: e.target.value })} /></div>
              <div><Label>Created At</Label><Input type="datetime-local" value={editing.created_at ? new Date(editing.created_at).toISOString().slice(0,16) : ""} onChange={(e) => setEditing({ ...editing, created_at: new Date(e.target.value).toISOString() })} /></div>
              <div><Label>Delivered At</Label><Input type="datetime-local" value={editing.delivered_at ? new Date(editing.delivered_at).toISOString().slice(0,16) : ""} onChange={(e) => setEditing({ ...editing, delivered_at: e.target.value ? new Date(e.target.value).toISOString() : null })} /></div>
              <div><Label>Received At Branch</Label><Input type="datetime-local" value={editing.received_at ? new Date(editing.received_at).toISOString().slice(0,16) : ""} onChange={(e) => setEditing({ ...editing, received_at: e.target.value ? new Date(e.target.value).toISOString() : null })} /></div>
              <div><Label>Sender Name</Label><Input value={editing.sender_name ?? ""} onChange={(e) => setEditing({ ...editing, sender_name: e.target.value })} /></div>
              <div><Label>Sender City</Label><Input value={editing.sender_city ?? ""} onChange={(e) => setEditing({ ...editing, sender_city: e.target.value })} /></div>
              <div><Label>Sender Phone</Label><Input value={editing.sender_phone ?? ""} onChange={(e) => setEditing({ ...editing, sender_phone: e.target.value })} /></div>
              <div><Label>Receiver Name</Label><Input value={editing.receiver_name ?? ""} onChange={(e) => setEditing({ ...editing, receiver_name: e.target.value })} /></div>
              <div><Label>Receiver City</Label><Input value={editing.receiver_city ?? ""} onChange={(e) => setEditing({ ...editing, receiver_city: e.target.value })} /></div>
              <div><Label>Receiver Pin</Label><Input value={editing.receiver_pincode ?? ""} onChange={(e) => setEditing({ ...editing, receiver_pincode: e.target.value })} /></div>
              <div className="md:col-span-3"><Label>Receiver Address</Label><Textarea value={editing.receiver_address ?? ""} onChange={(e) => setEditing({ ...editing, receiver_address: e.target.value })} /></div>
              <div><Label>Pieces</Label><Input type="number" value={editing.pieces} onChange={(e) => setEditing({ ...editing, pieces: +e.target.value })} /></div>
              <div><Label>Actual Wt</Label><Input type="number" step="0.001" value={editing.actual_weight} onChange={(e) => setEditing({ ...editing, actual_weight: +e.target.value })} /></div>
              <div><Label>Chargeable Wt</Label><Input type="number" step="0.001" value={editing.chargeable_weight} onChange={(e) => setEditing({ ...editing, chargeable_weight: +e.target.value })} /></div>
              <div><Label>Freight</Label><Input type="number" step="0.01" value={editing.freight ?? 0} onChange={(e) => setEditing({ ...editing, freight: +e.target.value })} /></div>
              <div><Label>GST</Label><Input type="number" step="0.01" value={editing.gst ?? 0} onChange={(e) => setEditing({ ...editing, gst: +e.target.value })} /></div>
              <div><Label>Total</Label><Input type="number" step="0.01" value={editing.total_amount ?? 0} onChange={(e) => setEditing({ ...editing, total_amount: +e.target.value })} /></div>
              <div className="md:col-span-3"><Label>Remarks</Label><Textarea value={editing.remarks ?? ""} onChange={(e) => setEditing({ ...editing, remarks: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={saveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
