import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, Truck, ClipboardCheck, IndianRupee } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const [stats, setStats] = useState({ total: 0, intransit: 0, delivered: 0, today: 0 });
  const [recent, setRecent] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      const today = new Date().toISOString().slice(0, 10);
      const [{ count: total }, { count: intr }, { count: dlv }, { count: tdy }, { data: rec }] = await Promise.all([
        supabase.from("shipments").select("*", { count: "exact", head: true }),
        supabase.from("shipments").select("*", { count: "exact", head: true }).in("status", ["in_transit", "out_for_delivery", "manifested"]),
        supabase.from("shipments").select("*", { count: "exact", head: true }).eq("status", "delivered"),
        supabase.from("shipments").select("*", { count: "exact", head: true }).eq("booking_date", today),
        supabase.from("shipments").select("awb_number,receiver_city,status,total_amount,booking_date").order("created_at", { ascending: false }).limit(8),
      ]);
      setStats({ total: total ?? 0, intransit: intr ?? 0, delivered: dlv ?? 0, today: tdy ?? 0 });
      setRecent(rec ?? []);
    })();
  }, []);
  const cards = [
    { label: "Today's Bookings", v: stats.today, icon: Package, color: "text-primary" },
    { label: "In Transit", v: stats.intransit, icon: Truck, color: "text-warning" },
    { label: "Delivered", v: stats.delivered, icon: ClipboardCheck, color: "text-success" },
    { label: "Total Shipments", v: stats.total, icon: IndianRupee, color: "text-accent" },
  ];
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground text-sm">Overview of operations</p>
        </div>
        <Link to="/app/booking"><Button>+ New Booking</Button></Link>
      </div>
      <div className="grid gap-4 md:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label}><CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div><div className="text-xs text-muted-foreground uppercase">{c.label}</div><div className="text-3xl font-bold mt-1">{c.v}</div></div>
              <c.icon className={`h-8 w-8 ${c.color}`} />
            </div>
          </CardContent></Card>
        ))}
      </div>
      <Card>
        <CardHeader><CardTitle>Recent Shipments</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground border-b">
                <tr><th className="py-2">AWB</th><th>Date</th><th>Destination</th><th>Status</th><th className="text-right">Amount</th></tr>
              </thead>
              <tbody>
                {recent.map((s) => (
                  <tr key={s.awb_number} className="border-b last:border-0">
                    <td className="py-2 font-mono">{s.awb_number}</td>
                    <td>{s.booking_date}</td>
                    <td>{s.receiver_city}</td>
                    <td><span className="capitalize">{s.status.replace(/_/g, " ")}</span></td>
                    <td className="text-right">₹{Number(s.total_amount).toFixed(2)}</td>
                  </tr>
                ))}
                {recent.length === 0 && <tr><td colSpan={5} className="py-6 text-center text-muted-foreground">No shipments yet</td></tr>}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
