import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { PageHeader } from "@/components/PageHeader";
import { toast } from "sonner";
import { format } from "date-fns";
import { Truck, User, Phone, Calendar, MapPin, Pencil } from "lucide-react";

const STATUSES = ["pending", "assigned", "picked", "cancelled"];

export default function Pickups() {
  const [list, setList] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [statusFilter, setStatusFilter] = useState("all");
  const [editing, setEditing] = useState<any | null>(null);

  const load = async () => {
    let q = (supabase as any).from("pickup_requests").select("*").order("created_at", { ascending: false }).limit(500);
    if (statusFilter !== "all") q = q.eq("status", statusFilter);
    const { data } = await q;
    setList(data ?? []);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [statusFilter]);
  useEffect(() => { (supabase as any).from("branches").select("id,name,city").eq("active", true).order("name").then(({ data }: any) => setBranches(data ?? [])); }, []);

  const save = async () => {
    if (!editing) return;
    const patch: any = {
      status: editing.status,
      assigned_branch_id: editing.assigned_branch_id || null,
      assigned_rider: editing.assigned_rider || null,
      assigned_at: editing.assigned_rider ? new Date().toISOString() : null,
    };
    const { error } = await (supabase as any).from("pickup_requests").update(patch).eq("id", editing.id);
    if (error) return toast.error(error.message);
    toast.success("Pickup updated");
    if (editing.email && (patch.status === "assigned" || patch.status === "picked" || patch.status === "cancelled")) {
      const branchName = branches.find((b: any) => b.id === patch.assigned_branch_id)?.name;
      try {
        await (supabase as any).functions.invoke("send-transactional-email", {
          body: {
            templateName: "pickup-assigned",
            recipientEmail: editing.email,
            templateData: {
              customerName: editing.contact_name,
              pickupDate: editing.pickup_date,
              pickupAddress: editing.pickup_address,
              rider: patch.assigned_rider, branch: branchName, status: patch.status,
            },
          },
        });
        toast.success("Customer notified by email");
      } catch { /* ignore email errors */ }
    }
    setEditing(null); load();
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Pickup Requests" subtitle="All pickup requests from public website and customers — assign branch/rider, update status" />
      <Card><CardContent className="pt-6 flex flex-wrap gap-2 items-center">
        <Label className="text-xs">Filter status:</Label>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </CardContent></Card>
      <Card><CardHeader><CardTitle>All Pickup Requests ({list.length})</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3">When</th><th>Customer</th><th>Phone</th><th>Pickup Date</th><th>Address</th><th>Pieces</th><th>Status</th><th>Assigned</th><th className="p-3">Actions</th></tr></thead>
            <tbody>
              {list.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="p-3 whitespace-nowrap">{format(new Date(r.created_at), "dd MMM HH:mm")}</td>
                  <td><div className="font-medium">{r.contact_name}</div>{r.email && <div className="text-xs text-muted-foreground">{r.email}</div>}</td>
                  <td className="whitespace-nowrap">{r.contact_phone}</td>
                  <td className="whitespace-nowrap">{format(new Date(r.pickup_date), "dd MMM yyyy")}{r.pickup_time ? ` · ${r.pickup_time}` : ""}</td>
                  <td className="max-w-[300px]"><div className="truncate">{r.pickup_address}</div><div className="text-xs text-muted-foreground">{[r.pickup_city, r.pickup_pincode].filter(Boolean).join(" - ")}</div></td>
                  <td>{r.pieces} · {r.approx_weight}kg</td>
                  <td><Badge variant="outline" className="capitalize">{r.status}</Badge></td>
                  <td className="text-xs">{r.assigned_rider ? <><div className="font-medium">{r.assigned_rider}</div>{r.assigned_at && <div className="text-muted-foreground">{format(new Date(r.assigned_at), "dd MMM HH:mm")}</div>}</> : <span className="text-muted-foreground">—</span>}</td>
                  <td className="p-3"><Button size="sm" variant="outline" onClick={() => setEditing({ ...r })}><Pencil className="h-3 w-3 mr-1" />Assign</Button></td>
                </tr>
              ))}
              {!list.length && <tr><td colSpan={9} className="p-8 text-center text-muted-foreground">No pickup requests yet.</td></tr>}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Assign Pickup — {editing?.contact_name}</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3">
              <div className="rounded-md bg-muted p-3 text-sm space-y-1">
                <div className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 text-primary" />{editing.contact_phone}</div>
                <div className="flex items-center gap-2"><Calendar className="h-3.5 w-3.5 text-primary" />{format(new Date(editing.pickup_date), "dd MMM yyyy")} {editing.pickup_time}</div>
                <div className="flex items-start gap-2"><MapPin className="h-3.5 w-3.5 text-primary mt-0.5" />{editing.pickup_address} · {[editing.pickup_city, editing.pickup_pincode].filter(Boolean).join(" - ")}</div>
              </div>
              <div><Label>Branch</Label>
                <Select value={editing.assigned_branch_id || ""} onValueChange={(v) => setEditing({ ...editing, assigned_branch_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Select branch" /></SelectTrigger>
                  <SelectContent>{branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.name} {b.city ? `· ${b.city}` : ""}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Rider Name</Label><Input value={editing.assigned_rider || ""} onChange={(e) => setEditing({ ...editing, assigned_rider: e.target.value })} placeholder="Pickup boy name" /></div>
              <div><Label>Status</Label>
                <Select value={editing.status} onValueChange={(v) => setEditing({ ...editing, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={save}><Truck className="h-4 w-4 mr-2" />Save Assignment</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}