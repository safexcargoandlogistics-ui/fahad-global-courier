import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { format } from "date-fns";
import { FileImage, Upload, ExternalLink } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";

const cleanName = (n: string) => n.replace(/[^a-zA-Z0-9._-]/g, "_");

export default function PODUpload() {
  const [awb, setAwb] = useState("");
  const [shipment, setShipment] = useState<any>(null);
  const [file, setFile] = useState<File | null>(null);
  const [receiver, setReceiver] = useState("");
  const [busy, setBusy] = useState(false);

  const search = async () => {
    const code = awb.trim().toUpperCase();
    if (!code) return;
    const { data, error } = await supabase.from("shipments").select("*").eq("awb_number", code).maybeSingle();
    if (error || !data) { toast.error("AWB not found"); setShipment(null); return; }
    setShipment(data);
    setReceiver(data.pod_received_by || data.receiver_name || "");
  };

  const upload = async () => {
    if (!shipment || !file) { toast.error("Select a file"); return; }
    setBusy(true);
    const safe = cleanName(file.name);
    const path = `${shipment.awb_number}/${Date.now()}-${safe}`;
    const { error: upErr } = await supabase.storage.from("pods").upload(path, file, { upsert: true, contentType: file.type || "image/jpeg" });
    if (upErr) { toast.error("Upload failed: " + upErr.message); setBusy(false); return; }
    const pod_url = supabase.storage.from("pods").getPublicUrl(path).data.publicUrl;
    const now = new Date().toISOString();
    const upd: any = { pod_url, pod_at: now };
    if (receiver) upd.pod_received_by = receiver;
    if (shipment.status === "delivered" && !shipment.delivered_at) upd.delivered_at = now;
    const { error } = await supabase.from("shipments").update(upd).eq("id", shipment.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("POD uploaded successfully");
    setShipment({ ...shipment, ...upd });
    setFile(null);
  };

  return (
    <div className="space-y-4 max-w-4xl">
      <PageHeader title="POD Upload" subtitle="Upload or replace Proof of Delivery for any shipment — useful when POD was missed at delivery time" />
      <Card><CardContent className="pt-6 flex gap-2">
        <Input placeholder="Enter AWB number" value={awb} onChange={(e) => setAwb(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === "Enter" && search()} />
        <Button onClick={search}>Find</Button>
      </CardContent></Card>
      {shipment && (
        <Card>
          <CardHeader><CardTitle className="font-mono">{shipment.awb_number} — {shipment.receiver_name}</CardTitle></CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2">
            <div className="md:col-span-2 text-sm text-muted-foreground">{shipment.receiver_city}, {shipment.receiver_pincode} · Status: <span className="font-semibold capitalize">{shipment.status?.replace(/_/g, " ")}</span></div>
            {shipment.pod_url && (
              <div className="md:col-span-2 rounded-lg border bg-muted/30 p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-sm"><FileImage className="h-4 w-4 text-primary" /><span>Existing POD{shipment.pod_at && ` · uploaded ${format(new Date(shipment.pod_at), "dd MMM yyyy HH:mm")}`}</span></div>
                <a href={shipment.pod_url} target="_blank" rel="noreferrer"><Button size="sm" variant="outline"><ExternalLink className="h-3 w-3 mr-1" />Open</Button></a>
              </div>
            )}
            <div><Label>Received By</Label><Input value={receiver} onChange={(e) => setReceiver(e.target.value)} placeholder="Receiver name" /></div>
            <div><Label>POD Photo / Signature *</Label><Input type="file" accept="image/*,application/pdf" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></div>
            <div className="md:col-span-2 flex justify-end"><Button onClick={upload} disabled={busy || !file}><Upload className="h-4 w-4 mr-2" />{shipment.pod_url ? "Replace POD" : "Upload POD"}</Button></div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}