import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Pencil, Trash2 } from "lucide-react";

const empty = { name: "", city: "", state: "", address: "", phone: "", email: "", contact_person: "", map_url: "", image_url: "", display_order: 0, active: true };

export default function WebsiteBranches() {
  const { isAdmin } = useAuth();
  const [list, setList] = useState<any[]>([]);
  const [f, setF] = useState<any>(empty);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [imgFile, setImgFile] = useState<File | null>(null);

  const load = async () => {
    const { data } = await (supabase as any).from("website_branches").select("*").order("display_order").order("name");
    setList(data ?? []);
  };
  useEffect(() => { if (isAdmin) load(); }, [isAdmin]);

  const save = async () => {
    if (!f.name) { toast.error("Branch name required"); return; }
    let image_url = f.image_url;
    if (imgFile) {
      const path = `branches/${Date.now()}-${imgFile.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error: upErr } = await supabase.storage.from("website-assets").upload(path, imgFile, { upsert: true });
      if (upErr) return toast.error("Image upload: " + upErr.message);
      image_url = supabase.storage.from("website-assets").getPublicUrl(path).data.publicUrl;
    }
    const payload = { ...f, image_url };
    if (editingId) {
      const { error } = await (supabase as any).from("website_branches").update(payload).eq("id", editingId);
      if (error) return toast.error(error.message);
      toast.success("Updated — visible on website");
    } else {
      const { error } = await (supabase as any).from("website_branches").insert(payload);
      if (error) return toast.error(error.message);
      toast.success("Added — visible on website");
    }
    setF(empty); setEditingId(null); setImgFile(null); load();
  };
  const edit = (b: any) => { setF({ ...empty, ...b }); setEditingId(b.id); };
  const remove = async (id: string) => {
    if (!confirm("Remove from public website?")) return;
    const { error } = await (supabase as any).from("website_branches").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Removed"); load();
  };

  if (!isAdmin) return <div className="text-muted-foreground">Admin only</div>;

  return (
    <div className="space-y-4">
      <PageHeader title="Website Branches" subtitle="Branches displayed on the public website (separate from operational branches used for booking & manifest)" />
      <Card><CardHeader><CardTitle>{editingId ? "Edit Website Branch" : "Add Website Branch"}</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3">
          <div><Label>Name *</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Mumbai Office" /></div>
          <div><Label>City</Label><Input value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} /></div>
          <div><Label>State</Label><Input value={f.state} onChange={(e) => setF({ ...f, state: e.target.value })} /></div>
          <div><Label>Phone</Label><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></div>
          <div><Label>Email</Label><Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
          <div><Label>Contact Person</Label><Input value={f.contact_person} onChange={(e) => setF({ ...f, contact_person: e.target.value })} /></div>
          <div className="md:col-span-3"><Label>Address</Label><Textarea value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></div>
          <div><Label>Google Maps URL</Label><Input value={f.map_url} onChange={(e) => setF({ ...f, map_url: e.target.value })} placeholder="https://maps.google.com/..." /></div>
          <div><Label>Image (optional)</Label><Input type="file" accept="image/*" onChange={(e) => setImgFile(e.target.files?.[0] ?? null)} /></div>
          <div><Label>Display Order</Label><Input type="number" value={f.display_order} onChange={(e) => setF({ ...f, display_order: Number(e.target.value) })} /></div>
          <div className="md:col-span-3 flex justify-end gap-2">
            {editingId && <Button variant="outline" onClick={() => { setF(empty); setEditingId(null); setImgFile(null); }}>Cancel</Button>}
            <Button onClick={save}>{editingId ? "Update" : "Publish to Website"}</Button>
          </div>
        </CardContent>
      </Card>
      <Card><CardHeader><CardTitle>Live on Website ({list.length})</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3">Order</th><th>Name</th><th>City</th><th>Phone</th><th>Email</th><th>Active</th><th className="p-3">Actions</th></tr></thead>
            <tbody>{list.map((b) => (
              <tr key={b.id} className="border-t">
                <td className="p-3">{b.display_order}</td>
                <td>{b.name}</td><td>{b.city}</td><td>{b.phone}</td><td>{b.email}</td>
                <td>{b.active ? "Yes" : "No"}</td>
                <td className="p-3 flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => edit(b)}><Pencil className="h-3 w-3" /></Button>
                  <Button size="sm" variant="outline" onClick={() => remove(b.id)}><Trash2 className="h-3 w-3" /></Button>
                </td>
              </tr>
            ))}{!list.length && <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">None yet — add your first branch above.</td></tr>}</tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
