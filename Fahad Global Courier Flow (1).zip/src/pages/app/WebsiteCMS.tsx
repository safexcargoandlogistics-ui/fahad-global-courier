import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PageHeader } from "@/components/PageHeader";
import { useSiteContent, SITE_DEFAULTS } from "@/hooks/useSiteContent";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import { Plus, Trash2, Save } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

function Section<T>({ title, k, defaults, render }: { title: string; k: string; defaults: T; render: (v: T, set: (v: T) => void) => React.ReactNode }) {
  const { value, setValue, save, loading } = useSiteContent<T>(k, defaults);
  if (loading) return null;
  return (
    <Card>
      <CardHeader><CardTitle className="flex items-center justify-between">{title}<Button size="sm" onClick={async () => { const e = await save(value); toast[e ? "error" : "success"](e ? e.message : "Saved"); }}><Save className="h-3 w-3 mr-1" />Save</Button></CardTitle></CardHeader>
      <CardContent className="space-y-3">{render(value, setValue)}</CardContent>
    </Card>
  );
}

async function uploadImage(file: File): Promise<string | null> {
  const path = `cms/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  const { error } = await supabase.storage.from("website-assets").upload(path, file, { upsert: true });
  if (error) { toast.error(error.message); return null; }
  return supabase.storage.from("website-assets").getPublicUrl(path).data.publicUrl;
}

export default function WebsiteCMS() {
  const { isAdmin } = useAuth();
  const [tab, setTab] = useState("header");
  if (!isAdmin) return <div className="text-muted-foreground">Admin only</div>;

  return (
    <div className="space-y-4">
      <PageHeader title="Website CMS" subtitle="Edit every section of the public website — header, hero, contact, footer, partners and more" />
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="header">Header</TabsTrigger>
          <TabsTrigger value="hero">Hero</TabsTrigger>
          <TabsTrigger value="slides">Banner Slides</TabsTrigger>
          <TabsTrigger value="about">About</TabsTrigger>
          <TabsTrigger value="services">Services</TabsTrigger>
          <TabsTrigger value="public_rates">Public Rates</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
          <TabsTrigger value="footer">Footer</TabsTrigger>
          <TabsTrigger value="track">Track Page</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
          <TabsTrigger value="partners">Partners</TabsTrigger>
          <TabsTrigger value="team">Team</TabsTrigger>
          <TabsTrigger value="invoice">Invoice Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="header">
          <Section title="Header / Top Navigation" k="header" defaults={SITE_DEFAULTS.header} render={(v: any, set) => (<>
            <div className="grid md:grid-cols-2 gap-3">
              <div><Label>Brand Name</Label><Input value={v.brand} onChange={(e) => set({ ...v, brand: e.target.value })} /></div>
              <div><Label>Tagline</Label><Input value={v.tagline} onChange={(e) => set({ ...v, tagline: e.target.value })} /></div>
            </div>
            <div className="mt-2">
              <Label>Navigation Links</Label>
              {v.nav.map((n: any, i: number) => (
                <div key={i} className="flex gap-2 mt-2">
                  <Input placeholder="Label" value={n.label} onChange={(e) => { const a = [...v.nav]; a[i] = { ...a[i], label: e.target.value }; set({ ...v, nav: a }); }} />
                  <Input placeholder="/url or #anchor" value={n.url} onChange={(e) => { const a = [...v.nav]; a[i] = { ...a[i], url: e.target.value }; set({ ...v, nav: a }); }} />
                  <Button size="icon" variant="outline" onClick={() => set({ ...v, nav: v.nav.filter((_: any, k: number) => k !== i) })}><Trash2 className="h-3 w-3" /></Button>
                </div>
              ))}
              <Button size="sm" variant="outline" className="mt-2" onClick={() => set({ ...v, nav: [...v.nav, { label: "New", url: "/" }] })}><Plus className="h-3 w-3 mr-1" />Add Link</Button>
            </div>
          </>)} />
        </TabsContent>

        <TabsContent value="hero">
          <Section title="Hero Section (Homepage)" k="hero" defaults={SITE_DEFAULTS.hero} render={(v: any, set) => (<>
            <div><Label>Top Badge Text</Label><Input value={v.badge} onChange={(e) => set({ ...v, badge: e.target.value })} /></div>
            <div className="grid md:grid-cols-2 gap-3">
              <div><Label>Title Line 1</Label><Input value={v.title_line1} onChange={(e) => set({ ...v, title_line1: e.target.value })} /></div>
              <div><Label>Title Line 2</Label><Input value={v.title_line2} onChange={(e) => set({ ...v, title_line2: e.target.value })} /></div>
            </div>
            <div><Label>Subtitle</Label><Textarea value={v.subtitle} onChange={(e) => set({ ...v, subtitle: e.target.value })} /></div>
            <div className="grid md:grid-cols-2 gap-3">
              <div><Label>Primary CTA Text</Label><Input value={v.cta_primary} onChange={(e) => set({ ...v, cta_primary: e.target.value })} /></div>
              <div><Label>Secondary CTA Text</Label><Input value={v.cta_secondary} onChange={(e) => set({ ...v, cta_secondary: e.target.value })} /></div>
            </div>
            <div className="border rounded-md p-3 bg-muted/30">
              <Label>Hero Banner Image (single fallback - use Banner Slides tab for slideshow)</Label>
              {v.banner_url ? (
                <div className="flex items-center gap-3 mt-2">
                  <img src={v.banner_url} alt="Hero banner" className="h-24 rounded border bg-white object-cover" />
                  <Button size="sm" variant="destructive" onClick={() => set({ ...v, banner_url: "" })}><Trash2 className="h-3 w-3 mr-1" />Remove (then click Save)</Button>
                </div>
              ) : <p className="text-xs text-muted-foreground mt-1">No banner uploaded</p>}
              <Input type="file" accept="image/*" className="mt-2" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const url = await uploadImage(f); if (url) { set({ ...v, banner_url: url }); toast.success("Banner uploaded — click Save"); } }} />
            </div>
          </>)} />
        </TabsContent>

        <TabsContent value="slides">
          <Section title="Hero Banner Slideshow" k="hero" defaults={SITE_DEFAULTS.hero} render={(v: any, set) => {
            const slides: any[] = Array.isArray(v.slides) ? v.slides : [];
            return (<>
              <p className="text-xs text-muted-foreground">Upload multiple banner images — they auto-rotate on the public homepage hero.</p>
              <div><Label>Auto-rotate interval (ms)</Label><Input type="number" min="1500" step="500" value={v.slide_interval_ms ?? 5000} onChange={(e) => set({ ...v, slide_interval_ms: +e.target.value })} /></div>
              <div className="space-y-2">
                {slides.map((s, i) => (
                  <div key={i} className="flex items-center gap-2 border rounded-md p-2">
                    {s.url && <img src={s.url} alt={s.caption || `slide ${i + 1}`} className="h-16 w-28 object-cover rounded bg-white" />}
                    <Input className="flex-1" placeholder="Caption (optional)" value={s.caption ?? ""} onChange={(e) => { const a = [...slides]; a[i] = { ...a[i], caption: e.target.value }; set({ ...v, slides: a }); }} />
                    <Input type="file" accept="image/*" className="max-w-[240px]" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const url = await uploadImage(f); if (url) { const a = [...slides]; a[i] = { ...a[i], url }; set({ ...v, slides: a }); toast.success("Image uploaded — click Save"); } }} />
                    <Button size="icon" variant="outline" onClick={() => set({ ...v, slides: slides.filter((_, k) => k !== i) })}><Trash2 className="h-3 w-3" /></Button>
                  </div>
                ))}
              </div>
              <Button size="sm" variant="outline" onClick={() => set({ ...v, slides: [...slides, { url: "", caption: "" }] })}><Plus className="h-3 w-3 mr-1" />Add Slide</Button>
            </>);
          }} />
        </TabsContent>

        <TabsContent value="public_rates">
          <Section title="Public Website Rate Card" k="public_rates" defaults={SITE_DEFAULTS.public_rates} render={(v: any[], set) => {
            const rows: any[] = Array.isArray(v) ? v : [];
            return (<>
              <p className="text-xs text-muted-foreground">Rates shown on /rates and the Rate &amp; TAT Calculator. Use "REST OF INDIA" as fallback destination.</p>
              <div className="space-y-2">
                {rows.map((r, i) => (
                  <div key={i} className="grid grid-cols-2 md:grid-cols-8 gap-2 border rounded-md p-2 items-end">
                    <div className="md:col-span-2"><Label className="text-xs">Service</Label><Input value={r.service ?? ""} onChange={(e) => { const a = [...rows]; a[i] = { ...a[i], service: e.target.value }; set(a as any); }} /></div>
                    <div className="md:col-span-2"><Label className="text-xs">Destination</Label><Input value={r.destination ?? ""} onChange={(e) => { const a = [...rows]; a[i] = { ...a[i], destination: e.target.value }; set(a as any); }} /></div>
                    <div><Label className="text-xs">Rate ₹/kg</Label><Input type="number" value={r.rate ?? 0} onChange={(e) => { const a = [...rows]; a[i] = { ...a[i], rate: +e.target.value }; set(a as any); }} /></div>
                    <div><Label className="text-xs">Min Wt (kg)</Label><Input type="number" step="0.1" value={r.min_weight ?? 0} onChange={(e) => { const a = [...rows]; a[i] = { ...a[i], min_weight: +e.target.value }; set(a as any); }} /></div>
                    <div><Label className="text-xs">Fuel %</Label><Input type="number" step="0.1" value={r.fuel_pct ?? 0} onChange={(e) => { const a = [...rows]; a[i] = { ...a[i], fuel_pct: +e.target.value }; set(a as any); }} /></div>
                    <div><Label className="text-xs">Other ₹</Label><Input type="number" value={r.other_charge ?? 0} onChange={(e) => { const a = [...rows]; a[i] = { ...a[i], other_charge: +e.target.value }; set(a as any); }} /></div>
                    <div className="md:col-span-2"><Label className="text-xs">TAT</Label><Input value={r.tat ?? ""} onChange={(e) => { const a = [...rows]; a[i] = { ...a[i], tat: e.target.value }; set(a as any); }} /></div>
                    <div className="md:col-span-5 flex items-center gap-3">
                      <label className="text-xs inline-flex items-center gap-2"><input type="checkbox" checked={r.active !== false} onChange={(e) => { const a = [...rows]; a[i] = { ...a[i], active: e.target.checked }; set(a as any); }} />Active (visible on public website)</label>
                    </div>
                    <div className="md:col-span-1 flex justify-end"><Button size="icon" variant="outline" onClick={() => set(rows.filter((_, k) => k !== i) as any)}><Trash2 className="h-3 w-3" /></Button></div>
                  </div>
                ))}
              </div>
              <Button size="sm" variant="outline" onClick={() => set([...rows, { service: "Standard Air", destination: "REST OF INDIA", rate: 90, min_weight: 0.5, fuel_pct: 0, other_charge: 0, tat: "1-2 Days", active: true }] as any)}><Plus className="h-3 w-3 mr-1" />Add Rate Row</Button>
            </>);
          }} />
        </TabsContent>

        <TabsContent value="about">
          <Section title="About Us" k="about" defaults={SITE_DEFAULTS.about} render={(v: any, set) => (<>
            <div><Label>Title</Label><Input value={v.title} onChange={(e) => set({ ...v, title: e.target.value })} /></div>
            <div><Label>Body (supports line breaks)</Label><Textarea rows={10} value={v.body} onChange={(e) => set({ ...v, body: e.target.value })} /></div>
          </>)} />
        </TabsContent>

        <TabsContent value="contact">
          <Section title="Contact Information" k="contact" defaults={SITE_DEFAULTS.contact} render={(v: any, set) => (<>
            <div className="grid md:grid-cols-2 gap-3">
              <div><Label>Phone</Label><Input value={v.phone} onChange={(e) => set({ ...v, phone: e.target.value })} /></div>
              <div><Label>Email</Label><Input value={v.email} onChange={(e) => set({ ...v, email: e.target.value })} /></div>
              <div><Label>Website</Label><Input value={v.web} onChange={(e) => set({ ...v, web: e.target.value })} /></div>
              <div><Label>Hours</Label><Input value={v.hours} onChange={(e) => set({ ...v, hours: e.target.value })} /></div>
              <div><Label>WhatsApp Number (digits only, with country code)</Label><Input value={v.whatsapp} onChange={(e) => set({ ...v, whatsapp: e.target.value })} /></div>
            </div>
            <div><Label>Head Office Address</Label><Textarea value={v.address} onChange={(e) => set({ ...v, address: e.target.value })} /></div>
          </>)} />
        </TabsContent>

        <TabsContent value="footer">
          <Section title="Footer" k="footer" defaults={SITE_DEFAULTS.footer} render={(v: any, set) => (<>
            <div><Label>Tagline</Label><Input value={v.tagline} onChange={(e) => set({ ...v, tagline: e.target.value })} /></div>
            <div><Label>GSTIN</Label><Input value={v.gstin} onChange={(e) => set({ ...v, gstin: e.target.value })} /></div>
            <div><Label>Copyright Line</Label><Input value={v.copyright} onChange={(e) => set({ ...v, copyright: e.target.value })} /></div>
          </>)} />
        </TabsContent>

        <TabsContent value="track">
          <Section title="Public Tracking Page" k="track_page" defaults={SITE_DEFAULTS.track_page} render={(v: any, set) => (<>
            <div><Label>Page Title</Label><Input value={v.title} onChange={(e) => set({ ...v, title: e.target.value })} /></div>
            <div><Label>Sub-text</Label><Input value={v.subtitle} onChange={(e) => set({ ...v, subtitle: e.target.value })} /></div>
          </>)} />
        </TabsContent>

        <TabsContent value="seo">
          <Section title="SEO / Google Search Console" k="seo_settings" defaults={SITE_DEFAULTS.seo_settings} render={(v: any, set) => (<>
            <div><Label>Google site verification code</Label><Input value={v.google_site_verification ?? ""} onChange={(e) => set({ ...v, google_site_verification: e.target.value })} placeholder="Paste only the verification content value" /></div>
            <div><Label>Social profiles (one URL per line)</Label><Textarea rows={5} value={v.same_as ?? ""} onChange={(e) => set({ ...v, same_as: e.target.value })} placeholder="https://www.facebook.com/..." /></div>
          </>)} />
        </TabsContent>

        <TabsContent value="partners">
          <Section title="Delivery Partners" k="partners" defaults={SITE_DEFAULTS.partners} render={(v: any[], set) => (<>
            {(Array.isArray(v) ? v : []).map((p, i) => (
              <div key={i} className="flex items-center gap-2 border rounded-md p-2">
                {p.logo && <img src={p.logo} alt={p.name} className="h-10 w-20 object-contain bg-white rounded" />}
                <Input className="flex-1" placeholder="Partner name" value={p.name ?? ""} onChange={(e) => { const a = [...(Array.isArray(v) ? v : [])]; a[i] = { ...a[i], name: e.target.value }; set(a as any); }} />
                <Input type="file" accept="image/*" className="max-w-[220px]" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const url = await uploadImage(f); if (url) { const a = [...(Array.isArray(v) ? v : [])]; a[i] = { ...a[i], logo: url }; set(a as any); toast.success("Logo uploaded — click Save"); } }} />
                <Button size="icon" variant="outline" onClick={() => set((Array.isArray(v) ? v : []).filter((_, k) => k !== i) as any)}><Trash2 className="h-3 w-3" /></Button>
              </div>
            ))}
            <Button size="sm" variant="outline" onClick={() => set([...(Array.isArray(v) ? v : []), { name: "New Partner", logo: "" }] as any)}><Plus className="h-3 w-3 mr-1" />Add Partner</Button>
          </>)} />
        </TabsContent>

        <TabsContent value="services">
          <Section title="Services (Homepage)" k="services" defaults={SITE_DEFAULTS.services} render={(v: any[], set) => (<>
            <p className="text-xs text-muted-foreground">Add, edit or delete services shown on the public homepage. Upload a logo or pick a built-in icon.</p>
            {(Array.isArray(v) ? v : []).map((s, i) => (
              <div key={i} className="grid md:grid-cols-12 gap-2 border rounded-md p-3 items-start">
                <div className="md:col-span-2 flex flex-col items-center gap-1">
                  {s.logo ? <img src={s.logo} alt={s.title} className="h-14 w-14 object-contain bg-white rounded border" /> : <div className="h-14 w-14 rounded border bg-muted flex items-center justify-center text-[10px] text-muted-foreground">No logo</div>}
                  <Input type="file" accept="image/*" className="text-xs" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const url = await uploadImage(f); if (url) { const a = [...v]; a[i] = { ...a[i], logo: url }; set(a as any); toast.success("Logo uploaded — click Save"); } }} />
                </div>
                <div className="md:col-span-3"><Label className="text-xs">Title</Label><Input value={s.title ?? ""} onChange={(e) => { const a = [...v]; a[i] = { ...a[i], title: e.target.value }; set(a as any); }} /></div>
                <div className="md:col-span-5"><Label className="text-xs">Description</Label><Input value={s.desc ?? ""} onChange={(e) => { const a = [...v]; a[i] = { ...a[i], desc: e.target.value }; set(a as any); }} /></div>
                <div className="md:col-span-2 flex items-end justify-end h-full">
                  <Button size="icon" variant="outline" onClick={() => set(v.filter((_, k) => k !== i) as any)}><Trash2 className="h-3 w-3" /></Button>
                </div>
              </div>
            ))}
            <Button size="sm" variant="outline" onClick={() => set([...(Array.isArray(v) ? v : []), { title: "New Service", desc: "", logo: "", icon: "PackageCheck", color: "from-primary to-accent" }] as any)}><Plus className="h-3 w-3 mr-1" />Add Service</Button>
          </>)} />
        </TabsContent>

        <TabsContent value="invoice">
          <Section title="Invoice Settings (used in Manual Invoice PDF)" k="invoice_settings" defaults={SITE_DEFAULTS.invoice_settings} render={(v: any, set) => (<>
            <div className="grid md:grid-cols-2 gap-3">
              <div className="md:col-span-2"><Label>Company Name</Label><Input value={v.company_name} onChange={(e) => set({ ...v, company_name: e.target.value })} /></div>
              <div className="md:col-span-2"><Label>Registered Address</Label><Textarea value={v.address} onChange={(e) => set({ ...v, address: e.target.value })} /></div>
              <div><Label>Phone</Label><Input value={v.phone} onChange={(e) => set({ ...v, phone: e.target.value })} /></div>
              <div><Label>Email</Label><Input value={v.email} onChange={(e) => set({ ...v, email: e.target.value })} /></div>
              <div><Label>Website</Label><Input value={v.web} onChange={(e) => set({ ...v, web: e.target.value })} /></div>
              <div><Label>UDYAM</Label><Input value={v.udyam ?? ""} onChange={(e) => set({ ...v, udyam: e.target.value })} /></div>
              <div><Label>GSTIN</Label><Input value={v.gstin} onChange={(e) => set({ ...v, gstin: e.target.value })} /></div>
              <div><Label>PAN</Label><Input value={v.pan} onChange={(e) => set({ ...v, pan: e.target.value })} /></div>
              <div><Label>State</Label><Input value={v.state} onChange={(e) => set({ ...v, state: e.target.value })} /></div>
              <div><Label>State Code</Label><Input value={v.state_code} onChange={(e) => set({ ...v, state_code: e.target.value })} /></div>
              <div><Label>HSN / SAC</Label><Input value={v.sac} onChange={(e) => set({ ...v, sac: e.target.value })} /></div>
              <div><Label>Default Due Days</Label><Input value={v.due_days} onChange={(e) => set({ ...v, due_days: e.target.value })} /></div>
              <div><Label>Total GST %</Label><Input type="number" step="0.01" value={v.gst_pct} onChange={(e) => set({ ...v, gst_pct: +e.target.value })} /></div>
              <div><Label>CGST %</Label><Input type="number" step="0.01" value={v.cgst_pct} onChange={(e) => set({ ...v, cgst_pct: +e.target.value })} /></div>
              <div><Label>SGST %</Label><Input type="number" step="0.01" value={v.sgst_pct} onChange={(e) => set({ ...v, sgst_pct: +e.target.value })} /></div>
              <div><Label>IGST %</Label><Input type="number" step="0.01" value={v.igst_pct} onChange={(e) => set({ ...v, igst_pct: +e.target.value })} /></div>
              <div><Label>Invoice Primary Color</Label><Input type="color" value={v.primary_color ?? "#0B1E5B"} onChange={(e) => set({ ...v, primary_color: e.target.value })} /></div>
              <div><Label>Invoice Accent Color</Label><Input type="color" value={v.accent_color ?? "#D4AF37"} onChange={(e) => set({ ...v, accent_color: e.target.value })} /></div>
              <div><Label>Invoice Font Size</Label><Input type="number" min="6" max="12" step="0.5" value={v.font_size ?? 8} onChange={(e) => set({ ...v, font_size: +e.target.value })} /></div>
              <div className="md:col-span-2 flex items-center gap-2 pt-2 border-t"><input id="intra" type="checkbox" checked={!!v.intra_state} onChange={(e) => set({ ...v, intra_state: e.target.checked })} /><Label htmlFor="intra">Default to Intra-State (CGST + SGST). Uncheck for Inter-State (IGST).</Label></div>
            </div>
            <h4 className="font-semibold pt-3 border-t">Bank Details</h4>
            <div className="grid md:grid-cols-2 gap-3">
              <div><Label>Bank Name</Label><Input value={v.bank_name} onChange={(e) => set({ ...v, bank_name: e.target.value })} /></div>
              <div><Label>Account No</Label><Input value={v.bank_account} onChange={(e) => set({ ...v, bank_account: e.target.value })} /></div>
              <div><Label>Branch</Label><Input value={v.bank_branch} onChange={(e) => set({ ...v, bank_branch: e.target.value })} /></div>
              <div><Label>IFSC</Label><Input value={v.bank_ifsc} onChange={(e) => set({ ...v, bank_ifsc: e.target.value })} /></div>
              <div><Label>SWIFT (international)</Label><Input value={v.swift_code} onChange={(e) => set({ ...v, swift_code: e.target.value })} /></div>
            </div>
            <h4 className="font-semibold pt-3 border-t">Notes & Terms</h4>
            <div><Label>Declaration</Label><Textarea value={v.declaration} onChange={(e) => set({ ...v, declaration: e.target.value })} /></div>
            <div><Label>Computer-generated note</Label><Input value={v.computer_generated} onChange={(e) => set({ ...v, computer_generated: e.target.value })} /></div>
            <div>
              <Label>Payment Terms (one per line)</Label>
              <Textarea rows={5} value={(v.terms ?? []).join("\n")} onChange={(e) => set({ ...v, terms: e.target.value.split("\n").filter(Boolean) })} />
            </div>
          </>)} />
        </TabsContent>
      </Tabs>
    </div>
  );
}