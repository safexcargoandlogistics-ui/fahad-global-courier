import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Pencil, Trash2 } from "lucide-react";
import { IndiaPostPicker } from "@/components/IndiaPostPicker";

const empty = { branch_code: "", name: "", city: "", state: "", pincode: "", address: "", phone: "", email: "", contact_person: "" };

export default function Branches() {
  const { isAdmin, isBranchManager } = useAuth();
  const canManage = isAdmin || isBranchManager;
  const [list, setList] = useState<any[]>([]);
  const [f, setF] = useState<any>(empty);
  const [editingId, setEditingId] = useState<string | null>(null);

  const load = async () => {
    const { data } = await (supabase as any).from("branches").select("*").order("name");
    setList(data ?? []);
  };
  useEffect(() => { if (canManage) load(); }, [canManage]);

  const save = async () => {
    if (!f.branch_code || !f.name) { toast.error("Code and Name required"); return; }
    if (editingId) {
      const { error } = await (supabase as any).from("branches").update(f).eq("id", editingId);
      if (error) return toast.error(error.message);
      toast.success("Branch updated");
    } else {
      const { error } = await (supabase as any).from("branches").insert(f);
      if (error) return toast.error(error.message);
      toast.success("Branch added");
    }
    setF(empty); setEditingId(null); load();
  };
  const edit = (b: any) => { setF({ branch_code: b.branch_code, name: b.name, city: b.city ?? "", state: b.state ?? "", pincode: b.pincode ?? "", address: b.address ?? "", phone: b.phone ?? "", email: b.email ?? "", contact_person: b.contact_person ?? "" }); setEditingId(b.id); };
  const remove = async (id: string) => {
    if (!confirm("Delete branch?")) return;
    const { error } = await (supabase as any).from("branches").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); load();
  };

  if (!canManage) return <div className="text-muted-foreground">Admin or Branch Manager only</div>;

  return (
    <div className="space-y-4">
      <PageHeader title="Branches" subtitle="Add or edit branch offices used for booking, manifest and DRS" />
      <Card><CardHeader><CardTitle>{editingId ? "Edit Branch" : "Add New Branch"}</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3">
          <div><Label>Branch Code *</Label><Input value={f.branch_code} onChange={(e) => setF({ ...f, branch_code: e.target.value.toUpperCase() })} placeholder="DEL01" /></div>
          <div><Label>Branch Name *</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Delhi Okhla" /></div>
          <div><Label>India Post Location</Label><IndiaPostPicker value={f.city || f.pincode} onSelect={(loc) => setF({ ...f, city: loc.city, state: loc.state, pincode: loc.pincode })} placeholder="Search city / pincode" /></div>
          <div><Label>City</Label><Input value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} /></div>
          <div><Label>State</Label><Input value={f.state} onChange={(e) => setF({ ...f, state: e.target.value })} /></div>
          <div><Label>Pincode</Label><Input maxLength={6} value={f.pincode} onChange={(e) => setF({ ...f, pincode: e.target.value.replace(/\D/g, "") })} /></div>
          <div><Label>Phone</Label><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></div>
          <div><Label>Email</Label><Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} placeholder="branch@fahadglobal.com" /></div>
          <div><Label>Contact Person</Label><Input value={f.contact_person} onChange={(e) => setF({ ...f, contact_person: e.target.value })} placeholder="Branch Manager Name" /></div>
          <div className="md:col-span-3"><Label>Address</Label><Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></div>
          <div className="md:col-span-3 flex justify-end gap-2">
            {editingId && <Button variant="outline" onClick={() => { setF(empty); setEditingId(null); }}>Cancel</Button>}
            <Button onClick={save}>{editingId ? "Update" : "Add Branch"}</Button>
          </div>
        </CardContent>
      </Card>
      <Card><CardHeader><CardTitle>All Branches ({list.length})</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3">Code</th><th>Name</th><th>City</th><th>State</th><th>Pincode</th><th>Phone</th><th>Email</th><th>Contact</th><th className="p-3">Actions</th></tr></thead>
            <tbody>{list.map((b) => (
              <tr key={b.id} className="border-t">
                <td className="p-3 font-mono">{b.branch_code}</td>
                <td>{b.name}</td><td>{b.city}</td><td>{b.state}</td><td>{b.pincode ?? "—"}</td><td>{b.phone}</td><td>{b.email}</td><td>{b.contact_person}</td>
                <td className="p-3 flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => edit(b)}><Pencil className="h-3 w-3" /></Button>
                  <Button size="sm" variant="outline" onClick={() => remove(b.id)}><Trash2 className="h-3 w-3" /></Button>
                </td>
              </tr>
            ))}</tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
