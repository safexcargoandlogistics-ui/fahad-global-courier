import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { PageHeader } from "@/components/PageHeader";
import { CheckCircle2, Clock } from "lucide-react";

const MODULES = [
  { area: "Website", name: "Public Home", url: "/", status: "live", how: "Open homepage; check services, branches, contact, tracking widget." },
  { area: "Website", name: "Public Tracking", url: "/track", status: "live", how: "Enter any AWB (e.g. FGL000001) and verify timeline; weight is hidden publicly." },
  { area: "Auth", name: "Login / Signup", url: "/auth", status: "live", how: "info@fahadglobal.com auto-becomes Admin; others get Client role." },
  { area: "Software", name: "Dashboard", url: "/app", status: "live", how: "KPIs and recent shipments." },
  { area: "Software", name: "New Booking", url: "/app/booking", status: "live", how: "Auto weight (LxBxH/divisor), auto freight + fuel + 18% GST, prints docket + sticker." },
  { area: "Software", name: "Shipments", url: "/app/shipments", status: "live", how: "Search/filter, reprint label & docket." },
  { area: "Software", name: "Outgoing Manifest", url: "/app/manifest/outgoing", status: "live", how: "Pick origin/destination branch, select bookings, create + print." },
  { area: "Software", name: "Receive Incoming Manifest", url: "/app/receive", status: "new", how: "Open inbound manifest, scan AWBs OR one-click receive all; updates status to received_at_branch." },
  { area: "Software", name: "DRS", url: "/app/drs", status: "live", how: "Create delivery run sheet with addresses; print." },
  { area: "Software", name: "Delivery Update", url: "/app/delivery", status: "live", how: "Mark delivered with POD upload, signature name, date/time." },
  { area: "Billing", name: "Invoices", url: "/app/invoices", status: "live", how: "Generate per client; export PDF + Excel." },
  { area: "Billing", name: "Ledger", url: "/app/ledger", status: "live", how: "Add payments; print client ledger." },
  { area: "Billing", name: "Rate Cards", url: "/app/rates", status: "live", how: "Per-client zone/weight slabs." },
  { area: "Reports", name: "MIS", url: "/app/mis", status: "live", how: "Filter by date/branch/client; export." },
  { area: "Admin", name: "Clients", url: "/app/clients", status: "live", how: "Auto client code FGLC00001; link to a User ID for portal access." },
  { area: "Admin", name: "Users & Roles + Branch", url: "/app/users", status: "live", how: "Assign role (Admin / Branch Manager / Staff / Client) + branch." },
  { area: "Portal", name: "Client Portal", url: "/portal", status: "live", how: "Log in as a client user — sees only own shipments + ledger." },
];

export default function Status() {
  const groups = Array.from(new Set(MODULES.map((m) => m.area)));
  return (
    <div className="space-y-4">
      <PageHeader title="System Status & Trial Sheet" subtitle="Module-wise checklist with links and how to test each one" />
      {groups.map((g) => (
        <Card key={g}><CardHeader><CardTitle>{g}</CardTitle></CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left"><tr><th className="p-3">Module</th><th>Status</th><th>Open</th><th>How to test</th></tr></thead>
              <tbody>{MODULES.filter((m) => m.area === g).map((m) => (
                <tr key={m.url} className="border-t align-top">
                  <td className="p-3 font-medium">{m.name}</td>
                  <td>{m.status === "new" ? <Badge className="bg-accent text-accent-foreground"><Clock className="h-3 w-3 mr-1" />New</Badge> : <Badge variant="secondary"><CheckCircle2 className="h-3 w-3 mr-1" />Live</Badge>}</td>
                  <td><Link to={m.url} className="text-primary underline font-mono text-xs">{m.url}</Link></td>
                  <td className="text-muted-foreground">{m.how}</td>
                </tr>
              ))}</tbody>
            </table>
          </CardContent></Card>
      ))}
    </div>
  );
}