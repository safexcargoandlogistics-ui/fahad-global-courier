import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/PageHeader";
import { format } from "date-fns";
import { toast } from "sonner";
import { CheckCircle2, RotateCcw, MapPin, AlertTriangle, Calendar } from "lucide-react";

const ICONS: any = { reattempt: RotateCcw, reschedule: Calendar, self_collect: MapPin, rto: AlertTriangle };
const COLOR: any = { reattempt: "bg-blue-500/10 text-blue-700", reschedule: "bg-amber-500/10 text-amber-700", self_collect: "bg-emerald-500/10 text-emerald-700", rto: "bg-red-500/10 text-red-700" };

export default function TrackingActions() {
  const [rows, setRows] = useState<any[]>([]);
  const load = async () => {
    const { data } = await (supabase as any).from("tracking_actions").select("*").order("created_at", { ascending: false }).limit(200);
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, []);
  const setStatus = async (id: string, status: string) => {
    const { error } = await (supabase as any).from("tracking_actions").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Updated"); load();
  };
  return (
    <div className="space-y-4">
      <PageHeader title="Customer Tracking Actions" subtitle="Requests submitted from the public tracking page for undelivered shipments" />
      <Card><CardHeader><CardTitle>Pending & Recent ({rows.length})</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left">
              <tr><th className="p-3">When</th><th>AWB</th><th>Action</th><th>Details</th><th>Contact</th><th>Status</th><th className="p-3">Manage</th></tr>
            </thead>
            <tbody>
              {rows.map((r) => { const Icon = ICONS[r.action] ?? AlertTriangle; return (
                <tr key={r.id} className="border-t">
                  <td className="p-3 whitespace-nowrap">{format(new Date(r.created_at), "dd MMM, HH:mm")}</td>
                  <td className="font-mono">{r.awb_number}</td>
                  <td><Badge variant="secondary" className={`${COLOR[r.action]} capitalize gap-1`}><Icon className="h-3 w-3" />{r.action.replace("_", " ")}</Badge></td>
                  <td className="text-xs max-w-[260px]">
                    {r.action === "reschedule" && r.payload?.date && <div>📅 {r.payload.date} {r.payload.time}</div>}
                    {r.payload?.note && <div className="text-muted-foreground">{r.payload.note}</div>}
                  </td>
                  <td className="text-xs">{r.contact_name && <div>{r.contact_name}</div>}{r.contact_phone && <div className="text-muted-foreground">{r.contact_phone}</div>}</td>
                  <td><Badge className="capitalize">{r.status}</Badge></td>
                  <td className="p-3 space-x-1 whitespace-nowrap">
                    {r.status !== "completed" && <Button size="sm" variant="outline" onClick={() => setStatus(r.id, "completed")}><CheckCircle2 className="h-3 w-3 mr-1" />Done</Button>}
                    {r.status === "pending" && <Button size="sm" variant="outline" onClick={() => setStatus(r.id, "in_progress")}>Working</Button>}
                  </td>
                </tr>
              ); })}
              {!rows.length && <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">No customer requests yet.</td></tr>}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}