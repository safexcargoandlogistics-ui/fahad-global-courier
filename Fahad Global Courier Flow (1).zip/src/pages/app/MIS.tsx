import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function MIS() {
  const today = new Date().toISOString().slice(0, 10);
  const monthStart = today.slice(0, 8) + "01";
  const [from, setFrom] = useState(monthStart);
  const [to, setTo] = useState(today);
  const [clientId, setClientId] = useState<string>("all");
  const [status, setStatus] = useState<string>("all");
  const [clients, setClients] = useState<any[]>([]);
  const [rows, setRows] = useState<any[]>([]);
  const [stats, setStats] = useState({ booked: 0, in_transit: 0, delivered: 0, undelivered: 0, rto: 0, total_amount: 0, total_weight: 0, count: 0 });

  const load = async () => {
    let qb = supabase.from("shipments").select("*, clients(name)").gte("booking_date", from).lte("booking_date", to).order("booking_date", { ascending: false });
    if (clientId && clientId !== "all") qb = qb.eq("client_id", clientId);
    if (status && status !== "all") qb = qb.eq("status", status as any);
    const { data } = await qb;
    const list = data ?? [];
    setRows(list);
    const s = { booked: 0, in_transit: 0, delivered: 0, undelivered: 0, rto: 0, total_amount: 0, total_weight: 0, count: list.length };
    list.forEach((r: any) => { (s as any)[r.status] = ((s as any)[r.status] ?? 0) + 1; s.total_amount += Number(r.total_amount || 0); s.total_weight += Number(r.chargeable_weight || 0); });
    setStats(s);
  };
  useEffect(() => { load(); }, [clientId, status]);
  useEffect(() => { supabase.from("clients").select("id,name,client_code").eq("active", true).order("name").then(({ data }) => setClients(data ?? [])); }, []);

  const exportCsv = () => {
    const head = ["AWB","Date","Client","Receiver","City","Pin","Mode","Service","Pcs","Wt","Status","Amount"];
    const lines = [head.join(",")].concat(rows.map((r) => [r.awb_number, r.booking_date, r.clients?.name || "", r.receiver_name, r.receiver_city, r.receiver_pincode, r.transport_mode || r.mode, r.service_type, r.pieces, r.chargeable_weight, r.status, r.total_amount].map((v) => `"${(v ?? "").toString().replace(/"/g, '""')}"`).join(",")));
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = `MIS_${from}_${to}.csv`; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">MIS Report</h1>
      <Card><CardContent className="pt-6 flex flex-wrap gap-3 items-end">
        <div><Label>From</Label><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
        <div><Label>To</Label><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        <div className="min-w-[240px]"><Label>Client</Label>
          <Select value={clientId} onValueChange={setClientId}>
            <SelectTrigger><SelectValue placeholder="All clients" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All clients</SelectItem>
              {clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.client_code} — {c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="min-w-[200px]"><Label>Status</Label>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger><SelectValue placeholder="All status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All status</SelectItem>
              <SelectItem value="booked">Booked / Pending</SelectItem>
              <SelectItem value="manifested">Manifested</SelectItem>
              <SelectItem value="in_transit">In Transit</SelectItem>
              <SelectItem value="out_for_delivery">Out For Delivery</SelectItem>
              <SelectItem value="delivered">Delivered</SelectItem>
              <SelectItem value="undelivered">Undelivered</SelectItem>
              <SelectItem value="rto">RTO</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={load}>Run</Button>
        <Button variant="outline" onClick={exportCsv}>Export CSV</Button>
      </CardContent></Card>
      <div className="grid gap-3 md:grid-cols-4">
        {[
          { l: "Total Bookings", v: stats.count },
          { l: "Delivered", v: stats.delivered },
          { l: "In Transit / OFD", v: (stats.in_transit + (stats as any).out_for_delivery || 0) },
          { l: "Undelivered / RTO", v: stats.undelivered + stats.rto },
          { l: "Total Weight (kg)", v: stats.total_weight.toFixed(2) },
          { l: "Total Revenue (₹)", v: stats.total_amount.toFixed(2) },
        ].map((c) => (
          <Card key={c.l}><CardHeader className="pb-2"><CardTitle className="text-xs text-muted-foreground font-medium uppercase">{c.l}</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{c.v}</div></CardContent></Card>
        ))}
      </div>
      <Card><CardContent className="p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left"><tr><th className="p-3">AWB</th><th>Date</th><th>Client</th><th>City</th><th>Service</th><th>Wt</th><th>Status</th><th className="text-right p-3">Amount</th></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.id} className="border-t"><td className="p-3 font-mono">{r.awb_number}</td><td>{r.booking_date}</td><td>{r.clients?.name || "—"}</td><td>{r.receiver_city}</td><td>{r.service_type}</td><td>{r.chargeable_weight}</td><td className="capitalize">{r.status.replace(/_/g," ")}</td><td className="text-right p-3">₹{Number(r.total_amount).toFixed(2)}</td></tr>
          ))}{rows.length === 0 && <tr><td colSpan={8} className="p-6 text-center text-muted-foreground">No data</td></tr>}</tbody>
        </table>
      </CardContent></Card>
    </div>
  );
}