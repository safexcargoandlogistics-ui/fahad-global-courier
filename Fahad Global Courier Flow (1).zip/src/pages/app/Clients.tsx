import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const empty = { client_code: "", name: "", contact_person: "", email: "", phone: "", address: "", city: "", state: "", pincode: "", gstin: "", pan: "", credit_limit: 0, opening_balance: 0, user_id: "" };

export default function Clients() {
  const [rows, setRows] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState<any>(empty);
  const load = async () => { const { data } = await supabase.from("clients").select("*").order("name"); setRows(data ?? []); };
  useEffect(() => { load(); }, []);
  const set = (k: string, v: any) => setF((p: any) => ({ ...p, [k]: v }));
  const save = async () => {
    const payload = { ...f };
    if (!payload.client_code) delete payload.client_code;
    if (!payload.user_id) delete payload.user_id;
    const { error } = await supabase.from("clients").insert(payload);
    if (error) toast.error(error.message); else { toast.success("Client added"); setOpen(false); setF(empty); load(); }
  };
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Clients</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button>+ New Client</Button></DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>New Client</DialogTitle></DialogHeader>
            <div className="grid gap-3 md:grid-cols-2">
              <div><Label>Client Code</Label><Input value={f.client_code} onChange={(e) => set("client_code", e.target.value.toUpperCase())} placeholder="Auto generated" /></div>
              <div><Label>Name *</Label><Input value={f.name} onChange={(e) => set("name", e.target.value)} /></div>
              <div><Label>Contact Person</Label><Input value={f.contact_person} onChange={(e) => set("contact_person", e.target.value)} /></div>
              <div><Label>Email</Label><Input type="email" value={f.email} onChange={(e) => set("email", e.target.value)} /></div>
              <div><Label>Phone</Label><Input value={f.phone} onChange={(e) => set("phone", e.target.value)} /></div>
              <div><Label>GSTIN</Label><Input value={f.gstin} onChange={(e) => set("gstin", e.target.value)} /></div>
              <div><Label>PAN</Label><Input value={f.pan} onChange={(e) => set("pan", e.target.value.toUpperCase())} /></div>
              <div className="md:col-span-2"><Label>Address</Label><Textarea value={f.address} onChange={(e) => set("address", e.target.value)} /></div>
              <div><Label>City</Label><Input value={f.city} onChange={(e) => set("city", e.target.value)} /></div>
              <div><Label>State</Label><Input value={f.state} onChange={(e) => set("state", e.target.value)} /></div>
              <div><Label>Pincode</Label><Input value={f.pincode} onChange={(e) => set("pincode", e.target.value)} /></div>
              <div><Label>Credit Limit</Label><Input type="number" value={f.credit_limit} onChange={(e) => set("credit_limit", +e.target.value)} /></div>
              <div><Label>Opening Balance</Label><Input type="number" value={f.opening_balance} onChange={(e) => set("opening_balance", +e.target.value)} /></div>
              <div className="md:col-span-2"><Label>Linked Login User ID</Label><Input value={f.user_id} onChange={(e) => set("user_id", e.target.value)} placeholder="Optional — paste client user ID after signup" /></div>
              <div className="md:col-span-2 flex justify-end"><Button onClick={save}>Save</Button></div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      <Card><CardContent className="p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left"><tr><th className="p-3">Code</th><th>Name</th><th>City</th><th>Phone</th><th>GSTIN</th><th>PAN</th><th>Login</th><th>Credit</th></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.id} className="border-t"><td className="p-3 font-mono">{r.client_code}</td><td>{r.name}</td><td>{r.city}</td><td>{r.phone}</td><td>{r.gstin}</td><td>{r.pan ?? "—"}</td><td>{r.user_id ? <Badge variant="secondary">Linked</Badge> : <Badge variant="outline">Pending</Badge>}</td><td>₹{r.credit_limit}</td></tr>
          ))}{rows.length === 0 && <tr><td colSpan={8} className="p-6 text-center text-muted-foreground">No clients yet</td></tr>}</tbody>
        </table>
      </CardContent></Card>
    </div>
  );
}
