import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { Pencil, Trash2, Upload, Download, AlertTriangle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import * as XLSX from "xlsx";
import { IndiaPostPicker } from "@/components/IndiaPostPicker";

const empty = { pincode: "", city: "", state: "", branch_id: null as string | null, serviceable: true, cod_available: false, tat_days: 2 };

export default function Pincodes() {
  const { isAdmin, isBranchManager } = useAuth();
  const canManage = isAdmin || isBranchManager;
  const [list, setList] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [f, setF] = useState<any>(empty);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [csvBusy, setCsvBusy] = useState(false);

  const load = async () => {
    let q = (supabase as any).from("pincodes").select("*, branches(name,city)").order("pincode").limit(2000);
    if (search) q = q.ilike("pincode", `${search}%`);
    const { data } = await q;
    setList(data ?? []);
    if (!branches.length) {
      const { data: b } = await (supabase as any).from("branches").select("id,name,city,branch_code").order("name");
      setBranches(b ?? []);
    }
  };
  useEffect(() => { if (canManage) load(); }, [canManage, search]);

  const save = async () => {
    if (!f.pincode || f.pincode.length !== 6) { toast.error("Valid 6-digit pincode required"); return; }
    if (editingId) {
      const { error } = await (supabase as any).from("pincodes").update(f).eq("id", editingId);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await (supabase as any).from("pincodes").upsert(f, { onConflict: "pincode" });
      if (error) return toast.error(error.message);
    }
    toast.success("Saved"); setF(empty); setEditingId(null); load();
  };
  const edit = (p: any) => { setF({ pincode: p.pincode, city: p.city ?? "", state: p.state ?? "", branch_id: p.branch_id, serviceable: p.serviceable, cod_available: p.cod_available, tat_days: p.tat_days ?? 2 }); setEditingId(p.id); };
  const remove = async (id: string) => {
    if (!confirm("Delete pincode?")) return;
    const { error } = await (supabase as any).from("pincodes").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); load();
  };

  const purgeAll = async () => {
    if (!confirm("Delete ALL pincodes? This cannot be undone. Use this before re-uploading a fresh sheet.")) return;
    const { error } = await (supabase as any).from("pincodes").delete().neq("pincode", "");
    if (error) return toast.error(error.message);
    toast.success("All pincodes cleared"); load();
  };

  const downloadTemplate = () => {
    const csv = "pincode,city,state,branch_code,serviceable,cod_available,tat_days\n110001,New Delhi,Delhi,DEL01,Y,Y,1\n400001,Mumbai,Maharashtra,MUM01,Y,N,2\n";
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "pincodes-template.csv"; a.click(); URL.revokeObjectURL(url);
  };

  // Flexible header detection
  const HEAD_MAP: Record<string, string[]> = {
    pincode: ["pincode", "pin", "pin code", "zip", "zipcode", "postal", "postal code", "postcode"],
    city: ["city", "district", "town", "location"],
    state: ["state", "region", "province"],
    branch_code: ["branch_code", "branch code", "branch", "hub", "hub code"],
    serviceable: ["serviceable", "service", "available", "active", "deliverable", "status"],
    cod_available: ["cod_available", "cod", "cash on delivery"],
    tat_days: ["tat_days", "tat", "days", "tat days", "transit time", "transit", "sla"],
  };
  const findCol = (headers: string[], key: string) => {
    const cands = HEAD_MAP[key];
    for (let i = 0; i < headers.length; i++) {
      const h = headers[i].toString().toLowerCase().trim();
      if (cands.some((c) => h === c || h.replace(/[_\s-]/g, "") === c.replace(/[_\s-]/g, ""))) return i;
    }
    return -1;
  };

  const parseRows = (raw: any[][]): any[] => {
    if (!raw.length) return [];
    const headers = raw[0].map((h) => String(h ?? ""));
    const colP = findCol(headers, "pincode");
    if (colP === -1) throw new Error("Could not find a Pincode column (accepted: pincode, pin, zip, postal code)");
    const colC = findCol(headers, "city");
    const colS = findCol(headers, "state");
    const colB = findCol(headers, "branch_code");
    const colSvc = findCol(headers, "serviceable");
    const colCod = findCol(headers, "cod_available");
    const colT = findCol(headers, "tat_days");
    const truthy = (v: any) => ["y", "yes", "true", "1", "serviceable", "active", "available"].includes(String(v ?? "").toLowerCase().trim());
    const rows: any[] = [];
    for (let i = 1; i < raw.length; i++) {
      const r = raw[i] ?? [];
      const pin = String(r[colP] ?? "").trim();
      if (!/^\d{6}$/.test(pin)) continue;
      const branchCode = colB > -1 ? String(r[colB] ?? "").trim() : "";
      const branch = branchCode ? branches.find((b) => b.branch_code?.toUpperCase() === branchCode.toUpperCase()) : null;
      rows.push({
        pincode: pin,
        city: colC > -1 ? String(r[colC] ?? "").trim() || null : null,
        state: colS > -1 ? String(r[colS] ?? "").trim() || null : null,
        branch_id: branch?.id ?? null,
        serviceable: colSvc > -1 ? truthy(r[colSvc]) : true,
        cod_available: colCod > -1 ? truthy(r[colCod]) : false,
        tat_days: colT > -1 ? Number(r[colT]) || 2 : 2,
      });
    }
    return rows;
  };

  const uploadCsv = async (file: File) => {
    setCsvBusy(true);
    try {
      let raw: any[][] = [];
      const isXls = /\.xlsx?$/i.test(file.name);
      if (isXls) {
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        raw = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" }) as any[][];
      } else {
        const text = await file.text();
        const lines = text.trim().split(/\r?\n/);
        raw = lines.map((l) => l.split(/[,;\t]/).map((c) => c.trim().replace(/^"|"$/g, "")));
      }
      const valid = parseRows(raw);
      if (!valid.length) { toast.error("No valid rows found in file"); return; }
      const chunkSize = 500;
      for (let i = 0; i < valid.length; i += chunkSize) {
        const { error } = await (supabase as any).from("pincodes").upsert(valid.slice(i, i + chunkSize), { onConflict: "pincode" });
        if (error) throw error;
      }
      toast.success(`Imported ${valid.length} pincodes`); load();
    } catch (e: any) { toast.error("Import failed: " + e.message); }
    finally { setCsvBusy(false); }
  };

  if (!canManage) return <div className="text-muted-foreground">Admin or Branch Manager only</div>;

  return (
    <div className="space-y-4">
      <PageHeader title="Serviceable Pincodes" subtitle="Manage serviceable pincode list (also visible on public website pincode-check page)" />
      <Card><CardHeader><CardTitle className="flex items-center justify-between">{editingId ? "Edit Pincode" : "Add Pincode"}<div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={downloadTemplate}><Download className="h-3 w-3 mr-1" />Template</Button>
        <label className={`inline-flex items-center gap-1 cursor-pointer rounded-md border px-3 py-1.5 text-sm ${csvBusy ? "opacity-50" : ""}`}>
          <Upload className="h-3 w-3" /> {csvBusy ? "Uploading…" : "Upload CSV"}
          <input type="file" accept=".csv,.xlsx,.xls" className="hidden" disabled={csvBusy} onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadCsv(f); e.target.value = ""; }} />
        </label>
        <Button size="sm" variant="destructive" onClick={purgeAll}><AlertTriangle className="h-3 w-3 mr-1" />Delete All</Button>
      </div></CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-4">
          <div><Label>India Post Location</Label><IndiaPostPicker value={f.city || f.pincode} onSelect={(loc) => setF({ ...f, pincode: loc.pincode, city: loc.city, state: loc.state })} placeholder="Search city / pincode" /></div>
          <div><Label>Pincode *</Label><Input maxLength={6} value={f.pincode} onChange={(e) => setF({ ...f, pincode: e.target.value.replace(/\D/g, "") })} /></div>
          <div><Label>City</Label><Input value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} /></div>
          <div><Label>State</Label><Input value={f.state} onChange={(e) => setF({ ...f, state: e.target.value })} /></div>
          <div><Label>Branch</Label>
            <Select value={f.branch_id ?? "none"} onValueChange={(v) => setF({ ...f, branch_id: v === "none" ? null : v })}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent><SelectItem value="none">None</SelectItem>{branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.name} ({b.city})</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>TAT Days</Label><Input type="number" value={f.tat_days} onChange={(e) => setF({ ...f, tat_days: Number(e.target.value) })} /></div>
          <div className="flex items-end gap-2"><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.serviceable} onChange={(e) => setF({ ...f, serviceable: e.target.checked })} />Serviceable</label></div>
          <div className="flex items-end gap-2"><label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.cod_available} onChange={(e) => setF({ ...f, cod_available: e.target.checked })} />COD</label></div>
          <div className="md:col-span-4 flex justify-end gap-2">
            {editingId && <Button variant="outline" onClick={() => { setF(empty); setEditingId(null); }}>Cancel</Button>}
            <Button onClick={save}>{editingId ? "Update" : "Add"}</Button>
          </div>
        </CardContent>
      </Card>
      <Card><CardHeader><CardTitle className="flex items-center justify-between">Pincodes ({list.length})<Input className="w-48" placeholder="Search pincode…" value={search} onChange={(e) => setSearch(e.target.value.replace(/\D/g, ""))} /></CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3">Pincode</th><th>City</th><th>State</th><th>Branch</th><th>TAT</th><th>Service</th><th>COD</th><th className="p-3">Actions</th></tr></thead>
            <tbody>{list.map((p) => (
              <tr key={p.id} className="border-t">
                <td className="p-3 font-mono">{p.pincode}</td>
                <td>{p.city}</td><td>{p.state}</td><td>{p.branches?.name ?? "—"}</td><td>{p.tat_days}d</td>
                <td>{p.serviceable ? "✅" : "❌"}</td><td>{p.cod_available ? "✅" : "❌"}</td>
                <td className="p-3 flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => edit(p)}><Pencil className="h-3 w-3" /></Button>
                  <Button size="sm" variant="outline" onClick={() => remove(p.id)}><Trash2 className="h-3 w-3" /></Button>
                </td>
              </tr>
            ))}{!list.length && <tr><td colSpan={8} className="p-6 text-center text-muted-foreground">No pincodes yet — upload CSV or add manually.</td></tr>}</tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
