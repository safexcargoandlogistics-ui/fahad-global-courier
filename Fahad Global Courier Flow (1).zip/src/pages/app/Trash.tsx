import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { toast } from "sonner";
import { RotateCcw, Trash2 } from "lucide-react";
import { format } from "date-fns";

export default function Trash() {
  const { isAdmin } = useAuth();
  const [rows, setRows] = useState<any[]>([]);

  const load = async () => {
    const { data } = await (supabase as any).from("shipments_trash").select("*").order("deleted_at", { ascending: false });
    setRows(data ?? []);
  };
  useEffect(() => { if (isAdmin) load(); }, [isAdmin]);

  const restore = async (id: string) => {
    const { error } = await (supabase as any).rpc("restore_shipment", { _trash_id: id });
    if (error) return toast.error(error.message);
    toast.success("Shipment restored"); load();
  };
  const purge = async (id: string) => {
    if (!confirm("Permanently delete this trashed shipment? This cannot be undone.")) return;
    const { error } = await (supabase as any).from("shipments_trash").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Permanently deleted"); load();
  };

  if (!isAdmin) return <div className="text-muted-foreground">Admin only</div>;

  return (
    <div className="space-y-4">
      <PageHeader title="Recycle Bin" subtitle="Recover deleted shipments. Admin only." />
      <Card><CardHeader><CardTitle>Deleted Shipments ({rows.length})</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3">AWB</th><th>Receiver</th><th>City</th><th>Deleted</th><th className="p-3">Actions</th></tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="p-3 font-mono">{r.awb_number}</td>
                <td>{r.shipment_data?.receiver_name}</td>
                <td>{r.shipment_data?.receiver_city}</td>
                <td className="text-xs">{format(new Date(r.deleted_at), "dd MMM yyyy, HH:mm")}</td>
                <td className="p-3 space-x-1 whitespace-nowrap">
                  <Button size="sm" onClick={() => restore(r.id)}><RotateCcw className="h-3 w-3 mr-1" />Restore</Button>
                  <Button size="sm" variant="destructive" onClick={() => purge(r.id)}><Trash2 className="h-3 w-3" /></Button>
                </td>
              </tr>
            ))}{rows.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-muted-foreground">No deleted shipments.</td></tr>}</tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}