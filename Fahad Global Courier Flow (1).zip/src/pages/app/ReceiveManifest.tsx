import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth";
import { PageHeader } from "@/components/PageHeader";
import { CheckCircle2, ScanLine, Zap } from "lucide-react";
import { Label } from "@/components/ui/label";

const nowLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };

export default function ReceiveManifest() {
  const { user } = useAuth();
  const [manifests, setManifests] = useState<any[]>([]);
  const [active, setActive] = useState<any | null>(null);
  const [items, setItems] = useState<any[]>([]);
  const [scanned, setScanned] = useState<Record<string, boolean>>({});
  const [scan, setScan] = useState("");
  const [receivedAt, setReceivedAt] = useState<string>(nowLocal());

  const loadManifests = async () => {
    const { data: prof } = await supabase.from("profiles").select("branch_id").eq("id", user!.id).maybeSingle();
    const myBranch = prof?.branch_id;
    let cityName: string | null = null;
    if (myBranch) {
      const { data: br } = await (supabase as any).from("branches").select("city,name").eq("id", myBranch).maybeSingle();
      cityName = br?.city ?? br?.name ?? null;
    }
    let q = supabase.from("manifests").select("*").order("created_at", { ascending: false }).limit(50);
    // Show all manifests if user has no branch; else match by branch_id OR text destination
    if (myBranch && cityName) {
      q = q.or(`destination_branch_id.eq.${myBranch},destination.ilike.%${cityName}%`);
    } else if (myBranch) {
      q = q.eq("destination_branch_id", myBranch);
    }
    const { data } = await q;
    setManifests(data ?? []);
  };
  const openManifest = async (m: any) => {
    setActive(m); setScanned({}); setReceivedAt(nowLocal());
    const { data: links } = await supabase.from("manifest_shipments").select("shipment_id").eq("manifest_id", m.id);
    const ids = (links ?? []).map((l: any) => l.shipment_id);
    if (!ids.length) { setItems([]); return; }
    const { data: ship } = await supabase.from("shipments").select("id,awb_number,receiver_name,receiver_city,pieces,chargeable_weight,status,received_at").in("id", ids);
    setItems(ship ?? []);
    const initial: Record<string, boolean> = {};
    (ship ?? []).forEach((s: any) => { if (s.received_at) initial[s.id] = true; });
    setScanned(initial);
  };
  useEffect(() => { if (user) loadManifests(); }, [user]);

  const onScan = (val: string) => {
    const code = val.trim().toUpperCase(); if (!code) return;
    const found = items.find((s) => s.awb_number === code);
    if (!found) { toast.error("AWB not in this manifest"); return; }
    setScanned((p) => ({ ...p, [found.id]: true }));
    setScan(""); toast.success(`Scanned ${code}`);
  };

  const receive = async (mode: "scanned" | "all") => {
    if (!active) return;
    const ids = mode === "all" ? items.map((s) => s.id) : Object.keys(scanned).filter((k) => scanned[k]);
    if (!ids.length) { toast.error("Nothing selected"); return; }
    const { data: prof } = await supabase.from("profiles").select("branch_id").eq("id", user!.id).maybeSingle();
    const branchId = prof?.branch_id ?? active.destination_branch_id;
    const now = new Date(receivedAt).toISOString();
    const { error } = await supabase.from("shipments").update({
      status: "received_at_branch" as any, received_at: now, received_by: user!.id, current_branch_id: branchId,
    }).in("id", ids);
    if (error) { toast.error(error.message); return; }
    await supabase.from("tracking_events").insert(ids.map((id) => ({
      shipment_id: id, status: "received_at_branch" as any, location: active.destination, remarks: `Received at ${active.destination || "branch"} (${active.manifest_no})`, created_by: user!.id, event_at: now,
    })));
    const missing = items.filter((s) => !ids.includes(s.id) && !s.received_at).map((s) => s.awb_number);
    toast.success(`Received ${ids.length} shipment(s). ${missing.length ? "Missing: " + missing.join(", ") : ""}`);
    openManifest(active); loadManifests();
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Receive Incoming Manifest" subtitle="Scan AWBs or one-click receive entire manifest at destination branch" />
      {!active ? (
        <Card><CardHeader><CardTitle>Incoming Manifests</CardTitle></CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left"><tr><th className="p-3">No</th><th>Date</th><th>Route</th><th>Vehicle</th><th>Pcs</th><th></th></tr></thead>
              <tbody>{manifests.map((m) => (
                <tr key={m.id} className="border-t">
                  <td className="p-3 font-mono">{m.manifest_no}</td><td>{m.manifest_date}</td>
                  <td>{m.origin} → {m.destination}</td><td>{m.vehicle_no}</td><td>{m.total_pieces}</td>
                  <td className="p-3"><Button size="sm" onClick={() => openManifest(m)}>Open</Button></td>
                </tr>
              ))}{!manifests.length && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No incoming manifests for your branch.</td></tr>}</tbody>
            </table>
          </CardContent></Card>
      ) : (
        <>
          <Card><CardHeader className="flex flex-row items-center justify-between"><CardTitle>{active.manifest_no} — {active.origin} → {active.destination}</CardTitle><Button variant="outline" size="sm" onClick={() => setActive(null)}>← Back</Button></CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-[1fr_1fr_auto_auto] items-end">
              <div>
                <label className="text-xs text-muted-foreground flex items-center gap-1"><ScanLine className="h-3 w-3" />Scan / Type AWB</label>
                <Input autoFocus value={scan} onChange={(e) => setScan(e.target.value.toUpperCase())} onKeyDown={(e) => { if (e.key === "Enter") onScan(scan); }} placeholder="FGL000123" />
              </div>
              <div>
                <Label className="text-xs">Received Date & Time</Label>
                <Input type="datetime-local" value={receivedAt} onChange={(e) => setReceivedAt(e.target.value)} />
              </div>
              <Button onClick={() => receive("scanned")}><CheckCircle2 className="h-4 w-4 mr-1" />Receive Scanned ({Object.values(scanned).filter(Boolean).length})</Button>
              <Button variant="secondary" onClick={() => receive("all")}><Zap className="h-4 w-4 mr-1" />One-click Receive All</Button>
            </CardContent></Card>
          <Card><CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left"><tr><th className="p-3 w-10"></th><th>AWB</th><th>Receiver</th><th>City</th><th>Pcs</th><th>Wt</th><th>Status</th></tr></thead>
              <tbody>{items.map((s) => (
                <tr key={s.id} className={`border-t ${scanned[s.id] ? "bg-success/5" : ""}`}>
                  <td className="p-3"><Checkbox checked={!!scanned[s.id]} onCheckedChange={(v) => setScanned((p) => ({ ...p, [s.id]: !!v }))} /></td>
                  <td className="font-mono">{s.awb_number}</td><td>{s.receiver_name}</td><td>{s.receiver_city}</td><td>{s.pieces}</td><td>{s.chargeable_weight}</td>
                  <td>{s.received_at ? <Badge variant="secondary">Received</Badge> : <Badge variant="outline">Pending</Badge>}</td>
                </tr>
              ))}</tbody>
            </table>
          </CardContent></Card>
        </>
      )}
    </div>
  );
}