import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Printer } from "lucide-react";
import { printDRS } from "@/lib/printDocs";
import { PageHeader } from "@/components/PageHeader";
import { useAuth } from "@/lib/auth";
import { Pencil, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const nowLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };

export default function DRS() {
  const { isAdmin } = useAuth();
  const [list, setList] = useState<any[]>([]);
  const [shipments, setShipments] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [branchId, setBranchId] = useState<string>("all");
  const [boys, setBoys] = useState<{ name: string; phone: string; branch_id?: string }[]>([]);
  const [picked, setPicked] = useState<Record<string, boolean>>({});
  const [form, setForm] = useState({ drs_no: "", delivery_boy: "", delivery_boy_phone: "", area: "", remarks: "" });
  const [drsAt, setDrsAt] = useState<string>(nowLocal());
  const [awbInput, setAwbInput] = useState("");
  const [editing, setEditing] = useState<any | null>(null);

  const load = async () => {
    const { data } = await supabase.from("drs").select("*").order("created_at", { ascending: false }).limit(50);
    setList(data ?? []);
    const { data: s } = await supabase.from("shipments")
      .select("id,awb_number,receiver_name,receiver_address,receiver_city,receiver_pincode,pieces,status")
      .not("status", "in", "(delivered,cancelled,rto)")
      .order("created_at", { ascending: false }).limit(200);
    setShipments(s ?? []);
    // Build delivery boy registry from past DRS rows (unique by name+phone)
    const { data: boysData } = await supabase.from("drs").select("delivery_boy,delivery_boy_phone,branch_id").not("delivery_boy", "is", null);
    const map = new Map<string, { name: string; phone: string; branch_id?: string }>();
    (boysData ?? []).forEach((b: any) => { const key = `${b.delivery_boy}|${b.delivery_boy_phone || ""}`; if (b.delivery_boy && !map.has(key)) map.set(key, { name: b.delivery_boy, phone: b.delivery_boy_phone || "", branch_id: b.branch_id }); });
    setBoys(Array.from(map.values()));
    const { data: br } = await (supabase as any).from("branches").select("id,branch_code,name,city").eq("active", true).order("name");
    setBranches(br ?? []);
  };
  useEffect(() => { load(); setForm((f) => ({ ...f, drs_no: `DRS-${Date.now().toString().slice(-6)}` })); setDrsAt(nowLocal()); }, []);

  const addByAwb = async () => {
    const code = awbInput.trim().toUpperCase(); if (!code) return;
    const found = shipments.find((s) => s.awb_number === code);
    if (found) { setPicked((p) => ({ ...p, [found.id]: true })); setAwbInput(""); toast.success(`Added ${code}`); return; }
    const { data } = await supabase.from("shipments").select("id,awb_number,receiver_name,receiver_address,receiver_city,receiver_pincode,pieces,status").eq("awb_number", code).maybeSingle();
    if (!data) { toast.error("AWB not found"); return; }
    setShipments((p) => [data, ...p]); setPicked((p) => ({ ...p, [data.id]: true })); setAwbInput("");
  };

  const save = async () => {
    const ids = Object.keys(picked).filter((k) => picked[k]);
    if (!ids.length) { toast.error("Select shipments"); return; }
    if (!form.delivery_boy) { toast.error("Enter delivery boy name"); return; }
    const { data: { user } } = await supabase.auth.getUser();
    const totalPieces = shipments.filter((s) => ids.includes(s.id)).reduce((a, b) => a + b.pieces, 0);
    const ts = new Date(drsAt);
    const branchPayload = branchId && branchId !== "all" ? { branch_id: branchId } : {};
    const { data: d, error } = await supabase.from("drs").insert({ ...form, ...branchPayload, drs_date: ts.toISOString().slice(0,10), total_pieces: totalPieces, created_by: user?.id }).select().single();
    if (error) { toast.error(error.message); return; }
    await supabase.from("drs_shipments").insert(ids.map((id) => ({ drs_id: d.id, shipment_id: id })));
    await supabase.from("shipments").update({ status: "out_for_delivery" }).in("id", ids);
    await supabase.from("tracking_events").insert(ids.map((id) => ({ shipment_id: id, status: "out_for_delivery", location: form.area, remarks: `Out for delivery — ${form.delivery_boy} (${form.drs_no})`, created_by: user?.id, event_at: ts.toISOString() })));
    toast.success("DRS created");
    setPicked({}); load();
  };

  const reprint = async (d: any) => {
    const { data: links } = await supabase.from("drs_shipments").select("shipment_id").eq("drs_id", d.id);
    const ids = (links ?? []).map((l: any) => l.shipment_id);
    const { data: items } = await supabase.from("shipments").select("awb_number,receiver_name,receiver_address,receiver_city,receiver_pincode,pieces").in("id", ids);
    printDRS(d, items ?? []);
  };
  const removeDrs = async (d: any) => {
    if (!confirm(`Delete DRS ${d.drs_no}?`)) return;
    await supabase.from("drs_shipments").delete().eq("drs_id", d.id);
    const { error } = await supabase.from("drs").delete().eq("id", d.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); load();
  };
  const saveEdit = async () => {
    if (!editing) return;
    const { id, ...rest } = editing;
    const { error } = await supabase.from("drs").update(rest).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Updated"); setEditing(null); load();
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Delivery Run Sheet (DRS)" subtitle="Address-wise delivery sheet with timestamp and receiver signature columns" />
      <Card><CardHeader><CardTitle>Create DRS</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-4">
          <div><Label>DRS No</Label><Input value={form.drs_no} onChange={(e) => setForm({ ...form, drs_no: e.target.value })} /></div>
          <div><Label>DRS Date & Time</Label><Input type="datetime-local" value={drsAt} onChange={(e) => setDrsAt(e.target.value)} /></div>
          <div><Label>Branch</Label>
            <Select value={branchId} onValueChange={setBranchId}>
              <SelectTrigger><SelectValue placeholder="Select branch" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">— None —</SelectItem>
                {branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.branch_code} — {b.city}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div><Label>Delivery Boy *</Label>
            <Select value={form.delivery_boy ? `${form.delivery_boy}|${form.delivery_boy_phone || ""}` : ""} onValueChange={(v) => { const [n, p] = v.split("|"); setForm({ ...form, delivery_boy: n, delivery_boy_phone: p || "" }); }}>
              <SelectTrigger><SelectValue placeholder="Select existing boy" /></SelectTrigger>
              <SelectContent>
                {boys.filter((b) => branchId === "all" || !b.branch_id || b.branch_id === branchId).map((b, i) => <SelectItem key={i} value={`${b.name}|${b.phone}`}>{b.name}{b.phone ? ` — ${b.phone}` : ""}</SelectItem>)}
              </SelectContent>
            </Select>
            <Input className="mt-1" placeholder="Or type new name" value={form.delivery_boy} onChange={(e) => setForm({ ...form, delivery_boy: e.target.value })} />
          </div>
          <div><Label>Phone</Label><Input value={form.delivery_boy_phone} onChange={(e) => setForm({ ...form, delivery_boy_phone: e.target.value })} /></div>
          <div><Label>Area</Label><Input value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} /></div>
          <div className="md:col-span-4"><Label>Remarks</Label><Input value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} /></div>
        </CardContent>
      </Card>
      <Card><CardHeader><CardTitle>Shipments to Deliver ({shipments.length})</CardTitle></CardHeader>
        <CardContent className="border-b py-3 flex gap-2">
          <Input placeholder="Add by AWB (multi-leg / re-DRS)" value={awbInput} onChange={(e) => setAwbInput(e.target.value.toUpperCase())} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addByAwb(); } }} />
          <Button type="button" variant="outline" onClick={addByAwb}>Add AWB</Button>
        </CardContent>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3 w-10"></th><th>AWB</th><th>Receiver</th><th>Address</th><th>City</th><th>Pin</th></tr></thead>
            <tbody>{shipments.map((s) => (
              <tr key={s.id} className="border-t">
                <td className="p-3"><Checkbox checked={!!picked[s.id]} onCheckedChange={(v) => setPicked({ ...picked, [s.id]: !!v })} /></td>
                <td className="font-mono">{s.awb_number}</td><td>{s.receiver_name}</td><td className="max-w-xs truncate">{s.receiver_address}</td><td>{s.receiver_city}</td><td>{s.receiver_pincode}</td>
              </tr>
            ))}</tbody>
          </table>
        </CardContent>
        <div className="p-3 border-t flex justify-end"><Button onClick={save}>Create DRS</Button></div>
      </Card>
      <Card><CardHeader><CardTitle>Recent DRS</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3">No</th><th>Date</th><th>Boy</th><th>Area</th><th>Pcs</th><th className="p-3">Actions</th></tr></thead>
            <tbody>{list.map((d) => (
              <tr key={d.id} className="border-t">
                <td className="p-3 font-mono">{d.drs_no}</td><td>{d.drs_date}</td><td>{d.delivery_boy}</td><td>{d.area}</td><td>{d.total_pieces}</td>
                <td className="p-3 space-x-1 whitespace-nowrap">
                  <Button size="sm" variant="outline" onClick={() => reprint(d)}><Printer className="h-3 w-3 mr-1" />Print</Button>
                  {isAdmin && <>
                    <Button size="sm" variant="outline" onClick={() => setEditing(d)}><Pencil className="h-3 w-3" /></Button>
                    <Button size="sm" variant="destructive" onClick={() => removeDrs(d)}><Trash2 className="h-3 w-3" /></Button>
                  </>}
                </td>
              </tr>
            ))}</tbody>
          </table>
        </CardContent>
      </Card>
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit DRS</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3 md:grid-cols-2">
              <div><Label>DRS No</Label><Input value={editing.drs_no} onChange={(e) => setEditing({ ...editing, drs_no: e.target.value })} /></div>
              <div><Label>Date</Label><Input type="date" value={editing.drs_date ?? ""} onChange={(e) => setEditing({ ...editing, drs_date: e.target.value })} /></div>
              <div><Label>Delivery Boy</Label><Input value={editing.delivery_boy ?? ""} onChange={(e) => setEditing({ ...editing, delivery_boy: e.target.value })} /></div>
              <div><Label>Phone</Label><Input value={editing.delivery_boy_phone ?? ""} onChange={(e) => setEditing({ ...editing, delivery_boy_phone: e.target.value })} /></div>
              <div><Label>Area</Label><Input value={editing.area ?? ""} onChange={(e) => setEditing({ ...editing, area: e.target.value })} /></div>
              <div className="md:col-span-2"><Label>Remarks</Label><Input value={editing.remarks ?? ""} onChange={(e) => setEditing({ ...editing, remarks: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={saveEdit}>Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
