import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/PageHeader";
import { format } from "date-fns";
import { CheckCircle2, MapPin, Activity, ArrowRight, User, Phone, Package } from "lucide-react";

export default function MultiTrack() {
  const [input, setInput] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const search = async () => {
    const list = Array.from(new Set(input.split(/[\s,;\n]+/).map((x) => x.trim().toUpperCase()).filter(Boolean)));
    if (!list.length) return;
    setLoading(true);
    const { data: ships } = await supabase.from("shipments").select("*").in("awb_number", list);
    const out: any[] = [];
    for (const code of list) {
      const s = (ships ?? []).find((x: any) => x.awb_number === code);
      if (!s) { out.push({ awb_number: code, _missing: true }); continue; }
      const { data: ev } = await supabase.from("tracking_events").select("status,location,event_at,remarks").eq("shipment_id", s.id).order("event_at", { ascending: false });
      out.push({ ...s, events: ev ?? [] });
    }
    setResults(out);
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Multi-AWB Tracking" subtitle="Track multiple shipments at once with full operational details" />
      <Card>
        <CardContent className="pt-4 space-y-2">
          <textarea className="w-full min-h-[80px] rounded-md border bg-background px-3 py-2 text-sm font-mono" placeholder="Paste AWB numbers — separated by comma, space or newline" value={input} onChange={(e) => setInput(e.target.value.toUpperCase())} />
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => { setInput(""); setResults([]); }}>Clear</Button><Button onClick={search} disabled={loading}>{loading ? "Searching…" : `Track ${input.split(/[\s,;\n]+/).filter(Boolean).length} AWB`}</Button></div>
        </CardContent>
      </Card>

      {results.map((s) => s._missing ? (
        <Card key={s.awb_number}><CardContent className="pt-4 text-sm text-muted-foreground">No shipment found for <span className="font-mono">{s.awb_number}</span></CardContent></Card>
      ) : (
        <Card key={s.id} className="overflow-hidden">
          <div className="bg-primary/5 px-5 py-3 flex flex-wrap items-center justify-between gap-2 border-b">
            <div className="flex items-center gap-3"><Package className="h-5 w-5 text-primary" /><div><div className="text-xs text-muted-foreground">AWB</div><div className="font-mono font-bold">{s.awb_number}</div></div></div>
            <div className="flex flex-wrap gap-2 text-xs">
              <Badge variant="secondary" className="capitalize">{s.status.replace(/_/g, " ")}</Badge>
              <span className="text-muted-foreground">Booked: {format(new Date(s.booking_date), "dd MMM yyyy")}</span>
              <span className="text-muted-foreground">Pcs: {s.pieces}</span>
              <span className="text-muted-foreground">Wt: {s.chargeable_weight} kg</span>
              <span className="text-muted-foreground">Mode: {s.transport_mode}</span>
            </div>
          </div>
          <CardContent className="pt-4 grid gap-4 md:grid-cols-[1fr_auto_1fr]">
            <div className="rounded-md border p-3 text-sm">
              <div className="text-[10px] uppercase text-muted-foreground tracking-wider mb-1">Consigner / From</div>
              <div className="font-semibold flex items-center gap-1"><User className="h-3 w-3" />{s.sender_name}</div>
              <div className="text-muted-foreground">{s.sender_address}</div>
              <div className="text-muted-foreground">{[s.sender_city, s.sender_pincode].filter(Boolean).join(" - ")}</div>
              {s.sender_phone && <div className="flex items-center gap-1 text-xs mt-1"><Phone className="h-3 w-3" />{s.sender_phone}</div>}
            </div>
            <ArrowRight className="hidden md:block self-center text-primary" />
            <div className="rounded-md border p-3 text-sm">
              <div className="text-[10px] uppercase text-muted-foreground tracking-wider mb-1">Consignee / To</div>
              <div className="font-semibold flex items-center gap-1"><User className="h-3 w-3" />{s.receiver_name}</div>
              <div className="text-muted-foreground">{s.receiver_address}</div>
              <div className="text-muted-foreground">{[s.receiver_city, s.receiver_state, s.receiver_pincode].filter(Boolean).join(", ")}</div>
              {s.receiver_phone && <div className="flex items-center gap-1 text-xs mt-1"><Phone className="h-3 w-3" />{s.receiver_phone}</div>}
            </div>
            <div className="md:col-span-3 grid gap-3 md:grid-cols-3">
              <div className="rounded-md border p-3 bg-muted/30 text-xs space-y-1">
                <div className="text-[10px] uppercase text-muted-foreground tracking-wider mb-1 font-semibold">Package</div>
                <div>Pieces: <span className="font-semibold">{s.pieces}</span></div>
                <div>Actual Weight: <span className="font-semibold">{s.actual_weight} kg</span></div>
                <div>Volumetric Wt: <span className="font-semibold">{s.volumetric_weight ?? 0} kg</span></div>
                <div>Chargeable Wt: <span className="font-semibold">{s.chargeable_weight} kg</span></div>
                <div>Dimensions (L×W×H): <span className="font-semibold">{s.length_cm || 0}×{s.width_cm || 0}×{s.height_cm || 0} cm</span></div>
                <div>Contents: <span className="font-semibold">{s.contents || "—"}</span></div>
                <div>Declared Value: <span className="font-semibold">₹{Number(s.declared_value || 0).toFixed(2)}</span></div>
              </div>
              <div className="rounded-md border p-3 bg-muted/30 text-xs space-y-1">
                <div className="text-[10px] uppercase text-muted-foreground tracking-wider mb-1 font-semibold">References</div>
                <div>Service: <span className="font-semibold">{s.service_type || "—"}</span></div>
                <div>Mode: <span className="font-semibold">{s.transport_mode || "—"} ({s.mode})</span></div>
                <div>Reference No: <span className="font-semibold">{s.reference_no || "—"}</span></div>
                <div>Invoice No: <span className="font-semibold">{s.invoice_no || "—"}</span></div>
                <div>E-Way Bill: <span className="font-semibold">{s.eway_bill_no || "—"}</span></div>
                <div>Distance: <span className="font-semibold">{s.distance_km ? `${s.distance_km} km` : "—"}</span></div>
                <div>Payment: <span className="font-semibold uppercase">{s.payment_mode}</span></div>
              </div>
              <div className="rounded-md border p-3 bg-muted/30 text-xs space-y-1">
                <div className="text-[10px] uppercase text-muted-foreground tracking-wider mb-1 font-semibold">Charges</div>
                <div>Freight: <span className="font-semibold">₹{Number(s.freight || 0).toFixed(2)}</span></div>
                <div>Fuel: <span className="font-semibold">₹{Number(s.fuel_charge || 0).toFixed(2)}</span></div>
                <div>Other: <span className="font-semibold">₹{Number(s.other_charges || 0).toFixed(2)}</span></div>
                <div>GST: <span className="font-semibold">₹{Number(s.gst || 0).toFixed(2)}</span></div>
                <div>COD: <span className="font-semibold">₹{Number(s.cod_amount || 0).toFixed(2)}</span></div>
                <div className="border-t pt-1 mt-1">Grand Total: <span className="font-bold text-base">₹{Number(s.total_amount || 0).toFixed(2)}</span></div>
              </div>
            </div>
            <div className="md:col-span-3">
              <div className="text-xs uppercase text-muted-foreground mb-2 flex items-center gap-1"><Activity className="h-3 w-3" />Tracking History</div>
              {(s.events ?? []).length === 0 ? <p className="text-xs text-muted-foreground">No events.</p> : (
                <ol className="space-y-2">
                  {s.events.map((e: any, i: number) => (
                    <li key={i} className="flex items-start gap-2 text-sm border-l-2 border-primary/30 pl-3">
                      {e.status === "delivered" ? <CheckCircle2 className="h-4 w-4 text-success mt-0.5" /> : <span className="h-2 w-2 rounded-full bg-primary mt-2" />}
                      <div className="flex-1">
                        <div className="flex justify-between gap-2"><span className="font-medium capitalize">{e.status.replace(/_/g, " ")}</span><span className="text-xs text-muted-foreground">{format(new Date(e.event_at), "dd MMM, HH:mm")}</span></div>
                        {e.location && <div className="text-xs text-muted-foreground">📍 {e.location}</div>}
                        {e.remarks && <div className="text-xs">{e.remarks}</div>}
                      </div>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}