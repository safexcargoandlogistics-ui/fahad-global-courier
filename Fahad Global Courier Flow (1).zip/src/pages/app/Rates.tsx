import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Pencil, Trash2, Upload, Download } from "lucide-react";
import * as XLSX from "xlsx";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Rates() {
  const [clients, setClients] = useState<any[]>([]);
  const [rows, setRows] = useState<any[]>([]);
  const [f, setF] = useState<{ client_id: string; mode: "domestic" | "international"; zone: string; weight_from: number; weight_to: number; base_rate: number; per_kg_rate: number }>({ client_id: "", mode: "domestic", zone: "", weight_from: 0, weight_to: 0.5, base_rate: 0, per_kg_rate: 0 });
  const [editing, setEditing] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);
  const load = async () => { const { data } = await supabase.from("rate_cards").select("*, clients(name)").order("created_at", { ascending: false }); setRows(data ?? []); };
  useEffect(() => { supabase.from("clients").select("id,name").order("name").then(({ data }) => setClients(data ?? [])); load(); }, []);
  const save = async () => {
    if (!f.client_id || !f.zone) { toast.error("Select client and zone"); return; }
    const { error } = await supabase.from("rate_cards").insert(f);
    if (error) toast.error(error.message); else { toast.success("Rate added"); load(); }
  };
  const remove = async (id: string) => {
    if (!confirm("Delete this rate row?")) return;
    const { error } = await supabase.from("rate_cards").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); load();
  };
  const saveEdit = async () => {
    if (!editing) return;
    const { id, clients: _c, created_at, ...rest } = editing;
    const { error } = await supabase.from("rate_cards").update(rest).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Updated"); setEditing(null); load();
  };

  const downloadTemplate = () => {
    const csv = "client_code,mode,zone,weight_from,weight_to,base_rate,per_kg_rate\nFGLC00001,domestic,A,0,0.5,80,40\nFGLC00001,domestic,A,0.5,1,120,60\n";
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "rate-quotation-template.csv"; a.click();
  };

  const uploadQuotation = async (file: File, defaultClientId?: string) => {
    setBusy(true);
    try {
      // Save file to storage
      const path = `quotations/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error: upErr } = await supabase.storage.from("rate-agreements").upload(path, file, { upsert: true });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("rate-agreements").createSignedUrl ? { data: { signedUrl: "" } } as any : { data: { signedUrl: "" } } as any;

      // Parse rows
      let raw: any[][] = [];
      const isXls = /\.xlsx?$/i.test(file.name);
      if (isXls) {
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: "array" });
        raw = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: "" }) as any[][];
      } else {
        const text = await file.text();
        raw = text.trim().split(/\r?\n/).map((l) => l.split(/[,;\t]/).map((c) => c.trim().replace(/^"|"$/g, "")));
      }
      if (raw.length < 2) throw new Error("Empty file");
      const headers = raw[0].map((h) => String(h).toLowerCase().trim());
      const idx = (k: string, alts: string[] = []) => headers.findIndex((h) => h === k || alts.includes(h));
      const cI = idx("client_code", ["client", "code"]);
      const mI = idx("mode");
      const zI = idx("zone");
      const wfI = idx("weight_from", ["from"]);
      const wtI = idx("weight_to", ["to"]);
      const brI = idx("base_rate", ["base"]);
      const prI = idx("per_kg_rate", ["per_kg", "perkg", "rate"]);

      // Resolve clients by code
      const codes = Array.from(new Set(raw.slice(1).map((r) => cI > -1 ? String(r[cI] ?? "").toUpperCase().trim() : "").filter(Boolean)));
      const codeMap: Record<string, string> = {};
      if (codes.length) {
        const { data: cs } = await supabase.from("clients").select("id,client_code").in("client_code", codes);
        (cs ?? []).forEach((c: any) => { codeMap[c.client_code.toUpperCase()] = c.id; });
      }
      const inserts: any[] = [];
      for (let i = 1; i < raw.length; i++) {
        const r = raw[i] ?? [];
        const code = cI > -1 ? String(r[cI] ?? "").toUpperCase().trim() : "";
        const client_id = codeMap[code] || defaultClientId;
        if (!client_id) continue;
        const zone = String(r[zI] ?? "").trim() || "A";
        const weight_from = Number(r[wfI]) || 0;
        const weight_to = Number(r[wtI]) || 0.5;
        if (!weight_to) continue;
        inserts.push({
          client_id,
          mode: (String(r[mI] ?? "domestic").toLowerCase() === "international" ? "international" : "domestic"),
          zone,
          weight_from,
          weight_to,
          base_rate: Number(r[brI]) || 0,
          per_kg_rate: Number(r[prI]) || 0,
          agreement_url: path,
        });
      }
      if (!inserts.length) throw new Error("No valid rate rows found (check client_code column)");
      const { error } = await supabase.from("rate_cards").insert(inserts);
      if (error) throw error;
      toast.success(`Imported ${inserts.length} rates from quotation`);
      load();
    } catch (e: any) { toast.error("Upload failed: " + e.message); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Rate Cards</h1>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={downloadTemplate}><Download className="h-3 w-3 mr-1" />Template</Button>
          <label className={`inline-flex items-center gap-1 cursor-pointer rounded-md border px-3 py-1.5 text-sm ${busy ? "opacity-50" : ""}`}>
            <Upload className="h-3 w-3" /> {busy ? "Uploading…" : "Upload Quotation (auto-rates)"}
            <input type="file" accept=".csv,.xlsx,.xls" className="hidden" disabled={busy} onChange={(e) => { const file = e.target.files?.[0]; if (file) uploadQuotation(file, f.client_id || undefined); e.target.value = ""; }} />
          </label>
        </div>
      </div>
      <Card><CardHeader><CardTitle>Add Rate (manual)</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-7">
          <div className="md:col-span-2"><Label>Client</Label>
            <Select value={f.client_id} onValueChange={(v) => setF({ ...f, client_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>{clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Mode</Label>
            <Select value={f.mode} onValueChange={(v) => setF({ ...f, mode: v as "domestic" | "international" })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="domestic">Domestic</SelectItem><SelectItem value="international">International</SelectItem></SelectContent>
            </Select>
          </div>
          <div><Label>Zone</Label><Input value={f.zone} onChange={(e) => setF({ ...f, zone: e.target.value })} /></div>
          <div><Label>From kg</Label><Input type="number" step="0.001" value={f.weight_from} onChange={(e) => setF({ ...f, weight_from: +e.target.value })} /></div>
          <div><Label>To kg</Label><Input type="number" step="0.001" value={f.weight_to} onChange={(e) => setF({ ...f, weight_to: +e.target.value })} /></div>
          <div><Label>Base ₹</Label><Input type="number" step="0.01" value={f.base_rate} onChange={(e) => setF({ ...f, base_rate: +e.target.value })} /></div>
          <div className="md:col-span-7 flex items-end gap-3">
            <div className="flex-1"><Label>Per kg ₹</Label><Input type="number" step="0.01" value={f.per_kg_rate} onChange={(e) => setF({ ...f, per_kg_rate: +e.target.value })} /></div>
            <Button onClick={save}>Add</Button>
          </div>
        </CardContent></Card>
      <Card><CardContent className="p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left"><tr><th className="p-3">Client</th><th>Mode</th><th>Zone</th><th>Weight</th><th>Base</th><th>Per kg</th><th className="p-3">Actions</th></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.id} className="border-t"><td className="p-3">{r.clients?.name}</td><td className="capitalize">{r.mode}</td><td>{r.zone}</td><td>{r.weight_from}–{r.weight_to} kg</td><td>₹{r.base_rate}</td><td>₹{r.per_kg_rate}</td><td className="p-3 space-x-1"><Button size="sm" variant="outline" onClick={() => setEditing({ ...r })}><Pencil className="h-3 w-3" /></Button><Button size="sm" variant="destructive" onClick={() => remove(r.id)}><Trash2 className="h-3 w-3" /></Button></td></tr>
          ))}{rows.length === 0 && <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">No rates</td></tr>}</tbody>
        </table>
      </CardContent></Card>
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Rate</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3 md:grid-cols-2">
              <div><Label>Zone</Label><Input value={editing.zone ?? ""} onChange={(e) => setEditing({ ...editing, zone: e.target.value })} /></div>
              <div><Label>Mode</Label>
                <Select value={editing.mode} onValueChange={(v) => setEditing({ ...editing, mode: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="domestic">Domestic</SelectItem><SelectItem value="international">International</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>From kg</Label><Input type="number" step="0.001" value={editing.weight_from ?? 0} onChange={(e) => setEditing({ ...editing, weight_from: +e.target.value })} /></div>
              <div><Label>To kg</Label><Input type="number" step="0.001" value={editing.weight_to ?? 0} onChange={(e) => setEditing({ ...editing, weight_to: +e.target.value })} /></div>
              <div><Label>Base ₹</Label><Input type="number" step="0.01" value={editing.base_rate ?? 0} onChange={(e) => setEditing({ ...editing, base_rate: +e.target.value })} /></div>
              <div><Label>Per kg ₹</Label><Input type="number" step="0.01" value={editing.per_kg_rate ?? 0} onChange={(e) => setEditing({ ...editing, per_kg_rate: +e.target.value })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={saveEdit}>Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
