import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth";
import { Pencil, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { format } from "date-fns";

type ShipmentStatus = "booked" | "cancelled" | "delivered" | "in_transit" | "manifested" | "out_for_delivery" | "rto" | "undelivered";

const cleanName = (n: string) => n.replace(/[^a-zA-Z0-9._-]/g, "_");
const nowLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
const UNDELIVERED_REASONS = [
  "Consignee Not Available", "Premises Closed", "Address Incomplete", "Refused by Consignee",
  "Wrong Address", "Holiday", "Out of Station", "Customer Request - Delay Delivery",
  "Door Locked", "No Such Person", "COD Not Ready", "Other"
];

export default function Delivery() {
  const { isAdmin } = useAuth();
  const [awb, setAwb] = useState("");
  const [shipment, setShipment] = useState<any>(null);
  const [status, setStatus] = useState<ShipmentStatus>("delivered");
  const [receiver, setReceiver] = useState("");
  const [location, setLocation] = useState("");
  const [remarks, setRemarks] = useState("");
  const [podFile, setPodFile] = useState<File | null>(null);
  const [eventAt, setEventAt] = useState<string>(nowLocal());
  const [undeliveredReason, setUndeliveredReason] = useState<string>("");
  const [recent, setRecent] = useState<any[]>([]);
  const [editing, setEditing] = useState<any | null>(null);

  const loadRecent = async () => {
    const { data } = await supabase.from("tracking_events")
      .select("id,event_at,status,location,remarks,receiver_name,shipment_id,shipments(awb_number)")
      .order("event_at", { ascending: false }).limit(30);
    setRecent(data ?? []);
  };
  useEffect(() => { loadRecent(); }, []);

  const search = async () => {
    const { data } = await supabase.from("shipments").select("*").eq("awb_number", awb.toUpperCase()).maybeSingle();
    if (!data) toast.error("AWB not found"); else { setShipment(data); setReceiver(data.receiver_name); }
  };

  const update = async () => {
    if (!shipment) return;
    const { data: { user } } = await supabase.auth.getUser();
    let pod_url: string | undefined;
    if (podFile) {
      const safe = cleanName(podFile.name);
      const path = `${shipment.awb_number}/${Date.now()}-${safe}`;
      const { error: upErr } = await supabase.storage.from("pods").upload(path, podFile, { upsert: true, contentType: podFile.type || "image/jpeg" });
      if (upErr) { toast.error("POD upload failed: " + upErr.message); return; }
      pod_url = supabase.storage.from("pods").getPublicUrl(path).data.publicUrl;
    }
    const eventTs = new Date(eventAt).toISOString();
    const upd: any = { status };
    if (status === "delivered") { upd.delivered_at = eventTs; upd.pod_received_by = receiver; if (pod_url) { upd.pod_url = pod_url; upd.pod_at = eventTs; } }
    if (status === "undelivered" || status === "rto") {
      upd.undelivered_reason = undeliveredReason || null;
      if (pod_url) { upd.pod_url = pod_url; upd.pod_at = eventTs; }
    }
    const { error: e1 } = await supabase.from("shipments").update(upd).eq("id", shipment.id);
    if (e1) { toast.error(e1.message); return; }
    const trackPayload: any = { shipment_id: shipment.id, status, location, remarks, receiver_name: status === "delivered" ? receiver : null, created_by: user?.id, event_at: eventTs };
    if (status === "undelivered" || status === "rto") trackPayload.undelivered_reason = undeliveredReason || null;
    await (supabase as any).from("tracking_events").insert(trackPayload);
    toast.success("Status updated — public tracking will reflect shortly");
    setShipment(null); setAwb(""); setRemarks(""); setLocation(""); setPodFile(null); setUndeliveredReason("");
    loadRecent();
  };

  const removeEvent = async (ev: any) => {
    if (!confirm(`Delete event "${ev.status}" on ${format(new Date(ev.event_at), "dd MMM HH:mm")}?`)) return;
    const { error } = await supabase.from("tracking_events").delete().eq("id", ev.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); loadRecent();
  };
  const saveEdit = async () => {
    if (!editing) return;
    const { error } = await supabase.from("tracking_events").update({
      status: editing.status, location: editing.location, remarks: editing.remarks,
      receiver_name: editing.receiver_name, event_at: new Date(editing.event_at).toISOString(),
    }).eq("id", editing.id);
    if (error) return toast.error(error.message);
    // also propagate delivered timestamp to shipment if delivered event was edited
    if (editing.status === "delivered") {
      await supabase.from("shipments").update({ delivered_at: new Date(editing.event_at).toISOString(), pod_received_by: editing.receiver_name }).eq("id", editing.shipment_id);
    }
    toast.success("Event updated"); setEditing(null); loadRecent();
  };

  return (
    <div className="space-y-4 max-w-5xl">
      <h1 className="text-2xl font-bold">Delivery Updation</h1>
      <Card><CardContent className="pt-6 flex gap-2">
        <Input placeholder="Enter AWB number" value={awb} onChange={(e) => setAwb(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === "Enter" && search()} />
        <Button onClick={search}>Find</Button>
      </CardContent></Card>
      {shipment && (
        <Card><CardHeader><CardTitle>{shipment.awb_number}</CardTitle></CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2">
            <div className="md:col-span-2 text-sm text-muted-foreground">{shipment.receiver_name} — {shipment.receiver_city}, {shipment.receiver_pincode}</div>
            <div><Label>Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as ShipmentStatus)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="in_transit">In Transit</SelectItem>
                  <SelectItem value="out_for_delivery">Out for Delivery</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="undelivered">Undelivered</SelectItem>
                  <SelectItem value="rto">RTO</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Location</Label><Input value={location} onChange={(e) => setLocation(e.target.value)} /></div>
            <div><Label>Event Date & Time (back-date allowed)</Label><Input type="datetime-local" value={eventAt} onChange={(e) => setEventAt(e.target.value)} /></div>
            {status === "delivered" && <>
              <div><Label>Received By</Label><Input value={receiver} onChange={(e) => setReceiver(e.target.value)} /></div>
              <div><Label>POD Photo / Signature</Label><Input type="file" accept="image/*,application/pdf" onChange={(e) => setPodFile(e.target.files?.[0] ?? null)} /></div>
            </>}
            {(status === "undelivered" || status === "rto") && <>
              <div className="md:col-span-2"><Label>Undelivered Reason *</Label>
                <Select value={undeliveredReason} onValueChange={setUndeliveredReason}>
                  <SelectTrigger><SelectValue placeholder="Select a reason" /></SelectTrigger>
                  <SelectContent>{UNDELIVERED_REASONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2"><Label>Photo / Proof (optional)</Label><Input type="file" accept="image/*,application/pdf" onChange={(e) => setPodFile(e.target.files?.[0] ?? null)} /></div>
            </>}
            <div className="md:col-span-2"><Label>Remarks</Label><Textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} /></div>
            <div className="md:col-span-2 flex justify-end"><Button onClick={update}>Update Status</Button></div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle>Recent Delivery / Status Events</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3">When</th><th>AWB</th><th>Status</th><th>Location</th><th>Remarks</th>{isAdmin && <th>Actions</th>}</tr></thead>
            <tbody>{recent.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="p-3 whitespace-nowrap">{format(new Date(r.event_at), "dd MMM HH:mm")}</td>
                <td className="font-mono">{r.shipments?.awb_number}</td>
                <td className="capitalize">{r.status?.replace(/_/g, " ")}</td>
                <td>{r.location}</td>
                <td className="max-w-[200px] truncate">{r.remarks}</td>
                {isAdmin && <td className="space-x-1 whitespace-nowrap">
                  <Button size="sm" variant="outline" onClick={() => setEditing({ ...r, event_at: r.event_at?.slice(0, 16) })}><Pencil className="h-3 w-3" /></Button>
                  <Button size="sm" variant="destructive" onClick={() => removeEvent(r)}><Trash2 className="h-3 w-3" /></Button>
                </td>}
              </tr>
            ))}{!recent.length && <tr><td colSpan={isAdmin ? 6 : 5} className="p-6 text-center text-muted-foreground">No events</td></tr>}</tbody>
          </table>
        </CardContent>
      </Card>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Delivery Event</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3 md:grid-cols-2">
              <div><Label>Date & Time</Label><Input type="datetime-local" value={editing.event_at ?? ""} onChange={(e) => setEditing({ ...editing, event_at: e.target.value })} /></div>
              <div><Label>Status</Label>
                <Select value={editing.status} onValueChange={(v) => setEditing({ ...editing, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["booked","manifested","in_transit","received_at_branch","out_for_delivery","delivered","undelivered","rto","cancelled"].map((s) => <SelectItem key={s} value={s}>{s.replace(/_/g," ")}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2"><Label>Location</Label><Input value={editing.location ?? ""} onChange={(e) => setEditing({ ...editing, location: e.target.value })} /></div>
              <div className="md:col-span-2"><Label>Remarks</Label><Input value={editing.remarks ?? ""} onChange={(e) => setEditing({ ...editing, remarks: e.target.value })} /></div>
              <div className="md:col-span-2"><Label>Received By</Label><Input value={editing.receiver_name ?? ""} onChange={(e) => setEditing({ ...editing, receiver_name: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={saveEdit}>Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
