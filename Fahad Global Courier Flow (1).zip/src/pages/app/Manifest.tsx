import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Printer } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader } from "@/components/PageHeader";
import { printManifest } from "@/lib/printDocs";
import { useAuth } from "@/lib/auth";
import { Pencil, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const nowLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };

export default function Manifest() {
  const { type } = useParams<{ type: "outgoing" | "incoming" }>();
  const t = (type ?? "outgoing") as "outgoing" | "incoming";
  const { isAdmin } = useAuth();
  const [editing, setEditing] = useState<any | null>(null);
  const [list, setList] = useState<any[]>([]);
  const [shipments, setShipments] = useState<any[]>([]);
  const [picked, setPicked] = useState<Record<string, boolean>>({});
  const [branches, setBranches] = useState<any[]>([]);
  const [form, setForm] = useState<any>({ manifest_no: "", origin: "", destination: "", vehicle_no: "", driver_name: "", driver_phone: "", remarks: "", origin_branch_id: "", destination_branch_id: "" });
  const [manifestAt, setManifestAt] = useState<string>(nowLocal());
  const [awbInput, setAwbInput] = useState("");

  const load = async () => {
    const { data } = await supabase.from("manifests").select("*").eq("manifest_type", t).order("created_at", { ascending: false }).limit(50);
    setList(data ?? []);
    // For OUTGOING: only shipments physically present here (booked or received_at_branch).
    // For INCOMING: this page is just to view incoming manifests (real receive happens in Receive Manifest page).
    let q = supabase.from("shipments").select("id,awb_number,receiver_city,chargeable_weight,pieces,status").order("created_at", { ascending: false }).limit(200);
    if (t === "outgoing") q = q.in("status", ["booked", "received_at_branch"]);
    else q = q.in("status", ["manifested", "in_transit"]);
    const { data: s } = await q;
    setShipments(s ?? []);
    const { data: b } = await (supabase as any).from("branches").select("id,branch_code,name,city").eq("active", true).order("name");
    setBranches(b ?? []);
  };
  useEffect(() => { load(); setForm((f) => ({ ...f, manifest_no: `MF-${t.toUpperCase().slice(0,3)}-${Date.now().toString().slice(-6)}` })); setManifestAt(nowLocal()); }, [t]);

  const addByAwb = async () => {
    const code = awbInput.trim().toUpperCase(); if (!code) return;
    const found = shipments.find((s) => s.awb_number === code);
    if (found) { setPicked((p) => ({ ...p, [found.id]: true })); setAwbInput(""); toast.success(`Added ${code}`); return; }
    const { data } = await supabase.from("shipments").select("id,awb_number,receiver_city,chargeable_weight,pieces,status").eq("awb_number", code).maybeSingle();
    if (!data) { toast.error("AWB not found"); return; }
    setShipments((p) => [data, ...p]);
    setPicked((p) => ({ ...p, [data.id]: true }));
    setAwbInput("");
    toast.success(`Added ${code}`);
  };

  const save = async () => {
    const ids = Object.keys(picked).filter((k) => picked[k]);
    if (!ids.length) { toast.error("Select at least one shipment"); return; }
    const { data: { user } } = await supabase.auth.getUser();
    const totalPieces = shipments.filter((s) => ids.includes(s.id)).reduce((a, b) => a + b.pieces, 0);
    const totalWeight = shipments.filter((s) => ids.includes(s.id)).reduce((a, b) => a + Number(b.chargeable_weight), 0);
    const ts = new Date(manifestAt);
    // Resolve branch city for human-friendly tracking remark
    const destBranch = branches.find((b) => b.id === form.destination_branch_id);
    const destCity = destBranch?.city || destBranch?.name || form.destination || "next branch";
    const payload: any = { ...form, manifest_type: t, manifest_date: ts.toISOString().slice(0,10), total_pieces: totalPieces, total_weight: totalWeight, created_by: user?.id };
    if (!payload.origin_branch_id) delete payload.origin_branch_id;
    if (!payload.destination_branch_id) delete payload.destination_branch_id;
    const { data: m, error } = await supabase.from("manifests").insert(payload).select().single();
    if (error) { toast.error(error.message); return; }
    await supabase.from("manifest_shipments").insert(ids.map((id) => ({ manifest_id: m.id, shipment_id: id })));
    const newStatus = t === "outgoing" ? "manifested" : "in_transit";
    await supabase.from("shipments").update({ status: newStatus }).in("id", ids);
    await supabase.from("tracking_events").insert(ids.map((id) => ({
      shipment_id: id, status: newStatus, location: form.origin || "",
      remarks: `Forwarded to ${destCity} Branch`,
      created_by: user?.id, event_at: ts.toISOString(),
    })));
    toast.success("Manifest created");
    setPicked({}); load();
  };

  const reprint = async (m: any) => {
    const { data: links } = await supabase.from("manifest_shipments").select("shipment_id").eq("manifest_id", m.id);
    const ids = (links ?? []).map((l: any) => l.shipment_id);
    const { data: items } = await supabase.from("shipments").select("awb_number,receiver_name,receiver_city,receiver_pincode,pieces,chargeable_weight").in("id", ids);
    printManifest(m, items ?? []);
  };
  const removeManifest = async (m: any) => {
    if (!confirm(`Delete manifest ${m.manifest_no}?`)) return;
    await supabase.from("manifest_shipments").delete().eq("manifest_id", m.id);
    const { error } = await supabase.from("manifests").delete().eq("id", m.id);
    if (error) return toast.error(error.message);
    toast.success("Manifest deleted"); load();
  };
  const saveEdit = async () => {
    if (!editing) return;
    const { id, ...rest } = editing;
    const { error } = await supabase.from("manifests").update(rest).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Updated"); setEditing(null); load();
  };

  return (
    <div className="space-y-4">
      <PageHeader title={`${t === "outgoing" ? "Outgoing" : "Incoming"} Manifest`} subtitle="Branch-wise manifest creation with vehicle and driver details" />
      <Card><CardHeader><CardTitle>Create Manifest</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-4">
          <div><Label>Manifest No</Label><Input value={form.manifest_no} onChange={(e) => setForm({ ...form, manifest_no: e.target.value })} /></div>
          <div><Label>Manifest Date & Time</Label><Input type="datetime-local" value={manifestAt} onChange={(e) => setManifestAt(e.target.value)} /></div>
          <div><Label>Origin Branch</Label>
            <Select value={form.origin_branch_id} onValueChange={(v) => setForm({ ...form, origin_branch_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>{branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.branch_code} — {b.city}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Destination Branch</Label>
            <Select value={form.destination_branch_id} onValueChange={(v) => setForm({ ...form, destination_branch_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>{branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.branch_code} — {b.city}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Origin</Label><Input value={form.origin} onChange={(e) => setForm({ ...form, origin: e.target.value })} /></div>
          <div><Label>Destination</Label><Input value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} /></div>
          <div><Label>Vehicle No</Label><Input value={form.vehicle_no} onChange={(e) => setForm({ ...form, vehicle_no: e.target.value })} /></div>
          <div><Label>Driver</Label><Input value={form.driver_name} onChange={(e) => setForm({ ...form, driver_name: e.target.value })} /></div>
          <div><Label>Driver Phone</Label><Input value={form.driver_phone} onChange={(e) => setForm({ ...form, driver_phone: e.target.value })} /></div>
          <div className="md:col-span-2"><Label>Remarks</Label><Input value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} /></div>
        </CardContent>
      </Card>
      <Card><CardHeader><CardTitle>Available Shipments ({shipments.length})</CardTitle></CardHeader>
        <CardContent className="border-b py-3 flex gap-2">
          <Input placeholder="Add by AWB (for multi-leg / re-manifest)" value={awbInput} onChange={(e) => setAwbInput(e.target.value.toUpperCase())} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addByAwb(); } }} />
          <Button type="button" variant="outline" onClick={addByAwb}>Add AWB</Button>
        </CardContent>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3 w-10"></th><th>AWB</th><th>City</th><th>Pcs</th><th>Wt</th><th>Status</th></tr></thead>
            <tbody>{shipments.map((s) => (
              <tr key={s.id} className="border-t">
                <td className="p-3"><Checkbox checked={!!picked[s.id]} onCheckedChange={(v) => setPicked({ ...picked, [s.id]: !!v })} /></td>
                <td className="font-mono">{s.awb_number}</td><td>{s.receiver_city}</td><td>{s.pieces}</td><td>{s.chargeable_weight}</td><td className="capitalize">{s.status?.replace(/_/g, " ")}</td>
              </tr>
            ))}</tbody>
          </table>
        </CardContent>
        <div className="p-3 border-t flex justify-end"><Button onClick={save}>Create Manifest</Button></div>
      </Card>
      <Card><CardHeader><CardTitle>Recent Manifests</CardTitle></CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-3">No</th><th>Date</th><th>Route</th><th>Vehicle</th><th>Pcs</th><th>Wt</th><th className="p-3">Actions</th></tr></thead>
            <tbody>{list.map((m) => (
              <tr key={m.id} className="border-t">
                <td className="p-3 font-mono">{m.manifest_no}</td><td>{m.manifest_date}</td>
                <td>{m.origin} → {m.destination}</td><td>{m.vehicle_no}</td><td>{m.total_pieces}</td><td>{m.total_weight}</td>
                <td className="p-3 space-x-1 whitespace-nowrap">
                  <Button size="sm" variant="outline" onClick={() => reprint(m)}><Printer className="h-3 w-3 mr-1" />Print</Button>
                  {isAdmin && <>
                    <Button size="sm" variant="outline" onClick={() => setEditing(m)}><Pencil className="h-3 w-3" /></Button>
                    <Button size="sm" variant="destructive" onClick={() => removeManifest(m)}><Trash2 className="h-3 w-3" /></Button>
                  </>}
                </td>
              </tr>
            ))}</tbody>
          </table>
        </CardContent>
      </Card>
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Manifest</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3 md:grid-cols-2">
              <div><Label>Manifest No</Label><Input value={editing.manifest_no} onChange={(e) => setEditing({ ...editing, manifest_no: e.target.value })} /></div>
              <div><Label>Date</Label><Input type="date" value={editing.manifest_date ?? ""} onChange={(e) => setEditing({ ...editing, manifest_date: e.target.value })} /></div>
              <div><Label>Origin</Label><Input value={editing.origin ?? ""} onChange={(e) => setEditing({ ...editing, origin: e.target.value })} /></div>
              <div><Label>Destination</Label><Input value={editing.destination ?? ""} onChange={(e) => setEditing({ ...editing, destination: e.target.value })} /></div>
              <div><Label>Vehicle No</Label><Input value={editing.vehicle_no ?? ""} onChange={(e) => setEditing({ ...editing, vehicle_no: e.target.value })} /></div>
              <div><Label>Driver</Label><Input value={editing.driver_name ?? ""} onChange={(e) => setEditing({ ...editing, driver_name: e.target.value })} /></div>
              <div className="md:col-span-2"><Label>Remarks</Label><Input value={editing.remarks ?? ""} onChange={(e) => setEditing({ ...editing, remarks: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={saveEdit}>Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
