import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Printer, Pencil, Trash2 } from "lucide-react";
import { printLedger } from "@/lib/printDocs";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Ledger() {
  const [clients, setClients] = useState<any[]>([]);
  const [clientId, setClientId] = useState("");
  const [entries, setEntries] = useState<any[]>([]);
  const [opening, setOpening] = useState<number>(0);
  const [f, setF] = useState({ entry_date: new Date().toISOString().slice(0,10), description: "", reference: "", debit: 0, credit: 0 });
  const [editing, setEditing] = useState<any | null>(null);

  const reload = async () => {
    if (!clientId) return;
    const { data } = await supabase.from("ledger_entries").select("*").eq("client_id", clientId).order("entry_date").order("created_at");
    setEntries(data ?? []);
    const c = clients.find((x) => x.id === clientId);
    setOpening(Number(c?.opening_balance || 0));
  };
  useEffect(() => { supabase.from("clients").select("id,name,client_code,opening_balance").order("name").then(({ data }) => setClients(data ?? [])); }, []);
  useEffect(() => { reload(); }, [clientId]);

  const add = async () => {
    if (!clientId || !f.description) return;
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from("ledger_entries").insert({ client_id: clientId, ...f, created_by: user?.id });
    if (error) toast.error(error.message); else {
      toast.success("Entry added");
      setF({ entry_date: new Date().toISOString().slice(0,10), description: "", reference: "", debit: 0, credit: 0 });
      reload();
    }
  };
  const remove = async (id: string) => {
    if (!confirm("Delete this ledger entry?")) return;
    const { error } = await supabase.from("ledger_entries").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); reload();
  };
  const saveEdit = async () => {
    if (!editing) return;
    const { id, created_by, created_at, ...rest } = editing;
    const { error } = await supabase.from("ledger_entries").update(rest).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Updated"); setEditing(null); reload();
  };

  let bal = opening;
  const totals = entries.reduce((a, e) => ({ d: a.d + Number(e.debit || 0), c: a.c + Number(e.credit || 0) }), { d: 0, c: 0 });
  const closing = opening + totals.d - totals.c;
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Client Ledger <span className="text-xs font-normal text-muted-foreground">(Tally style)</span></h1>
        {clientId && <Button variant="outline" onClick={() => printLedger(clients.find(c=>c.id===clientId), entries)}><Printer className="h-4 w-4 mr-1" />Print Ledger</Button>}
      </div>
      <Card><CardContent className="pt-6 flex gap-2 items-end">
        <div className="flex-1"><Label>Client</Label>
          <Select value={clientId} onValueChange={setClientId}>
            <SelectTrigger><SelectValue placeholder="Select client" /></SelectTrigger>
            <SelectContent>{clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.client_code} — {c.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </CardContent></Card>
      {clientId && (
        <>
          <Card><CardHeader><CardTitle>Add Entry</CardTitle></CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-6">
              <div><Label>Date</Label><Input type="date" value={f.entry_date} onChange={(e) => setF({ ...f, entry_date: e.target.value })} /></div>
              <div className="md:col-span-2"><Label>Description</Label><Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
              <div><Label>Reference</Label><Input value={f.reference} onChange={(e) => setF({ ...f, reference: e.target.value })} /></div>
              <div><Label>Debit</Label><Input type="number" step="0.01" value={f.debit} onChange={(e) => setF({ ...f, debit: +e.target.value })} /></div>
              <div><Label>Credit</Label><Input type="number" step="0.01" value={f.credit} onChange={(e) => setF({ ...f, credit: +e.target.value })} /></div>
              <div className="md:col-span-6 flex justify-end"><Button onClick={add}>Add Entry</Button></div>
            </CardContent>
          </Card>
          <Card><CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left">
                <tr><th className="p-3">Date</th><th>Particulars</th><th>Voucher Type</th><th>Vch No.</th><th className="text-right">Debit</th><th className="text-right">Credit</th><th className="text-right p-3">Balance</th><th className="p-3">Actions</th></tr>
              </thead>
              <tbody>
                <tr className="border-t bg-muted/20 italic"><td className="p-3">—</td><td colSpan={3}>Opening Balance</td><td className="text-right">{opening >= 0 ? `₹${opening.toFixed(2)}` : "—"}</td><td className="text-right">{opening < 0 ? `₹${(-opening).toFixed(2)}` : "—"}</td><td className="text-right p-3 font-medium">₹{opening.toFixed(2)}</td><td></td></tr>
                {entries.map((e) => { bal += Number(e.debit) - Number(e.credit); const vt = (e.reference || "").toLowerCase().includes("inv") ? "Sales" : (e.reference || "").toLowerCase().includes("rcpt") || Number(e.credit) ? "Receipt" : "Journal"; return (
                <tr key={e.id} className="border-t hover:bg-muted/30"><td className="p-3">{e.entry_date}</td><td>{e.description}</td><td className="text-muted-foreground">{vt}</td><td className="font-mono">{e.reference}</td><td className="text-right">{Number(e.debit) ? `₹${Number(e.debit).toFixed(2)}` : "—"}</td><td className="text-right">{Number(e.credit) ? `₹${Number(e.credit).toFixed(2)}` : "—"}</td><td className="text-right p-3 font-medium">₹{bal.toFixed(2)}</td><td className="p-3 whitespace-nowrap space-x-1"><Button size="sm" variant="outline" onClick={() => setEditing({ ...e })}><Pencil className="h-3 w-3" /></Button><Button size="sm" variant="destructive" onClick={() => remove(e.id)}><Trash2 className="h-3 w-3" /></Button></td></tr>
              );})}
                {entries.length === 0 && <tr><td colSpan={8} className="p-6 text-center text-muted-foreground">No entries</td></tr>}
                <tr className="border-t bg-primary/5 font-semibold"><td className="p-3" colSpan={4}>Closing Balance</td><td className="text-right">₹{totals.d.toFixed(2)}</td><td className="text-right">₹{totals.c.toFixed(2)}</td><td className="text-right p-3 text-primary">₹{closing.toFixed(2)}</td><td></td></tr>
              </tbody>
            </table>
          </CardContent></Card>
          <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
            <DialogContent>
              <DialogHeader><DialogTitle>Edit Ledger Entry</DialogTitle></DialogHeader>
              {editing && (
                <div className="grid gap-3 md:grid-cols-2">
                  <div><Label>Date</Label><Input type="date" value={editing.entry_date ?? ""} onChange={(e) => setEditing({ ...editing, entry_date: e.target.value })} /></div>
                  <div><Label>Reference</Label><Input value={editing.reference ?? ""} onChange={(e) => setEditing({ ...editing, reference: e.target.value })} /></div>
                  <div className="md:col-span-2"><Label>Description</Label><Input value={editing.description ?? ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></div>
                  <div><Label>Debit</Label><Input type="number" step="0.01" value={editing.debit ?? 0} onChange={(e) => setEditing({ ...editing, debit: +e.target.value })} /></div>
                  <div><Label>Credit</Label><Input type="number" step="0.01" value={editing.credit ?? 0} onChange={(e) => setEditing({ ...editing, credit: +e.target.value })} /></div>
                </div>
              )}
              <DialogFooter><Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={saveEdit}>Save</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      )}
    </div>
  );
}
