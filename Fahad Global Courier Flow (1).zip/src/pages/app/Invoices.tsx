import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { FileSpreadsheet, Printer, Plus, Trash2, FileEdit } from "lucide-react";
import { exportInvoiceExcel, printInvoice, printInvoiceDetailed, printInvoiceSummary } from "@/lib/printDocs";
import { PageHeader } from "@/components/PageHeader";
import { useSiteContent, SITE_DEFAULTS } from "@/hooks/useSiteContent";

type ManualLine = { description: string; awb_number: string; bkg_date: string; origin: string; destination: string; weight: number; service: string; pkg_type: string; freight: number; other: number };
const blankLine = (): ManualLine => ({ description: "", awb_number: "", bkg_date: new Date().toISOString().slice(0,10), origin: "", destination: "", weight: 0, service: "Courier", pkg_type: "Non Docs", freight: 0, other: 0 });

export default function Invoices() {
  const [list, setList] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [manualOpen, setManualOpen] = useState(false);
  const { value: invSettings } = useSiteContent<any>("invoice_settings", SITE_DEFAULTS.invoice_settings as any);
  const [format, setFormat] = useState<"detailed" | "summary">("detailed");
  const [f, setF] = useState({ client_id: "", period_from: "", period_to: "", invoice_no: "" });
  const [m, setM] = useState({ client_id: "", invoice_no: "", invoice_date: new Date().toISOString().slice(0,10), period_from: "", period_to: "", fuel_pct: 0, cn_charge: 0, gst_pct: 18, round_off: 0, lines: [blankLine()] });
  const load = async () => {
    const { data } = await supabase.from("invoices").select("*, clients(name,client_code)").order("created_at", { ascending: false });
    setList(data ?? []);
    const { data: c } = await supabase.from("clients").select("id,name,client_code").eq("active", true);
    setClients(c ?? []);
  };
  useEffect(() => { load(); }, []);

  const generate = async () => {
    if (!f.client_id || !f.period_from || !f.period_to) { toast.error("Fill all fields"); return; }
    const { data: shipments } = await supabase.from("shipments").select("id,awb_number,total_amount,gst,booking_date,sender_city,receiver_city,chargeable_weight,transport_mode,service_type,contents,other_charges").eq("client_id", f.client_id).gte("booking_date", f.period_from).lte("booking_date", f.period_to);
    if (!shipments?.length) { toast.error("No shipments in this period"); return; }
    const subtotal = shipments.reduce((a, b) => a + Number(b.total_amount) - Number(b.gst), 0);
    const gst = shipments.reduce((a, b) => a + Number(b.gst), 0);
    const total = subtotal + gst;
    const invoice_no = f.invoice_no || `INV-${Date.now().toString().slice(-7)}`;
    const { data: { user } } = await supabase.auth.getUser();
    const { data: inv, error } = await supabase.from("invoices").insert({ invoice_no, client_id: f.client_id, period_from: f.period_from, period_to: f.period_to, subtotal, gst, total, created_by: user?.id }).select().single();
    if (error) { toast.error(error.message); return; }
    await supabase.from("invoice_items").insert(shipments.map((s) => ({ invoice_id: inv.id, shipment_id: s.id, description: `Shipment ${s.awb_number}`, amount: s.total_amount })));
    await supabase.from("ledger_entries").insert({ client_id: f.client_id, description: `Invoice ${invoice_no}`, reference: invoice_no, debit: total, created_by: user?.id });
    toast.success("Invoice generated");
    try {
      const { data: client } = await supabase.from("clients").select("*").eq("id", f.client_id).maybeSingle();
      const { data: items } = await supabase.from("invoice_items").select("*, shipments(awb_number,booking_date,sender_city,receiver_city,chargeable_weight,transport_mode,service_type,contents,total_amount,gst,other_charges)").eq("invoice_id", inv.id);
      printInvoice(inv, client, items ?? []);
    } catch {}
    setOpen(false); setF({ client_id: "", period_from: "", period_to: "", invoice_no: "" }); load();
  };

  const reprint = async (i: any) => {
    const { data: client } = await supabase.from("clients").select("*").eq("id", i.client_id).maybeSingle();
    const { data: items } = await supabase.from("invoice_items").select("*, shipments(awb_number,booking_date,sender_city,receiver_city,chargeable_weight,transport_mode,service_type,contents,total_amount,gst,other_charges)").eq("invoice_id", i.id);
    if (format === "summary") printInvoiceSummary(i, client, items ?? [], invSettings);
    else printInvoiceDetailed(i, client, items ?? [], invSettings);
  };
  const excel = async (i: any) => {
    const { data: client } = await supabase.from("clients").select("*").eq("id", i.client_id).maybeSingle();
    const { data: items } = await supabase.from("invoice_items").select("*, shipments(awb_number,booking_date,sender_city,receiver_city,chargeable_weight,transport_mode,service_type,contents,total_amount,gst,other_charges)").eq("invoice_id", i.id);
    exportInvoiceExcel(i, client, items ?? []);
  };

  // Manual invoice math
  const lineAmount = (l: ManualLine) => Number(l.freight || 0) + Number(l.other || 0);
  const subtotal = m.lines.reduce((a, l) => a + lineAmount(l), 0);
  const fuel = +(subtotal * (Number(m.fuel_pct) || 0) / 100).toFixed(2);
  const taxable = subtotal + fuel + Number(m.cn_charge || 0);
  const gstAmt = +(taxable * (Number(m.gst_pct) || 0) / 100).toFixed(2);
  const grandRaw = taxable + gstAmt;
  const rounded = Math.round(grandRaw + Number(m.round_off || 0));
  const autoRound = +(rounded - grandRaw).toFixed(2);

  const setLine = (i: number, k: keyof ManualLine, v: any) => setM((p) => ({ ...p, lines: p.lines.map((ln, idx) => idx === i ? { ...ln, [k]: v } : ln) }));

  const saveManual = async () => {
    if (!m.client_id) { toast.error("Select client"); return; }
    if (!m.lines.length) { toast.error("Add at least one line"); return; }
    const { data: { user } } = await supabase.auth.getUser();
    const inv_no = m.invoice_no || `INV-M-${Date.now().toString().slice(-7)}`;
    const { data: inv, error } = await supabase.from("invoices").insert({
      invoice_no: inv_no, client_id: m.client_id,
      invoice_date: m.invoice_date, period_from: m.period_from || null, period_to: m.period_to || null,
      subtotal: subtotal + fuel + Number(m.cn_charge || 0), gst: gstAmt, total: rounded,
      notes: `Manual invoice. Fuel ${m.fuel_pct}%, CN ${m.cn_charge}, GST ${m.gst_pct}%, Round-off ${autoRound}`,
      created_by: user?.id,
    }).select().single();
    if (error) { toast.error(error.message); return; }
    await supabase.from("invoice_items").insert(m.lines.map((l) => ({
      invoice_id: inv.id,
      description: l.description || `${l.awb_number} ${l.origin}→${l.destination}`,
      amount: lineAmount(l),
    })));
    await supabase.from("ledger_entries").insert({ client_id: m.client_id, description: `Invoice ${inv_no}`, reference: inv_no, debit: rounded, created_by: user?.id });
    toast.success("Manual invoice created");
    try {
      const { data: client } = await supabase.from("clients").select("*").eq("id", m.client_id).maybeSingle();
      // Build items array compatible with printInvoice (uses items[].shipments fallbacks)
      const printItems = m.lines.map((l) => ({
        amount: lineAmount(l),
        shipments: {
          awb_number: l.awb_number, booking_date: l.bkg_date, sender_city: l.origin, receiver_city: l.destination,
          chargeable_weight: l.weight, transport_mode: "SELF", service_type: l.service, contents: l.pkg_type,
          total_amount: lineAmount(l), gst: 0, other_charges: l.other,
        },
      }));
      const payload = { ...inv, gst: gstAmt, total: rounded, subtotal };
      if (format === "summary") printInvoiceSummary(payload, client, printItems, invSettings);
      else printInvoiceDetailed(payload, client, printItems, invSettings);
    } catch (e) { console.error(e); }
    setManualOpen(false);
    setM({ client_id: "", invoice_no: "", invoice_date: new Date().toISOString().slice(0,10), period_from: "", period_to: "", fuel_pct: 0, cn_charge: 0, gst_pct: 18, round_off: 0, lines: [blankLine()] });
    load();
  };

  const removeInvoice = async (inv: any) => {
    if (!confirm(`Delete invoice ${inv.invoice_no}? This will remove items and the ledger entry.`)) return;
    await supabase.from("invoice_items").delete().eq("invoice_id", inv.id);
    await supabase.from("ledger_entries").delete().eq("reference", inv.invoice_no).eq("client_id", inv.client_id);
    const { error } = await supabase.from("invoices").delete().eq("id", inv.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); load();
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Invoices" subtitle="Attached-style invoice format with PDF and Excel export" action={
        <div className="flex gap-2 items-center">
          <div className="hidden md:flex items-center gap-1 text-xs border rounded-md p-0.5">
            <button type="button" onClick={() => setFormat("detailed")} className={`px-2 py-1 rounded ${format === "detailed" ? "bg-primary text-primary-foreground" : ""}`}>Detailed</button>
            <button type="button" onClick={() => setFormat("summary")} className={`px-2 py-1 rounded ${format === "summary" ? "bg-primary text-primary-foreground" : ""}`}>Summary (Tally)</button>
          </div>
          <Button variant="outline" onClick={() => setManualOpen(true)}><FileEdit className="h-4 w-4 mr-1" />Manual Invoice</Button><Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button>+ Generate Invoice</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Generate Invoice</DialogTitle></DialogHeader>
            <div className="grid gap-3">
              <div><Label>Client</Label>
                <Select value={f.client_id} onValueChange={(v) => setF({ ...f, client_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>{clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.client_code} — {c.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>From</Label><Input type="date" value={f.period_from} onChange={(e) => setF({ ...f, period_from: e.target.value })} /></div>
                <div><Label>To</Label><Input type="date" value={f.period_to} onChange={(e) => setF({ ...f, period_to: e.target.value })} /></div>
              </div>
              <div><Label>Invoice No (optional)</Label><Input value={f.invoice_no} onChange={(e) => setF({ ...f, invoice_no: e.target.value })} /></div>
              <Button onClick={generate}>Generate</Button>
            </div>
          </DialogContent>
        </Dialog></div>
      } />
      <Card><CardContent className="p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left"><tr><th className="p-3">Invoice</th><th>Date</th><th>Client</th><th>Period</th><th>Status</th><th className="text-right p-3">Total</th><th className="p-3">Print</th></tr></thead>
          <tbody>{list.map((i) => (
            <tr key={i.id} className="border-t"><td className="p-3 font-mono">{i.invoice_no}</td><td>{i.invoice_date}</td><td>{i.clients?.name}</td><td>{i.period_from ? `${i.period_from} → ${i.period_to}` : "—"}</td><td className="capitalize">{i.status}</td><td className="text-right p-3 font-semibold">₹{Number(i.total).toFixed(2)}</td><td className="p-3 whitespace-nowrap space-x-1"><Button size="sm" variant="outline" onClick={() => reprint(i)}><Printer className="h-3 w-3 mr-1" />PDF</Button><Button size="sm" variant="outline" onClick={() => excel(i)}><FileSpreadsheet className="h-3 w-3 mr-1" />Excel</Button><Button size="sm" variant="destructive" onClick={() => removeInvoice(i)}><Trash2 className="h-3 w-3" /></Button></td></tr>
          ))}{list.length === 0 && <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">No invoices</td></tr>}</tbody>
        </table>
      </CardContent></Card>

      {/* Manual Invoice Dialog */}
      <Dialog open={manualOpen} onOpenChange={setManualOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Manual Invoice — Editable Line Items</DialogTitle></DialogHeader>
          <div className="grid gap-3 md:grid-cols-4 mb-3">
            <div className="md:col-span-2"><Label>Client *</Label>
              <Select value={m.client_id} onValueChange={(v) => setM({ ...m, client_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select client" /></SelectTrigger>
                <SelectContent>{clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.client_code} — {c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Invoice No</Label><Input placeholder="Auto if blank" value={m.invoice_no} onChange={(e) => setM({ ...m, invoice_no: e.target.value })} /></div>
            <div><Label>Invoice Date</Label><Input type="date" value={m.invoice_date} onChange={(e) => setM({ ...m, invoice_date: e.target.value })} /></div>
            <div><Label>Period From</Label><Input type="date" value={m.period_from} onChange={(e) => setM({ ...m, period_from: e.target.value })} /></div>
            <div><Label>Period To</Label><Input type="date" value={m.period_to} onChange={(e) => setM({ ...m, period_to: e.target.value })} /></div>
          </div>

          <div className="overflow-x-auto border rounded-md">
            <table className="w-full text-xs">
              <thead className="bg-muted/60"><tr>
                <th className="p-2">#</th><th>Date</th><th>AWB / Docket</th><th>Origin</th><th>Destination</th><th>Wt(kg)</th><th>Service</th><th>Pkg</th><th className="text-right">Freight</th><th className="text-right">Other</th><th className="text-right">Amount</th><th></th>
              </tr></thead>
              <tbody>{m.lines.map((l, i) => (
                <tr key={i} className="border-t">
                  <td className="p-1 text-center">{i + 1}</td>
                  <td><Input className="h-7" type="date" value={l.bkg_date} onChange={(e) => setLine(i, "bkg_date", e.target.value)} /></td>
                  <td><Input className="h-7 w-28" value={l.awb_number} onChange={(e) => setLine(i, "awb_number", e.target.value)} /></td>
                  <td><Input className="h-7 w-24" value={l.origin} onChange={(e) => setLine(i, "origin", e.target.value)} /></td>
                  <td><Input className="h-7 w-24" value={l.destination} onChange={(e) => setLine(i, "destination", e.target.value)} /></td>
                  <td><Input className="h-7 w-16" type="number" step="0.01" value={l.weight} onChange={(e) => setLine(i, "weight", +e.target.value)} /></td>
                  <td><Input className="h-7 w-24" value={l.service} onChange={(e) => setLine(i, "service", e.target.value)} /></td>
                  <td><Input className="h-7 w-20" value={l.pkg_type} onChange={(e) => setLine(i, "pkg_type", e.target.value)} /></td>
                  <td><Input className="h-7 w-20 text-right" type="number" step="0.01" value={l.freight} onChange={(e) => setLine(i, "freight", +e.target.value)} /></td>
                  <td><Input className="h-7 w-20 text-right" type="number" step="0.01" value={l.other} onChange={(e) => setLine(i, "other", +e.target.value)} /></td>
                  <td className="text-right pr-2 font-semibold">₹{lineAmount(l).toFixed(2)}</td>
                  <td><Button size="icon" variant="ghost" onClick={() => setM((p) => ({ ...p, lines: p.lines.filter((_, k) => k !== i) }))}><Trash2 className="h-3 w-3" /></Button></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
          <Button size="sm" variant="outline" className="mt-2" onClick={() => setM((p) => ({ ...p, lines: [...p.lines, blankLine()] }))}><Plus className="h-3 w-3 mr-1" />Add Row</Button>

          <div className="grid gap-3 md:grid-cols-2 mt-4">
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2 items-center"><Label>Fuel Charge %</Label><Input type="number" step="0.01" value={m.fuel_pct} onChange={(e) => setM({ ...m, fuel_pct: +e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-2 items-center"><Label>CN Charge ₹</Label><Input type="number" step="0.01" value={m.cn_charge} onChange={(e) => setM({ ...m, cn_charge: +e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-2 items-center"><Label>GST %</Label><Input type="number" step="0.01" value={m.gst_pct} onChange={(e) => setM({ ...m, gst_pct: +e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-2 items-center"><Label>Round-Off Adjust ₹</Label><Input type="number" step="0.01" value={m.round_off} onChange={(e) => setM({ ...m, round_off: +e.target.value })} /></div>
            </div>
            <div className="rounded-md border p-3 bg-muted/30 text-sm space-y-1">
              <div className="flex justify-between"><span>Subtotal (Freight + Other)</span><span className="font-mono">₹{subtotal.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Fuel ({m.fuel_pct}%)</span><span className="font-mono">₹{fuel.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>CN Charge</span><span className="font-mono">₹{Number(m.cn_charge||0).toFixed(2)}</span></div>
              <div className="flex justify-between border-t pt-1"><span>Taxable</span><span className="font-mono">₹{taxable.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>GST ({m.gst_pct}%)</span><span className="font-mono">₹{gstAmt.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Total</span><span className="font-mono">₹{grandRaw.toFixed(2)}</span></div>
              <div className="flex justify-between text-muted-foreground"><span>Round-off (auto)</span><span className="font-mono">{autoRound >= 0 ? "+" : ""}{autoRound.toFixed(2)}</span></div>
              <div className="flex justify-between text-lg font-bold border-t pt-2"><span>Grand Total</span><span className="font-mono text-primary">₹{rounded.toFixed(2)}</span></div>
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-3">
            <Button variant="outline" onClick={() => setManualOpen(false)}>Cancel</Button>
            <Button onClick={saveManual}>Save & Print</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
