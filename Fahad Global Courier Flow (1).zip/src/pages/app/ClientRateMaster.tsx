import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Download, ExternalLink, Plus, RefreshCcw, Save, Trash2, Upload, X } from "lucide-react";
import * as XLSX from "xlsx";
import { useSiteContent, SITE_DEFAULTS } from "@/hooks/useSiteContent";
import {
  ClientRateCard, DEFAULT_CARD, computeBilling, detectService, loadClientCard, saveClientCard,
  loadClientQuotationUrl, deleteClientQuotation, getQuotationPublicUrl,
} from "@/lib/clientRates";

const norm = (s: string) => (s || "").toLowerCase().trim();

export default function ClientRateMaster() {
  const [clients, setClients] = useState<any[]>([]);
  const [clientId, setClientId] = useState<string>("");
  const [card, setCard] = useState<ClientRateCard>(DEFAULT_CARD);
  const [busy, setBusy] = useState(false);
  const [quotationUrl, setQuotationUrl] = useState<string | null>(null);
  const [clientFiles, setClientFiles] = useState<any[]>([]);
  const { value: publicRates, setValue: setPublicRates, save: savePublicRates } = useSiteContent<any[]>("public_rates", SITE_DEFAULTS.public_rates as any);

  // demo calc
  const [demo, setDemo] = useState({ service: "Standard Air", city: "Indore", state: "Madhya Pradesh", actual: 8, l: 30, w: 30, h: 30, dv: 5000, oda: false, ins: false });
  const demoOut = useMemo(() => computeBilling(card, {
    service: detectService(demo.service), city: demo.city, state: demo.state,
    actualWeight: demo.actual, lengthCm: demo.l, widthCm: demo.w, heightCm: demo.h,
    declaredValue: demo.dv, odaApplied: demo.oda, insuranceApplied: demo.ins,
  }), [card, demo]);

  useEffect(() => {
    supabase.from("clients").select("id,name,client_code").eq("active", true).order("name").then(({ data }) => setClients(data ?? []));
  }, []);

  const loadClientFiles = async () => {
    const { data } = await (supabase as any).from("client_rate_master").select("client_id, quotation_url, updated_at").not("quotation_url", "is", null).order("updated_at", { ascending: false });
    setClientFiles(data ?? []);
  };
  useEffect(() => { loadClientFiles(); }, []);

  useEffect(() => {
    if (!clientId) { setCard(DEFAULT_CARD); setQuotationUrl(null); return; }
    loadClientCard(clientId).then(setCard);
    loadClientQuotationUrl(clientId).then(setQuotationUrl);
  }, [clientId]);

  const save = async () => {
    if (!clientId) { toast.error("Select a client"); return; }
    setBusy(true);
    const { error } = await saveClientCard(clientId, card) as any;
    setBusy(false);
    if (error) toast.error(error.message); else { toast.success("Rate master saved"); loadClientFiles(); }
  };

  const resetDefault = () => { setCard(DEFAULT_CARD); toast.info("Loaded Fahad default quotation — review and Save"); };

  // AIR helpers
  const setAirCity = (city: string, rate: number) => {
    const k = norm(city); if (!k) return;
    setCard({ ...card, air: { ...card.air, cities: { ...card.air.cities, [k]: rate } } });
  };
  const delAirCity = (k: string) => {
    const next = { ...card.air.cities }; delete next[k];
    setCard({ ...card, air: { ...card.air, cities: next } });
  };
  const setLocalCity = (city: string, rate: number) => {
    const k = norm(city); if (!k) return;
    setCard({ ...card, local: { ...card.local, cities: { ...card.local.cities, [k]: rate } } });
  };
  const delLocalCity = (k: string) => {
    const next = { ...card.local.cities }; delete next[k];
    setCard({ ...card, local: { ...card.local, cities: next } });
  };

  // Surface zones
  const setZone = (idx: number, patch: any) => {
    const zs = [...card.surface.zones]; zs[idx] = { ...zs[idx], ...patch };
    setCard({ ...card, surface: { ...card.surface, zones: zs } });
  };
  const addZone = () => setCard({ ...card, surface: { ...card.surface, zones: [...card.surface.zones, { zone: "NEW ZONE", rate: 0, cities: [], states: [] }] } });
  const delZone = (i: number) => setCard({ ...card, surface: { ...card.surface, zones: card.surface.zones.filter((_, x) => x !== i) } });

  // -- Bulk Excel/CSV upload (single client OR multi-client) --
  const downloadTemplate = () => {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([
      ["client_code","service","city","state","rate","min_weight","fuel_pct","gst_pct","fov_pct","insurance_pct","oda_per_kg","notes"],
      ["FGLC00001","AIR","Mumbai","",90,5,40,18,0.2,2,3,""],
      ["FGLC00001","AIR","Ahmedabad","",90,5,40,18,0.2,2,3,""],
      ["FGLC00001","AIR","REST OF INDIA","",140,5,40,18,0.2,2,3,"fallback"],
      ["FGLC00001","SURFACE","","Maharashtra",40,20,40,18,0.2,2,3,"WEST zone"],
      ["FGLC00001","SURFACE","REST OF INDIA","",50,20,40,18,0.2,2,3,"fallback"],
      ["FGLC00001","LOCAL","Delhi","",50,0.5,40,18,0.2,2,3,""],
    ]), "rates");
    XLSX.writeFile(wb, "client-rate-master-template.xlsx");
  };

  const importExcel = async (file: File) => {
    setBusy(true);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const rows = XLSX.utils.sheet_to_json<any>(wb.Sheets[wb.SheetNames[0]], { defval: "" });
      if (!rows.length) throw new Error("Empty sheet");

      // Resolve client codes → ids
      const codes = Array.from(new Set(rows.map(r => String(r.client_code || "").toUpperCase().trim()).filter(Boolean)));
      const { data: cs } = await supabase.from("clients").select("id,client_code").in("client_code", codes);
      const idMap: Record<string,string> = {};
      (cs ?? []).forEach((c: any) => idMap[c.client_code.toUpperCase()] = c.id);

      // Group rows per client
      const grouped: Record<string, any[]> = {};
      rows.forEach((r) => {
        const code = String(r.client_code || "").toUpperCase().trim();
        if (!code) return;
        (grouped[code] ||= []).push(r);
      });

      let saved = 0;
      for (const code of Object.keys(grouped)) {
        const cid = idMap[code] || (code === "*" ? clientId : "");
        if (!cid) continue;
        const next: ClientRateCard = JSON.parse(JSON.stringify(await loadClientCard(cid)));
        for (const r of grouped[code]) {
          const svc = String(r.service || "AIR").toUpperCase();
          const city = norm(String(r.city || ""));
          const state = norm(String(r.state || ""));
          const rate = Number(r.rate) || 0;
          if (r.fuel_pct) next.fuelPct = Number(r.fuel_pct);
          if (r.gst_pct) next.gstPct = Number(r.gst_pct);
          if (r.fov_pct) next.fovPctOfDV = Number(r.fov_pct);
          if (r.insurance_pct) next.insurancePctOfDV = Number(r.insurance_pct);
          if (r.oda_per_kg) next.odaPerKg = Number(r.oda_per_kg);
          if (svc === "AIR") {
            if (city === "rest of india") next.air.restOfIndia = rate;
            else if (city) next.air.cities[city] = rate;
            if (r.min_weight) next.air.minWeight = Number(r.min_weight);
          } else if (svc === "SURFACE") {
            if (city === "rest of india") next.surface.restOfIndia = rate;
            else if (state) {
              const zname = state.toUpperCase();
              const existing = next.surface.zones.find(z => z.zone === zname);
              if (existing) { existing.rate = rate; if (!existing.states?.includes(state)) (existing.states ||= []).push(state); }
              else next.surface.zones.push({ zone: zname, rate, cities: [], states: [state] });
            }
            if (r.min_weight) next.surface.minWeight = Number(r.min_weight);
          } else if (svc === "LOCAL") {
            if (city === "rest of india") next.local.restOfIndia = rate;
            else if (city) next.local.cities[city] = rate;
          }
        }
        await saveClientCard(cid, next);
        saved++;
      }
      toast.success(`Imported quotations for ${saved} client(s)`);
      if (clientId) setCard(await loadClientCard(clientId));
      loadClientFiles();
    } catch (e: any) { toast.error("Import failed: " + e.message); }
    finally { setBusy(false); }
  };

  const uploadQuotationFile = async (file: File) => {
    if (!clientId) { toast.error("Select a client first"); return; }
    setBusy(true);
    try {
      const path = `client-${clientId}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
      const { error: upErr } = await supabase.storage.from("rate-agreements").upload(path, file, { upsert: true });
      if (upErr) throw upErr;
      await saveClientCard(clientId, card, path);
      setQuotationUrl(path);
      loadClientFiles();
      toast.success("Quotation file attached to this client");
    } catch (e: any) { toast.error(e.message); }
    finally { setBusy(false); }
  };

  const openQuotation = async () => {
    if (!quotationUrl) return;
    const url = await getQuotationPublicUrl(quotationUrl);
    if (url) window.open(url, "_blank");
  };
  const removeQuotation = async () => {
    if (!clientId || !quotationUrl) return;
    if (!confirm("Delete the attached quotation file?")) return;
    setBusy(true);
    const { error } = await deleteClientQuotation(clientId, quotationUrl) as any;
    setBusy(false);
    if (error) return toast.error(error.message);
    setQuotationUrl(null);
    loadClientFiles();
    toast.success("Quotation file removed");
  };

  const openQuotationPath = async (path: string) => {
    const url = await getQuotationPublicUrl(path);
    if (url) window.open(url, "_blank");
  };
  const removeQuotationPath = async (cid: string, path: string) => {
    if (!confirm("Delete this client's attached quotation file?")) return;
    const { error } = await deleteClientQuotation(cid, path) as any;
    if (error) return toast.error(error.message);
    if (cid === clientId) setQuotationUrl(null);
    loadClientFiles();
    toast.success("Quotation file removed");
  };

  const airCityList = Object.entries(card.air.cities).sort(([a],[b]) => a.localeCompare(b));
  const localCityList = Object.entries(card.local.cities).sort(([a],[b]) => a.localeCompare(b));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Client Rate Master</h1>
          <p className="text-sm text-muted-foreground">Per-client quotations · auto-matched on booking · REST OF INDIA fallback</p>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="w-72">
            <Label>Client</Label>
            <Select value={clientId} onValueChange={setClientId}>
              <SelectTrigger><SelectValue placeholder="Select a client" /></SelectTrigger>
              <SelectContent>{clients.map(c => <SelectItem key={c.id} value={c.id}>{c.client_code} — {c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <Button variant="outline" onClick={resetDefault}><RefreshCcw className="h-3 w-3 mr-1" />Load Default</Button>
          <Button onClick={save} disabled={busy || !clientId}><Save className="h-3 w-3 mr-1" />Save</Button>
        </div>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-sm">Bulk import & file upload</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap items-center gap-2 text-sm">
          <Button size="sm" variant="outline" onClick={downloadTemplate}><Download className="h-3 w-3 mr-1" />Excel Template</Button>
          <label className={`inline-flex items-center gap-1 cursor-pointer rounded-md border px-3 py-1.5 ${busy ? "opacity-50" : ""}`}>
            <Upload className="h-3 w-3" /> Bulk Import (Excel/CSV — multi-client)
            <input type="file" accept=".xlsx,.xls,.csv" className="hidden" disabled={busy}
              onChange={(e) => { const f = e.target.files?.[0]; if (f) importExcel(f); e.target.value = ""; }} />
          </label>
          <label className={`inline-flex items-center gap-1 cursor-pointer rounded-md border px-3 py-1.5 ${busy ? "opacity-50" : ""}`}>
            <Upload className="h-3 w-3" /> Attach Quotation PDF/DOCX (this client)
            <input type="file" accept=".pdf,.docx,.doc,.xlsx,.xls" className="hidden" disabled={busy || !clientId}
              onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadQuotationFile(f); e.target.value = ""; }} />
          </label>
          {quotationUrl && (
            <div className="flex items-center gap-2 ml-2 rounded-md bg-muted/40 px-3 py-1.5 text-xs">
              <span className="font-medium">Attached:</span>
              <span className="font-mono max-w-[280px] truncate">{quotationUrl.split("/").pop()}</span>
              <Button size="sm" variant="outline" onClick={openQuotation}><ExternalLink className="h-3 w-3 mr-1" />Open</Button>
              <Button size="sm" variant="destructive" onClick={removeQuotation}><X className="h-3 w-3 mr-1" />Delete</Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Client-wise uploaded quotations</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          {clientFiles.map((row) => {
            const c = clients.find((x) => x.id === row.client_id);
            return (
              <div key={row.client_id} className="flex flex-wrap items-center justify-between gap-2 rounded-md border p-2">
                <div className="min-w-0">
                  <div className="font-medium">{c ? `${c.client_code} — ${c.name}` : row.client_id}</div>
                  <div className="font-mono text-xs text-muted-foreground truncate">{row.quotation_url?.split("/").pop()}</div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => openQuotationPath(row.quotation_url)}><ExternalLink className="h-3 w-3 mr-1" />Open</Button>
                  <Button size="sm" variant="outline" onClick={() => setClientId(row.client_id)}>Edit Rates</Button>
                  <Button size="sm" variant="destructive" onClick={() => removeQuotationPath(row.client_id, row.quotation_url)}><Trash2 className="h-3 w-3 mr-1" />Delete</Button>
                </div>
              </div>
            );
          })}
          {!clientFiles.length && <div className="text-muted-foreground">No quotation file uploaded yet.</div>}
        </CardContent>
      </Card>

      <Tabs defaultValue="air">
        <TabsList className="flex-wrap">
          <TabsTrigger value="air">AIR</TabsTrigger>
          <TabsTrigger value="surface">SURFACE</TabsTrigger>
          <TabsTrigger value="sameday">SAMEDAY</TabsTrigger>
          <TabsTrigger value="overnight">OVERNIGHT</TabsTrigger>
          <TabsTrigger value="local">LOCAL</TabsTrigger>
          <TabsTrigger value="rules">Rules</TabsTrigger>
          <TabsTrigger value="public">Public Website Rates</TabsTrigger>
          <TabsTrigger value="demo">Live Demo</TabsTrigger>
        </TabsList>

        <TabsContent value="air">
          <Card><CardContent className="p-4 space-y-3">
            <div className="grid md:grid-cols-3 gap-3">
              <div><Label>Min Chargeable (kg)</Label><Input type="number" value={card.air.minWeight} onChange={e => setCard({ ...card, air: { ...card.air, minWeight: +e.target.value } })} /></div>
              <div><Label>Volumetric Divisor</Label><Input type="number" value={card.air.divisor} onChange={e => setCard({ ...card, air: { ...card.air, divisor: +e.target.value } })} /></div>
              <div><Label>REST OF INDIA ₹/kg</Label><Input type="number" value={card.air.restOfIndia} onChange={e => setCard({ ...card, air: { ...card.air, restOfIndia: +e.target.value } })} /></div>
            </div>
            <div className="rounded border">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-left"><tr><th className="p-2">City</th><th className="p-2">₹/kg</th><th className="p-2 w-20">Action</th></tr></thead>
                <tbody>
                  {airCityList.map(([k,v]) => (
                    <tr key={k} className="border-t">
                      <td className="p-2 capitalize">{k}</td>
                      <td className="p-2"><Input type="number" value={v} onChange={e => setAirCity(k, +e.target.value)} /></td>
                      <td className="p-2"><Button size="sm" variant="destructive" onClick={() => delAirCity(k)}><Trash2 className="h-3 w-3" /></Button></td>
                    </tr>
                  ))}
                  <AddRow onAdd={(c, r) => setAirCity(c, r)} />
                </tbody>
              </table>
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="surface">
          <Card><CardContent className="p-4 space-y-3">
            <div className="grid md:grid-cols-3 gap-3">
              <div><Label>Min Chargeable (kg)</Label><Input type="number" value={card.surface.minWeight} onChange={e => setCard({ ...card, surface: { ...card.surface, minWeight: +e.target.value } })} /></div>
              <div><Label>Volumetric Divisor</Label><Input type="number" value={card.surface.divisor} onChange={e => setCard({ ...card, surface: { ...card.surface, divisor: +e.target.value } })} /></div>
              <div><Label>REST OF INDIA ₹/kg</Label><Input type="number" value={card.surface.restOfIndia} onChange={e => setCard({ ...card, surface: { ...card.surface, restOfIndia: +e.target.value } })} /></div>
            </div>
            <div className="space-y-3">
              {card.surface.zones.map((z, idx) => (
                <div key={idx} className="rounded border p-3 grid md:grid-cols-12 gap-2">
                  <div className="md:col-span-2"><Label>Zone</Label><Input value={z.zone} onChange={e => setZone(idx, { zone: e.target.value })} /></div>
                  <div className="md:col-span-1"><Label>₹/kg</Label><Input type="number" value={z.rate} onChange={e => setZone(idx, { rate: +e.target.value })} /></div>
                  <div className="md:col-span-2"><Label>TAT</Label><Input value={z.tat || ""} onChange={e => setZone(idx, { tat: e.target.value })} /></div>
                  <div className="md:col-span-3"><Label>Cities (comma)</Label><Textarea rows={2} value={z.cities.join(", ")} onChange={e => setZone(idx, { cities: e.target.value.split(",").map(s => s.trim()).filter(Boolean) })} /></div>
                  <div className="md:col-span-3"><Label>States (comma)</Label><Textarea rows={2} value={(z.states || []).join(", ")} onChange={e => setZone(idx, { states: e.target.value.split(",").map(s => s.trim()).filter(Boolean) })} /></div>
                  <div className="md:col-span-1 flex items-end"><Button size="sm" variant="destructive" onClick={() => delZone(idx)}><Trash2 className="h-3 w-3" /></Button></div>
                </div>
              ))}
              <Button size="sm" variant="outline" onClick={addZone}><Plus className="h-3 w-3 mr-1" />Add Zone</Button>
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="sameday"><SlabEditor label="Same Day" weight={card.sameday.minWeight} slabs={card.sameday.slabs}
          onMin={(v) => setCard({ ...card, sameday: { ...card.sameday, minWeight: v } })}
          onSlabs={(s) => setCard({ ...card, sameday: { ...card.sameday, slabs: s } })} /></TabsContent>
        <TabsContent value="overnight"><SlabEditor label="Overnight" weight={card.overnight.minWeight} slabs={card.overnight.slabs}
          onMin={(v) => setCard({ ...card, overnight: { ...card.overnight, minWeight: v } })}
          onSlabs={(s) => setCard({ ...card, overnight: { ...card.overnight, slabs: s } })} /></TabsContent>

        <TabsContent value="local">
          <Card><CardContent className="p-4 space-y-3">
            <div className="grid md:grid-cols-3 gap-3">
              <div><Label>Min Chargeable (kg)</Label><Input type="number" value={card.local.minWeight} onChange={e => setCard({ ...card, local: { ...card.local, minWeight: +e.target.value } })} /></div>
              <div><Label>REST OF INDIA ₹/kg</Label><Input type="number" value={card.local.restOfIndia ?? 0} onChange={e => setCard({ ...card, local: { ...card.local, restOfIndia: +e.target.value } })} /></div>
              <div><Label>Priority Multiplier (SameDay/Overnight Local)</Label><Input type="number" value={card.local.priorityMultiplier ?? 0} onChange={e => setCard({ ...card, local: { ...card.local, priorityMultiplier: +e.target.value } })} /></div>
            </div>
            <div className="rounded border">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-left"><tr><th className="p-2">City</th><th className="p-2">₹</th><th className="p-2 w-20">Action</th></tr></thead>
                <tbody>
                  {localCityList.map(([k,v]) => (
                    <tr key={k} className="border-t">
                      <td className="p-2 capitalize">{k}</td>
                      <td className="p-2"><Input type="number" value={v} onChange={e => setLocalCity(k, +e.target.value)} /></td>
                      <td className="p-2"><Button size="sm" variant="destructive" onClick={() => delLocalCity(k)}><Trash2 className="h-3 w-3" /></Button></td>
                    </tr>
                  ))}
                  <AddRow onAdd={(c, r) => setLocalCity(c, r)} />
                </tbody>
              </table>
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="rules">
          <Card><CardContent className="p-4 grid md:grid-cols-3 gap-3">
            <div><Label>Fuel %</Label><Input type="number" value={card.fuelPct} onChange={e => setCard({ ...card, fuelPct: +e.target.value })} /></div>
            <div><Label>GST %</Label><Input type="number" value={card.gstPct} onChange={e => setCard({ ...card, gstPct: +e.target.value })} /></div>
            <div />
            <div><Label>FOV % of DV</Label><Input type="number" step="0.01" value={card.fovPctOfDV} onChange={e => setCard({ ...card, fovPctOfDV: +e.target.value })} /></div>
            <div><Label>FOV Min ₹</Label><Input type="number" value={card.fovMin} onChange={e => setCard({ ...card, fovMin: +e.target.value })} /></div>
            <div />
            <div><Label>Insurance % of DV</Label><Input type="number" step="0.01" value={card.insurancePctOfDV} onChange={e => setCard({ ...card, insurancePctOfDV: +e.target.value })} /></div>
            <div><Label>Insurance Min ₹</Label><Input type="number" value={card.insuranceMin} onChange={e => setCard({ ...card, insuranceMin: +e.target.value })} /></div>
            <div />
            <div><Label>ODA ₹/kg</Label><Input type="number" value={card.odaPerKg} onChange={e => setCard({ ...card, odaPerKg: +e.target.value })} /></div>
            <div><Label>ODA Min ₹</Label><Input type="number" value={card.odaMin} onChange={e => setCard({ ...card, odaMin: +e.target.value })} /></div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="public">
          <Card><CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div><h3 className="font-semibold">Public website rate table</h3><p className="text-xs text-muted-foreground">These rates show on /rates and are separate from private client billing rates.</p></div>
              <Button size="sm" onClick={async () => { const e = await savePublicRates(publicRates); toast[e ? "error" : "success"](e ? e.message : "Public rates saved"); }}><Save className="h-3 w-3 mr-1" />Save Public Rates</Button>
            </div>
            <div className="rounded border overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-left"><tr><th className="p-2">Service</th><th>Destination</th><th>₹/kg</th><th>Min Kg</th><th>TAT</th><th>Active</th><th className="p-2">Action</th></tr></thead>
                <tbody>{(Array.isArray(publicRates) ? publicRates : []).map((r: any, i: number) => (
                  <tr key={i} className="border-t">
                    <td className="p-2"><Input value={r.service || ""} onChange={e => { const a = [...publicRates]; a[i] = { ...a[i], service: e.target.value }; setPublicRates(a); }} /></td>
                    <td><Input value={r.destination || ""} onChange={e => { const a = [...publicRates]; a[i] = { ...a[i], destination: e.target.value }; setPublicRates(a); }} /></td>
                    <td><Input type="number" value={r.rate || 0} onChange={e => { const a = [...publicRates]; a[i] = { ...a[i], rate: +e.target.value }; setPublicRates(a); }} /></td>
                    <td><Input type="number" value={r.min_weight || 0} onChange={e => { const a = [...publicRates]; a[i] = { ...a[i], min_weight: +e.target.value }; setPublicRates(a); }} /></td>
                    <td><Input value={r.tat || ""} onChange={e => { const a = [...publicRates]; a[i] = { ...a[i], tat: e.target.value }; setPublicRates(a); }} /></td>
                    <td><input type="checkbox" checked={r.active !== false} onChange={e => { const a = [...publicRates]; a[i] = { ...a[i], active: e.target.checked }; setPublicRates(a); }} /></td>
                    <td className="p-2"><Button size="sm" variant="destructive" onClick={() => setPublicRates(publicRates.filter((_: any, k: number) => k !== i))}><Trash2 className="h-3 w-3" /></Button></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <Button size="sm" variant="outline" onClick={() => setPublicRates([...(Array.isArray(publicRates) ? publicRates : []), { service: "Standard Air", destination: "New City", rate: 0, min_weight: 5, tat: "", active: true }])}><Plus className="h-3 w-3 mr-1" />Add Public Rate</Button>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="demo">
          <Card><CardContent className="p-4 grid md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div><Label>Service</Label>
                  <Select value={demo.service} onValueChange={(v) => setDemo({ ...demo, service: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["Standard Air","Road Express","SameDay","Overnight","Local Standard"].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Destination City</Label><Input value={demo.city} onChange={e => setDemo({ ...demo, city: e.target.value })} /></div>
                <div><Label>State</Label><Input value={demo.state} onChange={e => setDemo({ ...demo, state: e.target.value })} /></div>
                <div><Label>Actual Weight</Label><Input type="number" value={demo.actual} onChange={e => setDemo({ ...demo, actual: +e.target.value })} /></div>
                <div><Label>L cm</Label><Input type="number" value={demo.l} onChange={e => setDemo({ ...demo, l: +e.target.value })} /></div>
                <div><Label>B cm</Label><Input type="number" value={demo.w} onChange={e => setDemo({ ...demo, w: +e.target.value })} /></div>
                <div><Label>H cm</Label><Input type="number" value={demo.h} onChange={e => setDemo({ ...demo, h: +e.target.value })} /></div>
                <div><Label>Declared Value</Label><Input type="number" value={demo.dv} onChange={e => setDemo({ ...demo, dv: +e.target.value })} /></div>
              </div>
              <div className="flex gap-4 text-sm">
                <label className="flex items-center gap-2"><input type="checkbox" checked={demo.oda} onChange={e => setDemo({ ...demo, oda: e.target.checked })} /> ODA</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={demo.ins} onChange={e => setDemo({ ...demo, ins: e.target.checked })} /> Insurance</label>
              </div>
            </div>
            <div className="rounded border p-3 text-sm space-y-1 bg-muted/30">
              <div className="flex justify-between"><span>Matched</span><Badge variant={demoOut.matched === "rest-of-india" ? "secondary" : "default"}>{demoOut.matched.toUpperCase()} · {demoOut.zone}</Badge></div>
              <div className="flex justify-between"><span>Volumetric</span><span>{demoOut.volumetricWeight} kg</span></div>
              <div className="flex justify-between"><span>Billable</span><span>{demoOut.billableWeight} kg</span></div>
              <div className="flex justify-between"><span>Rate</span><span>₹ {demoOut.rate}/kg</span></div>
              <hr />
              <div className="flex justify-between"><span>Freight</span><span>₹ {demoOut.freight}</span></div>
              <div className="flex justify-between"><span>FOV</span><span>₹ {demoOut.fov}</span></div>
              <div className="flex justify-between"><span>Insurance</span><span>₹ {demoOut.insurance}</span></div>
              <div className="flex justify-between"><span>ODA</span><span>₹ {demoOut.oda}</span></div>
              <div className="flex justify-between font-medium"><span>Total</span><span>₹ {demoOut.total}</span></div>
              <div className="flex justify-between"><span>Fuel ({demoOut.fuelPct}%)</span><span>₹ {demoOut.fuel}</span></div>
              <div className="flex justify-between"><span>Sub Total</span><span>₹ {demoOut.subTotal}</span></div>
              <div className="flex justify-between"><span>GST ({demoOut.gstPct}%)</span><span>₹ {demoOut.gst}</span></div>
              <div className="flex justify-between text-base font-bold"><span>Grand Total</span><span>₹ {demoOut.grandTotal}</span></div>
            </div>
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function AddRow({ onAdd }: { onAdd: (city: string, rate: number) => void }) {
  const [c, setC] = useState(""); const [r, setR] = useState<number>(0);
  return (
    <tr className="border-t bg-muted/30">
      <td className="p-2"><Input placeholder="City" value={c} onChange={e => setC(e.target.value)} /></td>
      <td className="p-2"><Input type="number" value={r} onChange={e => setR(+e.target.value)} /></td>
      <td className="p-2"><Button size="sm" onClick={() => { if (c) { onAdd(c, r); setC(""); setR(0); } }}><Plus className="h-3 w-3" /></Button></td>
    </tr>
  );
}

function SlabEditor({ label, weight, slabs, onMin, onSlabs }: { label: string; weight: number; slabs: any[]; onMin: (v: number) => void; onSlabs: (s: any[]) => void; }) {
  const set = (i: number, patch: any) => { const next = [...slabs]; next[i] = { ...next[i], ...patch }; onSlabs(next); };
  return (
    <Card><CardContent className="p-4 space-y-3">
      <div className="grid md:grid-cols-3 gap-3"><div><Label>Min Weight ({label})</Label><Input type="number" value={weight} onChange={e => onMin(+e.target.value)} /></div></div>
      <div className="rounded border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left"><tr><th className="p-2">Up to (kg)</th><th className="p-2">Flat ₹</th><th className="p-2">Add ₹/kg</th><th className="p-2">₹/kg (replaces flat)</th><th className="p-2 w-20"></th></tr></thead>
          <tbody>
            {slabs.map((s, i) => (
              <tr key={i} className="border-t">
                <td className="p-2"><Input type="number" value={s.uptoKg} onChange={e => set(i, { uptoKg: +e.target.value })} /></td>
                <td className="p-2"><Input type="number" value={s.flat || 0} onChange={e => set(i, { flat: +e.target.value })} /></td>
                <td className="p-2"><Input type="number" value={s.addPerKg || 0} onChange={e => set(i, { addPerKg: +e.target.value })} /></td>
                <td className="p-2"><Input type="number" value={s.perKg || 0} onChange={e => set(i, { perKg: +e.target.value })} /></td>
                <td className="p-2"><Button size="sm" variant="destructive" onClick={() => onSlabs(slabs.filter((_, x) => x !== i))}><Trash2 className="h-3 w-3" /></Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Button size="sm" variant="outline" onClick={() => onSlabs([...slabs, { uptoKg: 9999, perKg: 0 }])}><Plus className="h-3 w-3 mr-1" />Add Slab</Button>
    </CardContent></Card>
  );
}