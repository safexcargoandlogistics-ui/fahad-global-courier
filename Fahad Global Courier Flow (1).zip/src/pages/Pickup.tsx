import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { PackagePlus, Search, Phone, MapPin, Calendar, CheckCircle2, Truck, User } from "lucide-react";
import { Logo } from "@/components/Logo";
import { SEO } from "@/components/SEO";
import { IndiaPostPicker } from "@/components/IndiaPostPicker";
import { format } from "date-fns";

const schema = z.object({
  contact_name: z.string().trim().min(2, "Name required").max(100),
  contact_phone: z.string().trim().regex(/^[+0-9\s-]{7,20}$/, "Valid phone required"),
  email: z.string().trim().email().max(200).optional().or(z.literal("")),
  pickup_address: z.string().trim().min(5, "Address required").max(500),
  pickup_city: z.string().trim().max(120).optional().or(z.literal("")),
  pickup_pincode: z.string().trim().max(10).optional().or(z.literal("")),
  pickup_date: z.string().trim().min(4, "Date required"),
  pickup_time: z.string().trim().max(20).optional().or(z.literal("")),
  pieces: z.coerce.number().int().min(1).max(9999),
  approx_weight: z.coerce.number().min(0).max(99999).optional(),
  remarks: z.string().trim().max(500).optional().or(z.literal("")),
});

const STATUS_LABEL: Record<string, { label: string; cls: string }> = {
  pending:    { label: "Pending Assignment", cls: "bg-amber-500/15 text-amber-700 border-amber-500/40" },
  assigned:   { label: "Assigned to Rider",  cls: "bg-blue-500/15 text-blue-700 border-blue-500/40" },
  picked:     { label: "Picked Up",          cls: "bg-emerald-500/15 text-emerald-700 border-emerald-500/40" },
  cancelled:  { label: "Cancelled",          cls: "bg-red-500/15 text-red-700 border-red-500/40" },
};

export default function Pickup() {
  const [sp, setSp] = useSearchParams();
  const [tab, setTab] = useState(sp.get("track") ? "track" : "request");

  const [form, setForm] = useState<any>({
    contact_name: "", contact_phone: "", email: "",
    pickup_address: "", pickup_city: "", pickup_pincode: "",
    pickup_date: new Date().toISOString().slice(0, 10), pickup_time: "",
    pieces: 1, approx_weight: 0, remarks: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState<any | null>(null);

  const submit = async () => {
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error(parsed.error.issues[0]?.message || "Check the form"); return; }
    setSubmitting(true);
    const payload: any = { ...parsed.data, status: "pending" };
    const { data, error } = await (supabase as any).from("pickup_requests").insert(payload).select().maybeSingle();
    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success("Pickup request submitted!");
    // Notify admin
    try {
      await (supabase as any).functions.invoke("send-transactional-email", {
        body: {
          templateName: "pickup-received",
          recipientEmail: "info@fahadglobal.com",
          templateData: {
            customerName: data.contact_name, phone: data.contact_phone, email: data.email,
            pickupDate: data.pickup_date, pickupTime: data.pickup_time,
            pickupAddress: data.pickup_address, city: data.pickup_city, pincode: data.pickup_pincode,
            pieces: data.pieces, weight: data.approx_weight, remarks: data.remarks,
          },
        },
      });
    } catch {}
    setSubmitted(data);
    setSp({ track: data.id });
    setTab("track");
  };

  // Tracking
  const [trackId, setTrackId] = useState(sp.get("track") || "");
  const [trackPhone, setTrackPhone] = useState("");
  const [results, setResults] = useState<any[] | null>(null);
  const doTrack = async () => {
    let q = (supabase as any).from("pickup_requests").select("*").order("created_at", { ascending: false }).limit(20);
    if (trackId) q = q.eq("id", trackId);
    else if (trackPhone) q = q.eq("contact_phone", trackPhone);
    else { toast.error("Enter request ID or phone"); return; }
    const { data, error } = await q;
    if (error) return toast.error(error.message);
    setResults(data ?? []);
  };
  useEffect(() => { if (sp.get("track")) { setTrackId(sp.get("track")!); doTrack(); } /* eslint-disable-next-line */ }, []);

  return (
    <div className="min-h-screen bg-background">
      <SEO title="Book a Pickup | FAHAD GLOBAL LOGISTICS" description="Schedule a free door pickup with FAHAD GLOBAL LOGISTICS — domestic & international courier service." path="/pickup" />
      <header className="border-b bg-card">
        <div className="container flex h-14 items-center justify-between">
          <Link to="/" className="flex items-center gap-2"><Logo className="h-9 w-auto" /><span className="font-bold uppercase tracking-wider">FAHAD GLOBAL LOGISTICS</span></Link>
          <div className="flex gap-2">
            <Link to="/track"><Button size="sm" variant="outline">Track Shipment</Button></Link>
            <Link to="/auth"><Button size="sm">Login</Button></Link>
          </div>
        </div>
      </header>
      <section className="border-b bg-gradient-to-b from-primary/10 to-background">
        <div className="container max-w-4xl py-10 text-center">
          <div className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><PackagePlus className="h-7 w-7" /></div>
          <h1 className="mt-3 text-3xl md:text-4xl font-bold">Pickup &amp; Tracking</h1>
          <p className="mt-2 text-muted-foreground">Schedule a door pickup or check your pickup status — all in one place.</p>
        </div>
      </section>
      <main className="container max-w-4xl py-8">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="w-full grid grid-cols-2">
            <TabsTrigger value="request"><PackagePlus className="h-4 w-4 mr-2" />Request Pickup</TabsTrigger>
            <TabsTrigger value="track"><Search className="h-4 w-4 mr-2" />Track Pickup</TabsTrigger>
          </TabsList>

          <TabsContent value="request">
            <Card><CardContent className="pt-6 grid gap-3 md:grid-cols-2">
              <div><Label>Your Name *</Label><Input value={form.contact_name} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} placeholder="Full name" maxLength={100} /></div>
              <div><Label>Phone *</Label><Input value={form.contact_phone} onChange={(e) => setForm({ ...form, contact_phone: e.target.value })} placeholder="+91 9876543210" maxLength={20} /></div>
              <div className="md:col-span-2"><Label>Email (for updates)</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" maxLength={200} /></div>
              <div className="md:col-span-2"><Label>Pickup Address *</Label><Textarea value={form.pickup_address} onChange={(e) => setForm({ ...form, pickup_address: e.target.value })} placeholder="House / shop number, street, area" maxLength={500} /></div>
              <div className="md:col-span-2"><Label>City / Pincode (worldwide search)</Label><IndiaPostPicker value={form.pickup_city || form.pickup_pincode} onSelect={(loc) => setForm({ ...form, pickup_city: loc.city, pickup_pincode: loc.pincode })} /></div>
              <div><Label>Pickup Date *</Label><Input type="date" value={form.pickup_date} onChange={(e) => setForm({ ...form, pickup_date: e.target.value })} min={new Date().toISOString().slice(0, 10)} /></div>
              <div><Label>Preferred Time</Label><Input value={form.pickup_time} onChange={(e) => setForm({ ...form, pickup_time: e.target.value })} placeholder="e.g. 10:00 AM - 02:00 PM" maxLength={20} /></div>
              <div><Label>No. of Pieces *</Label><Input type="number" min={1} value={form.pieces} onChange={(e) => setForm({ ...form, pieces: +e.target.value || 1 })} /></div>
              <div><Label>Approx Weight (kg)</Label><Input type="number" min={0} step="0.1" value={form.approx_weight} onChange={(e) => setForm({ ...form, approx_weight: +e.target.value || 0 })} /></div>
              <div className="md:col-span-2"><Label>Remarks / Contents</Label><Textarea value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} placeholder="Any special instructions" maxLength={500} /></div>
              <div className="md:col-span-2 flex justify-end"><Button onClick={submit} disabled={submitting} size="lg"><PackagePlus className="h-4 w-4 mr-2" />{submitting ? "Submitting…" : "Submit Pickup Request"}</Button></div>
              {submitted && (
                <div className="md:col-span-2 rounded-lg border border-primary/30 bg-primary/5 p-4 flex items-center gap-3">
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                  <div className="text-sm">Request submitted! Your tracking ID: <span className="font-mono font-bold">{submitted.id}</span></div>
                </div>
              )}
            </CardContent></Card>
          </TabsContent>

          <TabsContent value="track">
            <Card><CardContent className="pt-6 grid gap-3 md:grid-cols-[1fr_1fr_auto]">
              <Input placeholder="Pickup request ID" value={trackId} onChange={(e) => setTrackId(e.target.value)} />
              <Input placeholder="OR phone number" value={trackPhone} onChange={(e) => setTrackPhone(e.target.value)} />
              <Button onClick={doTrack}><Search className="h-4 w-4 mr-2" />Track</Button>
            </CardContent></Card>
            <div className="mt-4 space-y-3">
              {results?.length === 0 && <div className="rounded-lg border border-dashed p-6 text-center text-muted-foreground text-sm">No pickup request found.</div>}
              {results?.map((r) => {
                const meta = STATUS_LABEL[r.status] || { label: r.status, cls: "bg-muted" };
                return (
                  <Card key={r.id} className="border-l-4 border-l-primary">
                    <CardContent className="pt-5 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="font-mono text-xs text-muted-foreground">{r.id}</div>
                        <Badge className={`${meta.cls} border`}>{meta.label}</Badge>
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm">
                        <span className="inline-flex items-center gap-1"><User className="h-3.5 w-3.5 text-primary" />{r.contact_name}</span>
                        <span className="inline-flex items-center gap-1"><Phone className="h-3.5 w-3.5 text-primary" />{r.contact_phone}</span>
                        <span className="inline-flex items-center gap-1"><Calendar className="h-3.5 w-3.5 text-primary" />{format(new Date(r.pickup_date), "dd MMM yyyy")}{r.pickup_time ? ` · ${r.pickup_time}` : ""}</span>
                        <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5 text-primary" />{[r.pickup_city, r.pickup_pincode].filter(Boolean).join(" - ") || "—"}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{r.pickup_address}</p>
                      {r.assigned_rider && (
                        <div className="rounded-md bg-emerald-50 border border-emerald-200 px-3 py-2 text-sm flex items-center gap-2 text-emerald-800"><Truck className="h-4 w-4" />Rider assigned: <span className="font-semibold">{r.assigned_rider}</span>{r.assigned_at && <span className="text-xs text-emerald-700/70 ml-auto">{format(new Date(r.assigned_at), "dd MMM HH:mm")}</span>}</div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}