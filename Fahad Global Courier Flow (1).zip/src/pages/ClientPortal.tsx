import { useEffect, useState } from "react";
import { Navigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Logo } from "@/components/Logo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Package, LogOut, Search, BarChart3, Truck, MessageSquareWarning } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ClientPortal() {
  const { user, loading, isStaff, signOut } = useAuth();
  const [client, setClient] = useState<any>(null);
  const [shipments, setShipments] = useState<any[]>([]);
  const [pickups, setPickups] = useState<any[]>([]);
  const [tickets, setTickets] = useState<any[]>([]);
  const [now, setNow] = useState(new Date());
  const [trackAwb, setTrackAwb] = useState("");
  const [trackResult, setTrackResult] = useState<any>(null);
  const [trackEvents, setTrackEvents] = useState<any[]>([]);

  // Pickup form
  const [pickupForm, setPickupForm] = useState({ pickup_date: new Date().toISOString().slice(0,10), pickup_time: "10:00", pickup_address: "", pickup_city: "", pickup_pincode: "", contact_name: "", contact_phone: "", pieces: 1, approx_weight: 0, remarks: "" });
  // Ticket form
  const [ticketForm, setTicketForm] = useState({ subject: "", description: "", awb_number: "", priority: "normal" });

  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);

  const loadAll = async () => {
    if (!user) return;
    const { data: c } = await supabase.from("clients").select("*").eq("user_id", user.id).maybeSingle();
    setClient(c);
    if (c) {
      const { data } = await supabase.from("shipments").select("*").eq("client_id", c.id).order("created_at", { ascending: false }).limit(200);
      setShipments(data ?? []);
    }
    const { data: pk } = await (supabase as any).from("pickup_requests").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
    setPickups(pk ?? []);
    const { data: tk } = await (supabase as any).from("support_tickets").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
    setTickets(tk ?? []);
  };
  useEffect(() => { loadAll(); }, [user]);

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading…</div>;
  if (!user) return <Navigate to="/auth" replace />;
  if (isStaff) return <Navigate to="/app" replace />;

  // ---- Track ----
  const doTrack = async () => {
    const code = trackAwb.trim().toUpperCase(); if (!code) return;
    const { data: s } = await (supabase as any).from("public_tracking_shipments").select("*").eq("awb_number", code).maybeSingle();
    setTrackResult(s);
    if (s) {
      const { data: e } = await supabase.from("tracking_events").select("status,location,event_at,remarks").eq("shipment_id", s.shipment_id).order("event_at", { ascending: false });
      setTrackEvents((e ?? []).map((ev: any) => ({ ...ev, remarks: ev.remarks ? String(ev.remarks).replace(/\b(MF-[A-Z0-9-]+|DRS-[A-Z0-9-]+)\b/gi, "").trim() : null })));
    } else { setTrackEvents([]); toast.error("AWB not found"); }
  };

  // ---- MIS metrics ----
  const total = shipments.length;
  const delivered = shipments.filter(s => s.status === "delivered").length;
  const inTransit = shipments.filter(s => ["in_transit","manifested","out_for_delivery","received_at_branch"].includes(s.status)).length;
  const pending = total - delivered - inTransit;
  const totalAmount = shipments.reduce((a, s) => a + Number(s.total_amount || 0), 0);

  // ---- Pickup submit ----
  const submitPickup = async () => {
    if (!pickupForm.pickup_address || !pickupForm.contact_phone) { toast.error("Address and contact phone required"); return; }
    const { error } = await (supabase as any).from("pickup_requests").insert({ ...pickupForm, user_id: user.id, client_id: client?.id ?? null });
    if (error) return toast.error(error.message);
    toast.success("Pickup request submitted");
    setPickupForm({ ...pickupForm, pickup_address: "", pickup_city: "", pickup_pincode: "", contact_name: "", remarks: "" });
    loadAll();
  };

  // ---- Ticket submit ----
  const submitTicket = async () => {
    if (!ticketForm.subject || !ticketForm.description) { toast.error("Subject and description required"); return; }
    const { error } = await (supabase as any).from("support_tickets").insert({ ...ticketForm, user_id: user.id, client_id: client?.id ?? null });
    if (error) return toast.error(error.message);
    toast.success("Ticket raised — our team will respond shortly.");
    setTicketForm({ subject: "", description: "", awb_number: "", priority: "normal" });
    loadAll();
  };

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-card sticky top-0 z-10">
        <div className="container flex h-14 items-center justify-between">
          <Link to="/" className="flex items-center gap-2"><Logo className="h-9 w-auto" /><span className="font-bold text-sm">Fahad Global — Client Portal</span></Link>
          <div className="flex items-center gap-3 text-sm">
            <span className="hidden md:inline text-muted-foreground">{format(now, "dd MMM yyyy, HH:mm:ss")}</span>
            <span className="hidden md:inline">{user.email}</span>
            <Button size="sm" variant="ghost" onClick={signOut}><LogOut className="h-4 w-4 mr-1" />Logout</Button>
          </div>
        </div>
      </header>

      <main className="container py-6 space-y-4">
        {client && (
          <Card><CardContent className="pt-6 grid md:grid-cols-4 gap-4">
            <div><div className="text-xs text-muted-foreground">Client Code</div><div className="font-bold">{client.client_code}</div></div>
            <div><div className="text-xs text-muted-foreground">Name</div><div className="font-bold">{client.name}</div></div>
            <div><div className="text-xs text-muted-foreground">Total Shipments</div><div className="font-bold">{shipments.length}</div></div>
            <div><div className="text-xs text-muted-foreground">Credit Limit</div><div className="font-bold">₹{client.credit_limit}</div></div>
          </CardContent></Card>
        )}

        <Tabs defaultValue="track">
          <TabsList className="grid w-full grid-cols-4 max-w-2xl">
            <TabsTrigger value="track"><Search className="h-4 w-4 mr-1" />Track</TabsTrigger>
            <TabsTrigger value="mis"><BarChart3 className="h-4 w-4 mr-1" />MIS</TabsTrigger>
            <TabsTrigger value="pickup"><Truck className="h-4 w-4 mr-1" />Pickup</TabsTrigger>
            <TabsTrigger value="ticket"><MessageSquareWarning className="h-4 w-4 mr-1" />Ticket</TabsTrigger>
          </TabsList>

          {/* TRACK */}
          <TabsContent value="track" className="space-y-3">
            <Card><CardHeader><CardTitle>Track Shipment</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="flex gap-2">
                  <Input placeholder="Enter AWB number" value={trackAwb} onChange={(e) => setTrackAwb(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === "Enter" && doTrack()} />
                  <Button onClick={doTrack}>Track</Button>
                </div>
                {trackResult && (
                  <div className="rounded-md border p-3 space-y-2 text-sm">
                    <div className="flex justify-between"><span className="font-mono font-bold">{trackResult.awb_number}</span><Badge className="capitalize">{trackResult.status?.replace(/_/g," ")}</Badge></div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div><div className="text-muted-foreground">From</div><div className="font-semibold">{trackResult.sender_city}</div></div>
                      <div><div className="text-muted-foreground">To</div><div className="font-semibold">{trackResult.receiver_city}</div></div>
                      <div className="col-span-2"><div className="text-muted-foreground">Current</div><div className="font-semibold text-primary">{trackResult.current_branch_city || "—"}</div></div>
                    </div>
                    <ol className="border-l-2 border-primary/20 ml-2 space-y-2 mt-2">
                      {trackEvents.map((e, i) => (
                        <li key={i} className="ml-3 pl-2">
                          <div className="text-xs font-semibold capitalize">{e.status?.replace(/_/g," ")} <span className="text-muted-foreground font-normal ml-2">{format(new Date(e.event_at), "dd MMM HH:mm")}</span></div>
                          {e.location && <div className="text-xs text-muted-foreground">{e.location}</div>}
                          {e.remarks && <div className="text-xs">{e.remarks}</div>}
                        </li>
                      ))}
                    </ol>
                  </div>
                )}
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50 text-left"><tr><th className="p-2">AWB</th><th>Date</th><th>To</th><th>Status</th></tr></thead>
                    <tbody>{shipments.slice(0, 20).map((s) => (
                      <tr key={s.id} className="border-t">
                        <td className="p-2 font-mono"><button onClick={() => { setTrackAwb(s.awb_number); setTimeout(doTrack, 50); }} className="text-primary hover:underline">{s.awb_number}</button></td>
                        <td>{s.booking_date}</td><td>{s.receiver_city}</td>
                        <td><Badge variant="secondary" className="capitalize">{s.status.replace(/_/g," ")}</Badge></td>
                      </tr>
                    ))}</tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* MIS */}
          <TabsContent value="mis" className="space-y-3">
            <div className="grid md:grid-cols-4 gap-3">
              <Card><CardContent className="pt-6"><div className="text-xs text-muted-foreground">Total</div><div className="text-3xl font-bold">{total}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-xs text-muted-foreground">Delivered</div><div className="text-3xl font-bold text-success">{delivered}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-xs text-muted-foreground">In Transit</div><div className="text-3xl font-bold text-primary">{inTransit}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-xs text-muted-foreground">Total Spend</div><div className="text-3xl font-bold">₹{totalAmount.toFixed(0)}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Package className="h-5 w-5" />My Shipments</CardTitle></CardHeader>
              <CardContent className="overflow-x-auto p-0">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 text-left"><tr><th className="p-3">AWB</th><th>Date</th><th>Receiver</th><th>City</th><th>Status</th><th className="text-right p-3">Amount</th></tr></thead>
                  <tbody>{shipments.map((s) => (
                    <tr key={s.id} className="border-t hover:bg-muted/30">
                      <td className="p-3 font-mono">{s.awb_number}</td>
                      <td>{s.booking_date}</td>
                      <td>{s.receiver_name}</td>
                      <td>{s.receiver_city}</td>
                      <td><Badge variant="secondary" className="capitalize">{s.status.replace(/_/g, " ")}</Badge></td>
                      <td className="text-right p-3">₹{Number(s.total_amount).toFixed(2)}</td>
                    </tr>
                  ))}{shipments.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No shipments</td></tr>}</tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* PICKUP */}
          <TabsContent value="pickup" className="space-y-3">
            <Card><CardHeader><CardTitle>Request a Pickup</CardTitle></CardHeader>
              <CardContent className="grid gap-3 md:grid-cols-3">
                <div><Label>Pickup Date</Label><Input type="date" value={pickupForm.pickup_date} onChange={(e) => setPickupForm({ ...pickupForm, pickup_date: e.target.value })} /></div>
                <div><Label>Time</Label><Input type="time" value={pickupForm.pickup_time} onChange={(e) => setPickupForm({ ...pickupForm, pickup_time: e.target.value })} /></div>
                <div><Label>Pieces</Label><Input type="number" min={1} value={pickupForm.pieces} onChange={(e) => setPickupForm({ ...pickupForm, pieces: +e.target.value })} /></div>
                <div className="md:col-span-3"><Label>Pickup Address *</Label><Textarea value={pickupForm.pickup_address} onChange={(e) => setPickupForm({ ...pickupForm, pickup_address: e.target.value })} /></div>
                <div><Label>City</Label><Input value={pickupForm.pickup_city} onChange={(e) => setPickupForm({ ...pickupForm, pickup_city: e.target.value })} /></div>
                <div><Label>Pincode</Label><Input value={pickupForm.pickup_pincode} onChange={(e) => setPickupForm({ ...pickupForm, pickup_pincode: e.target.value })} /></div>
                <div><Label>Approx Weight (kg)</Label><Input type="number" step="0.1" value={pickupForm.approx_weight} onChange={(e) => setPickupForm({ ...pickupForm, approx_weight: +e.target.value })} /></div>
                <div><Label>Contact Name</Label><Input value={pickupForm.contact_name} onChange={(e) => setPickupForm({ ...pickupForm, contact_name: e.target.value })} /></div>
                <div><Label>Contact Phone *</Label><Input value={pickupForm.contact_phone} onChange={(e) => setPickupForm({ ...pickupForm, contact_phone: e.target.value })} /></div>
                <div className="md:col-span-3"><Label>Remarks</Label><Textarea value={pickupForm.remarks} onChange={(e) => setPickupForm({ ...pickupForm, remarks: e.target.value })} /></div>
                <div className="md:col-span-3 flex justify-end"><Button onClick={submitPickup}>Submit Request</Button></div>
              </CardContent>
            </Card>
            <Card><CardHeader><CardTitle>My Pickup Requests</CardTitle></CardHeader>
              <CardContent className="overflow-x-auto p-0">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 text-left"><tr><th className="p-3">Date</th><th>Address</th><th>Pieces</th><th>Status</th><th>Submitted</th></tr></thead>
                  <tbody>{pickups.map((p) => (
                    <tr key={p.id} className="border-t">
                      <td className="p-3">{p.pickup_date} {p.pickup_time}</td>
                      <td className="max-w-xs truncate">{p.pickup_address}</td>
                      <td>{p.pieces}</td>
                      <td><Badge variant="secondary" className="capitalize">{p.status}</Badge></td>
                      <td>{format(new Date(p.created_at), "dd MMM HH:mm")}</td>
                    </tr>
                  ))}{pickups.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-muted-foreground">No pickup requests yet</td></tr>}</tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TICKET */}
          <TabsContent value="ticket" className="space-y-3">
            <Card><CardHeader><CardTitle>Raise a Support Ticket</CardTitle></CardHeader>
              <CardContent className="grid gap-3 md:grid-cols-2">
                <div><Label>Subject *</Label><Input value={ticketForm.subject} onChange={(e) => setTicketForm({ ...ticketForm, subject: e.target.value })} /></div>
                <div><Label>AWB (optional)</Label><Input value={ticketForm.awb_number} onChange={(e) => setTicketForm({ ...ticketForm, awb_number: e.target.value.toUpperCase() })} /></div>
                <div><Label>Priority</Label>
                  <Select value={ticketForm.priority} onValueChange={(v) => setTicketForm({ ...ticketForm, priority: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="low">Low</SelectItem><SelectItem value="normal">Normal</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="urgent">Urgent</SelectItem></SelectContent>
                  </Select>
                </div>
                <div className="md:col-span-2"><Label>Description *</Label><Textarea rows={4} value={ticketForm.description} onChange={(e) => setTicketForm({ ...ticketForm, description: e.target.value })} /></div>
                <div className="md:col-span-2 flex justify-end"><Button onClick={submitTicket}>Raise Ticket</Button></div>
              </CardContent>
            </Card>
            <Card><CardHeader><CardTitle>My Tickets</CardTitle></CardHeader>
              <CardContent className="overflow-x-auto p-0">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 text-left"><tr><th className="p-3">Subject</th><th>AWB</th><th>Priority</th><th>Status</th><th>Response</th><th>Date</th></tr></thead>
                  <tbody>{tickets.map((t) => (
                    <tr key={t.id} className="border-t">
                      <td className="p-3 font-medium">{t.subject}</td>
                      <td className="font-mono">{t.awb_number || "—"}</td>
                      <td><Badge variant="outline" className="capitalize">{t.priority}</Badge></td>
                      <td><Badge variant="secondary" className="capitalize">{t.status}</Badge></td>
                      <td className="max-w-xs truncate text-muted-foreground">{t.admin_response ?? "—"}</td>
                      <td>{format(new Date(t.created_at), "dd MMM HH:mm")}</td>
                    </tr>
                  ))}{tickets.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No tickets yet</td></tr>}</tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t bg-card mt-8">
        <div className="container py-4 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} Fahad Global Logistics  |  {format(now, "dd MMM yyyy, HH:mm:ss")}  |  info@fahadglobal.com  |  7352363283 / 9711522296
        </div>
      </footer>
    </div>
  );
}
