import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Logo } from "@/components/Logo";
import { useSiteContent, SITE_DEFAULTS } from "@/hooks/useSiteContent";
import { SEO } from "@/components/SEO";
import { IndianRupee, Search, Truck } from "lucide-react";
import { useMemo, useState } from "react";
import { RateTatCalculator } from "@/components/RateTatCalculator";

export default function PublicRates() {
  const { value } = useSiteContent<any[]>("public_rates", SITE_DEFAULTS.public_rates as any);
  const [q, setQ] = useState("");
  const rows = useMemo(() => (Array.isArray(value) ? value : []).filter((r: any) => r.active !== false).filter((r: any) => `${r.service} ${r.destination}`.toLowerCase().includes(q.toLowerCase())), [value, q]);
  return (
    <div className="min-h-screen bg-background">
      <SEO title="Courier Rates India | FAHAD GLOBAL LOGISTICS" description="View public courier rates for air, surface and express services from FAHAD GLOBAL LOGISTICS across India." path="/rates" jsonLd={{ "@context": "https://schema.org", "@type": "Service", name: "Courier rate card", provider: { "@type": "Organization", name: "FAHAD GLOBAL LOGISTICS" } }} />
      <header className="border-b bg-card">
        <div className="container flex h-14 items-center justify-between">
          <Link to="/" className="flex items-center gap-2"><Logo className="h-9 w-auto" /><span className="font-bold uppercase tracking-wider">FAHAD GLOBAL LOGISTICS</span></Link>
          <div className="flex gap-2"><Link to="/track"><Button size="sm" variant="outline">Track</Button></Link><Link to="/auth"><Button size="sm">Login</Button></Link></div>
        </div>
      </header>
      <section className="border-b bg-gradient-to-b from-primary/10 to-background">
        <div className="container max-w-5xl py-12">
          <div className="grid gap-6 lg:grid-cols-[1fr_420px] lg:items-start">
            <div>
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary"><IndianRupee className="h-6 w-6" /></div>
              <h1 className="mt-4 text-3xl font-bold md:text-4xl">Courier Rate Card</h1>
              <p className="mt-2 max-w-2xl text-muted-foreground">Public indicative rates. Client-specific billing runs from private quotation in Client Rate Master.</p>
            </div>
            <RateTatCalculator compact />
          </div>
        </div>
      </section>
      <main className="container max-w-5xl py-8">
        <div className="relative mb-4 w-full md:w-96"><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><Input className="pl-9" placeholder="Search destination or service" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left"><tr><th className="p-4">Service</th><th>Destination</th><th>Rate</th><th>Min Weight</th><th>TAT</th></tr></thead>
              <tbody>{rows.map((r: any, i: number) => (
                <tr key={`${r.service}-${r.destination}-${i}`} className="border-t">
                  <td className="p-4 font-medium"><Truck className="mr-2 inline h-4 w-4 text-primary" />{r.service}</td>
                  <td>{r.destination}</td><td className="font-semibold">₹{Number(r.rate || 0).toFixed(2)}/kg</td><td>{r.min_weight || 0} kg</td><td>{r.tat || "Contact us"}</td>
                </tr>
              ))}{!rows.length && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No public rates found.</td></tr>}</tbody>
            </table>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}