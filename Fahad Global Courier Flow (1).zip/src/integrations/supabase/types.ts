export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      branches: {
        Row: {
          active: boolean
          address: string | null
          branch_code: string
          city: string | null
          contact_person: string | null
          created_at: string
          email: string | null
          id: string
          name: string
          phone: string | null
          pincode: string | null
          state: string | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          address?: string | null
          branch_code: string
          city?: string | null
          contact_person?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name: string
          phone?: string | null
          pincode?: string | null
          state?: string | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          address?: string | null
          branch_code?: string
          city?: string | null
          contact_person?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          phone?: string | null
          pincode?: string | null
          state?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      client_rate_master: {
        Row: {
          client_id: string
          data: Json
          quotation_url: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          client_id: string
          data?: Json
          quotation_url?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          client_id?: string
          data?: Json
          quotation_url?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      clients: {
        Row: {
          active: boolean
          address: string | null
          city: string | null
          client_code: string
          contact_person: string | null
          created_at: string
          credit_limit: number | null
          email: string | null
          gstin: string | null
          id: string
          name: string
          opening_balance: number | null
          pan: string | null
          phone: string | null
          pincode: string | null
          state: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          active?: boolean
          address?: string | null
          city?: string | null
          client_code?: string
          contact_person?: string | null
          created_at?: string
          credit_limit?: number | null
          email?: string | null
          gstin?: string | null
          id?: string
          name: string
          opening_balance?: number | null
          pan?: string | null
          phone?: string | null
          pincode?: string | null
          state?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          active?: boolean
          address?: string | null
          city?: string | null
          client_code?: string
          contact_person?: string | null
          created_at?: string
          credit_limit?: number | null
          email?: string | null
          gstin?: string | null
          id?: string
          name?: string
          opening_balance?: number | null
          pan?: string | null
          phone?: string | null
          pincode?: string | null
          state?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      drs: {
        Row: {
          area: string | null
          branch_id: string | null
          created_at: string
          created_by: string | null
          delivery_boy: string
          delivery_boy_phone: string | null
          drs_date: string
          drs_no: string
          id: string
          remarks: string | null
          total_pieces: number | null
        }
        Insert: {
          area?: string | null
          branch_id?: string | null
          created_at?: string
          created_by?: string | null
          delivery_boy: string
          delivery_boy_phone?: string | null
          drs_date?: string
          drs_no: string
          id?: string
          remarks?: string | null
          total_pieces?: number | null
        }
        Update: {
          area?: string | null
          branch_id?: string | null
          created_at?: string
          created_by?: string | null
          delivery_boy?: string
          delivery_boy_phone?: string | null
          drs_date?: string
          drs_no?: string
          id?: string
          remarks?: string | null
          total_pieces?: number | null
        }
        Relationships: []
      }
      drs_shipments: {
        Row: {
          drs_id: string
          id: string
          shipment_id: string
        }
        Insert: {
          drs_id: string
          id?: string
          shipment_id: string
        }
        Update: {
          drs_id?: string
          id?: string
          shipment_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "drs_shipments_drs_id_fkey"
            columns: ["drs_id"]
            isOneToOne: false
            referencedRelation: "drs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "drs_shipments_shipment_id_fkey"
            columns: ["shipment_id"]
            isOneToOne: false
            referencedRelation: "shipments"
            referencedColumns: ["id"]
          },
        ]
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          status?: string
          template_name?: string
        }
        Relationships: []
      }
      email_send_state: {
        Row: {
          auth_email_ttl_minutes: number
          batch_size: number
          id: number
          retry_after_until: string | null
          send_delay_ms: number
          transactional_email_ttl_minutes: number
          updated_at: string
        }
        Insert: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Update: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_unsubscribe_tokens: {
        Row: {
          created_at: string
          email: string
          id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          token: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      invoice_items: {
        Row: {
          amount: number
          description: string | null
          id: string
          invoice_id: string
          shipment_id: string | null
        }
        Insert: {
          amount?: number
          description?: string | null
          id?: string
          invoice_id: string
          shipment_id?: string | null
        }
        Update: {
          amount?: number
          description?: string | null
          id?: string
          invoice_id?: string
          shipment_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invoice_items_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_items_shipment_id_fkey"
            columns: ["shipment_id"]
            isOneToOne: false
            referencedRelation: "shipments"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          client_id: string
          created_at: string
          created_by: string | null
          gst: number | null
          id: string
          invoice_date: string
          invoice_no: string
          notes: string | null
          paid: number | null
          period_from: string | null
          period_to: string | null
          status: string
          subtotal: number | null
          total: number | null
        }
        Insert: {
          client_id: string
          created_at?: string
          created_by?: string | null
          gst?: number | null
          id?: string
          invoice_date?: string
          invoice_no: string
          notes?: string | null
          paid?: number | null
          period_from?: string | null
          period_to?: string | null
          status?: string
          subtotal?: number | null
          total?: number | null
        }
        Update: {
          client_id?: string
          created_at?: string
          created_by?: string | null
          gst?: number | null
          id?: string
          invoice_date?: string
          invoice_no?: string
          notes?: string | null
          paid?: number | null
          period_from?: string | null
          period_to?: string | null
          status?: string
          subtotal?: number | null
          total?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "invoices_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      ledger_entries: {
        Row: {
          client_id: string
          created_at: string
          created_by: string | null
          credit: number | null
          debit: number | null
          description: string
          entry_date: string
          id: string
          reference: string | null
        }
        Insert: {
          client_id: string
          created_at?: string
          created_by?: string | null
          credit?: number | null
          debit?: number | null
          description: string
          entry_date?: string
          id?: string
          reference?: string | null
        }
        Update: {
          client_id?: string
          created_at?: string
          created_by?: string | null
          credit?: number | null
          debit?: number | null
          description?: string
          entry_date?: string
          id?: string
          reference?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ledger_entries_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      manifest_shipments: {
        Row: {
          id: string
          manifest_id: string
          shipment_id: string
        }
        Insert: {
          id?: string
          manifest_id: string
          shipment_id: string
        }
        Update: {
          id?: string
          manifest_id?: string
          shipment_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "manifest_shipments_manifest_id_fkey"
            columns: ["manifest_id"]
            isOneToOne: false
            referencedRelation: "manifests"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "manifest_shipments_shipment_id_fkey"
            columns: ["shipment_id"]
            isOneToOne: false
            referencedRelation: "shipments"
            referencedColumns: ["id"]
          },
        ]
      }
      manifests: {
        Row: {
          created_at: string
          created_by: string | null
          destination: string | null
          destination_branch_id: string | null
          driver_name: string | null
          driver_phone: string | null
          id: string
          manifest_date: string
          manifest_no: string
          manifest_type: Database["public"]["Enums"]["manifest_type"]
          origin: string | null
          origin_branch_id: string | null
          remarks: string | null
          total_pieces: number | null
          total_weight: number | null
          vehicle_no: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          destination?: string | null
          destination_branch_id?: string | null
          driver_name?: string | null
          driver_phone?: string | null
          id?: string
          manifest_date?: string
          manifest_no: string
          manifest_type: Database["public"]["Enums"]["manifest_type"]
          origin?: string | null
          origin_branch_id?: string | null
          remarks?: string | null
          total_pieces?: number | null
          total_weight?: number | null
          vehicle_no?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          destination?: string | null
          destination_branch_id?: string | null
          driver_name?: string | null
          driver_phone?: string | null
          id?: string
          manifest_date?: string
          manifest_no?: string
          manifest_type?: Database["public"]["Enums"]["manifest_type"]
          origin?: string | null
          origin_branch_id?: string | null
          remarks?: string | null
          total_pieces?: number | null
          total_weight?: number | null
          vehicle_no?: string | null
        }
        Relationships: []
      }
      pickup_requests: {
        Row: {
          approx_weight: number | null
          assigned_at: string | null
          assigned_branch_id: string | null
          assigned_rider: string | null
          client_id: string | null
          contact_name: string | null
          contact_phone: string
          created_at: string
          email: string | null
          id: string
          pickup_address: string
          pickup_city: string | null
          pickup_date: string
          pickup_pincode: string | null
          pickup_time: string | null
          pieces: number | null
          remarks: string | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          approx_weight?: number | null
          assigned_at?: string | null
          assigned_branch_id?: string | null
          assigned_rider?: string | null
          client_id?: string | null
          contact_name?: string | null
          contact_phone: string
          created_at?: string
          email?: string | null
          id?: string
          pickup_address: string
          pickup_city?: string | null
          pickup_date?: string
          pickup_pincode?: string | null
          pickup_time?: string | null
          pieces?: number | null
          remarks?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          approx_weight?: number | null
          assigned_at?: string | null
          assigned_branch_id?: string | null
          assigned_rider?: string | null
          client_id?: string | null
          contact_name?: string | null
          contact_phone?: string
          created_at?: string
          email?: string | null
          id?: string
          pickup_address?: string
          pickup_city?: string | null
          pickup_date?: string
          pickup_pincode?: string | null
          pickup_time?: string | null
          pieces?: number | null
          remarks?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      pincodes: {
        Row: {
          branch_id: string | null
          city: string | null
          cod_available: boolean
          created_at: string
          id: string
          pincode: string
          serviceable: boolean
          state: string | null
          tat_days: number | null
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          city?: string | null
          cod_available?: boolean
          created_at?: string
          id?: string
          pincode: string
          serviceable?: boolean
          state?: string | null
          tat_days?: number | null
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          city?: string | null
          cod_available?: boolean
          created_at?: string
          id?: string
          pincode?: string
          serviceable?: boolean
          state?: string | null
          tat_days?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          branch_id: string | null
          client_id: string | null
          created_at: string
          full_name: string | null
          id: string
          phone: string | null
        }
        Insert: {
          branch_id?: string | null
          client_id?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          phone?: string | null
        }
        Update: {
          branch_id?: string | null
          client_id?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
        }
        Relationships: []
      }
      public_tracking_shipments: {
        Row: {
          awb_number: string
          booking_date: string | null
          chargeable_weight: number | null
          current_branch_city: string | null
          current_branch_name: string | null
          delivered_at: string | null
          destination_branch_city: string | null
          height_cm: number | null
          length_cm: number | null
          pieces: number | null
          pod_at: string | null
          pod_received_by: string | null
          pod_url: string | null
          receiver_city: string | null
          receiver_country: string | null
          receiver_name: string | null
          receiver_pincode: string | null
          receiver_state: string | null
          sender_city: string | null
          sender_name: string | null
          sender_pincode: string | null
          service_type: string | null
          shipment_id: string
          status: string | null
          transport_mode: string | null
          updated_at: string | null
          volumetric_divisor: number | null
          volumetric_weight: number | null
          width_cm: number | null
        }
        Insert: {
          awb_number: string
          booking_date?: string | null
          chargeable_weight?: number | null
          current_branch_city?: string | null
          current_branch_name?: string | null
          delivered_at?: string | null
          destination_branch_city?: string | null
          height_cm?: number | null
          length_cm?: number | null
          pieces?: number | null
          pod_at?: string | null
          pod_received_by?: string | null
          pod_url?: string | null
          receiver_city?: string | null
          receiver_country?: string | null
          receiver_name?: string | null
          receiver_pincode?: string | null
          receiver_state?: string | null
          sender_city?: string | null
          sender_name?: string | null
          sender_pincode?: string | null
          service_type?: string | null
          shipment_id: string
          status?: string | null
          transport_mode?: string | null
          updated_at?: string | null
          volumetric_divisor?: number | null
          volumetric_weight?: number | null
          width_cm?: number | null
        }
        Update: {
          awb_number?: string
          booking_date?: string | null
          chargeable_weight?: number | null
          current_branch_city?: string | null
          current_branch_name?: string | null
          delivered_at?: string | null
          destination_branch_city?: string | null
          height_cm?: number | null
          length_cm?: number | null
          pieces?: number | null
          pod_at?: string | null
          pod_received_by?: string | null
          pod_url?: string | null
          receiver_city?: string | null
          receiver_country?: string | null
          receiver_name?: string | null
          receiver_pincode?: string | null
          receiver_state?: string | null
          sender_city?: string | null
          sender_name?: string | null
          sender_pincode?: string | null
          service_type?: string | null
          shipment_id?: string
          status?: string | null
          transport_mode?: string | null
          updated_at?: string | null
          volumetric_divisor?: number | null
          volumetric_weight?: number | null
          width_cm?: number | null
        }
        Relationships: []
      }
      rate_cards: {
        Row: {
          agreement_url: string | null
          base_rate: number
          client_id: string | null
          created_at: string
          destination_city: string | null
          destination_pincode: string | null
          id: string
          mode: Database["public"]["Enums"]["shipment_mode"]
          notes: string | null
          origin_city: string | null
          origin_pincode: string | null
          per_kg_rate: number
          weight_from: number
          weight_to: number
          zone: string
        }
        Insert: {
          agreement_url?: string | null
          base_rate?: number
          client_id?: string | null
          created_at?: string
          destination_city?: string | null
          destination_pincode?: string | null
          id?: string
          mode?: Database["public"]["Enums"]["shipment_mode"]
          notes?: string | null
          origin_city?: string | null
          origin_pincode?: string | null
          per_kg_rate?: number
          weight_from?: number
          weight_to?: number
          zone: string
        }
        Update: {
          agreement_url?: string | null
          base_rate?: number
          client_id?: string | null
          created_at?: string
          destination_city?: string | null
          destination_pincode?: string | null
          id?: string
          mode?: Database["public"]["Enums"]["shipment_mode"]
          notes?: string | null
          origin_city?: string | null
          origin_pincode?: string | null
          per_kg_rate?: number
          weight_from?: number
          weight_to?: number
          zone?: string
        }
        Relationships: [
          {
            foreignKeyName: "rate_cards_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      shipments: {
        Row: {
          actual_weight: number
          awb_number: string
          bill_booking: boolean | null
          booking_date: string
          chargeable_weight: number
          client_id: string | null
          cod_amount: number | null
          contents: string | null
          created_at: string
          created_by: string | null
          current_branch_id: string | null
          declared_value: number | null
          delivered_at: string | null
          destination_branch_id: string | null
          distance_km: number | null
          eway_bill_data: Json | null
          eway_bill_no: string | null
          freight: number | null
          fuel_charge: number | null
          gst: number | null
          height_cm: number | null
          id: string
          invoice_no: string | null
          length_cm: number | null
          mode: Database["public"]["Enums"]["shipment_mode"]
          origin_branch_id: string | null
          other_charges: number | null
          payment_mode: Database["public"]["Enums"]["payment_mode"]
          pieces: number
          pod_at: string | null
          pod_received_by: string | null
          pod_url: string | null
          received_at: string | null
          received_by: string | null
          receiver_address: string | null
          receiver_city: string
          receiver_country: string | null
          receiver_name: string
          receiver_phone: string | null
          receiver_pincode: string
          receiver_state: string | null
          reference_no: string | null
          remarks: string | null
          sender_address: string | null
          sender_city: string | null
          sender_name: string
          sender_phone: string | null
          sender_pincode: string | null
          service_type: string | null
          status: Database["public"]["Enums"]["shipment_status"]
          total_amount: number | null
          transport_mode: string | null
          undelivered_reason: string | null
          updated_at: string
          volumetric_divisor: number | null
          volumetric_weight: number | null
          width_cm: number | null
        }
        Insert: {
          actual_weight?: number
          awb_number?: string
          bill_booking?: boolean | null
          booking_date?: string
          chargeable_weight?: number
          client_id?: string | null
          cod_amount?: number | null
          contents?: string | null
          created_at?: string
          created_by?: string | null
          current_branch_id?: string | null
          declared_value?: number | null
          delivered_at?: string | null
          destination_branch_id?: string | null
          distance_km?: number | null
          eway_bill_data?: Json | null
          eway_bill_no?: string | null
          freight?: number | null
          fuel_charge?: number | null
          gst?: number | null
          height_cm?: number | null
          id?: string
          invoice_no?: string | null
          length_cm?: number | null
          mode?: Database["public"]["Enums"]["shipment_mode"]
          origin_branch_id?: string | null
          other_charges?: number | null
          payment_mode?: Database["public"]["Enums"]["payment_mode"]
          pieces?: number
          pod_at?: string | null
          pod_received_by?: string | null
          pod_url?: string | null
          received_at?: string | null
          received_by?: string | null
          receiver_address?: string | null
          receiver_city: string
          receiver_country?: string | null
          receiver_name: string
          receiver_phone?: string | null
          receiver_pincode: string
          receiver_state?: string | null
          reference_no?: string | null
          remarks?: string | null
          sender_address?: string | null
          sender_city?: string | null
          sender_name: string
          sender_phone?: string | null
          sender_pincode?: string | null
          service_type?: string | null
          status?: Database["public"]["Enums"]["shipment_status"]
          total_amount?: number | null
          transport_mode?: string | null
          undelivered_reason?: string | null
          updated_at?: string
          volumetric_divisor?: number | null
          volumetric_weight?: number | null
          width_cm?: number | null
        }
        Update: {
          actual_weight?: number
          awb_number?: string
          bill_booking?: boolean | null
          booking_date?: string
          chargeable_weight?: number
          client_id?: string | null
          cod_amount?: number | null
          contents?: string | null
          created_at?: string
          created_by?: string | null
          current_branch_id?: string | null
          declared_value?: number | null
          delivered_at?: string | null
          destination_branch_id?: string | null
          distance_km?: number | null
          eway_bill_data?: Json | null
          eway_bill_no?: string | null
          freight?: number | null
          fuel_charge?: number | null
          gst?: number | null
          height_cm?: number | null
          id?: string
          invoice_no?: string | null
          length_cm?: number | null
          mode?: Database["public"]["Enums"]["shipment_mode"]
          origin_branch_id?: string | null
          other_charges?: number | null
          payment_mode?: Database["public"]["Enums"]["payment_mode"]
          pieces?: number
          pod_at?: string | null
          pod_received_by?: string | null
          pod_url?: string | null
          received_at?: string | null
          received_by?: string | null
          receiver_address?: string | null
          receiver_city?: string
          receiver_country?: string | null
          receiver_name?: string
          receiver_phone?: string | null
          receiver_pincode?: string
          receiver_state?: string | null
          reference_no?: string | null
          remarks?: string | null
          sender_address?: string | null
          sender_city?: string | null
          sender_name?: string
          sender_phone?: string | null
          sender_pincode?: string | null
          service_type?: string | null
          status?: Database["public"]["Enums"]["shipment_status"]
          total_amount?: number | null
          transport_mode?: string | null
          undelivered_reason?: string | null
          updated_at?: string
          volumetric_divisor?: number | null
          volumetric_weight?: number | null
          width_cm?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "shipments_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      shipments_trash: {
        Row: {
          awb_number: string
          deleted_at: string
          deleted_by: string | null
          drs_links: Json | null
          id: string
          manifest_links: Json | null
          original_id: string
          shipment_data: Json
          tracking_data: Json | null
        }
        Insert: {
          awb_number: string
          deleted_at?: string
          deleted_by?: string | null
          drs_links?: Json | null
          id?: string
          manifest_links?: Json | null
          original_id: string
          shipment_data: Json
          tracking_data?: Json | null
        }
        Update: {
          awb_number?: string
          deleted_at?: string
          deleted_by?: string | null
          drs_links?: Json | null
          id?: string
          manifest_links?: Json | null
          original_id?: string
          shipment_data?: Json
          tracking_data?: Json | null
        }
        Relationships: []
      }
      site_content: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      support_tickets: {
        Row: {
          admin_response: string | null
          awb_number: string | null
          client_id: string | null
          created_at: string
          description: string
          id: string
          priority: string
          status: string
          subject: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_response?: string | null
          awb_number?: string | null
          client_id?: string | null
          created_at?: string
          description: string
          id?: string
          priority?: string
          status?: string
          subject: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_response?: string | null
          awb_number?: string | null
          client_id?: string | null
          created_at?: string
          description?: string
          id?: string
          priority?: string
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      suppressed_emails: {
        Row: {
          created_at: string
          email: string
          id: string
          metadata: Json | null
          reason: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          metadata?: Json | null
          reason: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          metadata?: Json | null
          reason?: string
        }
        Relationships: []
      }
      tracking_actions: {
        Row: {
          action: string
          admin_notes: string | null
          awb_number: string
          contact_name: string | null
          contact_phone: string | null
          created_at: string
          id: string
          payload: Json | null
          shipment_id: string | null
          status: string
          updated_at: string
        }
        Insert: {
          action: string
          admin_notes?: string | null
          awb_number: string
          contact_name?: string | null
          contact_phone?: string | null
          created_at?: string
          id?: string
          payload?: Json | null
          shipment_id?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          action?: string
          admin_notes?: string | null
          awb_number?: string
          contact_name?: string | null
          contact_phone?: string | null
          created_at?: string
          id?: string
          payload?: Json | null
          shipment_id?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      tracking_events: {
        Row: {
          created_by: string | null
          event_at: string
          id: string
          location: string | null
          receiver_name: string | null
          remarks: string | null
          shipment_id: string
          status: Database["public"]["Enums"]["shipment_status"]
          undelivered_reason: string | null
        }
        Insert: {
          created_by?: string | null
          event_at?: string
          id?: string
          location?: string | null
          receiver_name?: string | null
          remarks?: string | null
          shipment_id: string
          status: Database["public"]["Enums"]["shipment_status"]
          undelivered_reason?: string | null
        }
        Update: {
          created_by?: string | null
          event_at?: string
          id?: string
          location?: string | null
          receiver_name?: string | null
          remarks?: string | null
          shipment_id?: string
          status?: Database["public"]["Enums"]["shipment_status"]
          undelivered_reason?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tracking_events_shipment_id_fkey"
            columns: ["shipment_id"]
            isOneToOne: false
            referencedRelation: "shipments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      website_branches: {
        Row: {
          active: boolean
          address: string | null
          city: string | null
          contact_person: string | null
          created_at: string
          display_order: number
          email: string | null
          id: string
          image_url: string | null
          map_url: string | null
          name: string
          phone: string | null
          state: string | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          address?: string | null
          city?: string | null
          contact_person?: string | null
          created_at?: string
          display_order?: number
          email?: string | null
          id?: string
          image_url?: string | null
          map_url?: string | null
          name: string
          phone?: string | null
          state?: string | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          address?: string | null
          city?: string | null
          contact_person?: string | null
          created_at?: string
          display_order?: number
          email?: string | null
          id?: string
          image_url?: string | null
          map_url?: string | null
          name?: string
          phone?: string | null
          state?: string | null
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_access_branch_record: {
        Args: { _branch_ids: string[]; _user_id: string }
        Returns: boolean
      }
      delete_email: {
        Args: { message_id: number; queue_name: string }
        Returns: boolean
      }
      enqueue_email: {
        Args: { payload: Json; queue_name: string }
        Returns: number
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff_or_admin: { Args: { _user_id: string }; Returns: boolean }
      move_to_dlq: {
        Args: {
          dlq_name: string
          message_id: number
          payload: Json
          source_queue: string
        }
        Returns: number
      }
      next_awb: { Args: never; Returns: string }
      next_client_code: { Args: never; Returns: string }
      read_email_batch: {
        Args: { batch_size: number; queue_name: string; vt: number }
        Returns: {
          message: Json
          msg_id: number
          read_ct: number
        }[]
      }
      restore_shipment: { Args: { _trash_id: string }; Returns: string }
      user_branch_id: { Args: { _user_id: string }; Returns: string }
    }
    Enums: {
      app_role: "admin" | "staff" | "client" | "branch_manager"
      manifest_type: "outgoing" | "incoming"
      payment_mode: "prepaid" | "topay" | "cod" | "credit"
      shipment_mode: "domestic" | "international"
      shipment_status:
        | "booked"
        | "manifested"
        | "in_transit"
        | "out_for_delivery"
        | "delivered"
        | "undelivered"
        | "rto"
        | "cancelled"
        | "received_at_branch"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "staff", "client", "branch_manager"],
      manifest_type: ["outgoing", "incoming"],
      payment_mode: ["prepaid", "topay", "cod", "credit"],
      shipment_mode: ["domestic", "international"],
      shipment_status: [
        "booked",
        "manifested",
        "in_transit",
        "out_for_delivery",
        "delivered",
        "undelivered",
        "rto",
        "cancelled",
        "received_at_branch",
      ],
    },
  },
} as const
