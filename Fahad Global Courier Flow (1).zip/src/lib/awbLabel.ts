import jsPDF from "jspdf";
import QRCode from "qrcode";
import logoUrl from "@/assets/logo.png";

export const COMPANY = {
  name: "FAHAD GLOBAL LOGISTICS",
  tagline: "Your Vision Perfectly Delivered",
  gstin: "09AEXPF5632E1Z9",
  ho: "Shop No 01, Ground Floor, Main Thapar Gate Road, Vandana Vihar, Khora Colony, Ghaziabad, UP 201020",
  branch: "F 30/5, Opp HDFC Bank, Okhla Industrial Estate Phase II, New Delhi 110020",
  phone: "7352363283 / 9711522296",
  email: "info@fahadglobal.com",
  web: "www.fahadglobal.com",
};

const money = (v: any) => Number(v || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const text = (v: any, fallback = "-") => (v === null || v === undefined || v === "" ? fallback : String(v));
const shortDate = (v: any) => (v ? new Date(v).toLocaleDateString("en-GB") : new Date().toLocaleDateString("en-GB"));

/** Renders one docket copy in a section of A4 (top y, height h) */
function renderCopy(doc: jsPDF, s: any, qrUrl: string, top: number, h: number, copyLabel: string) {
  const left = 8, right = 202, width = right - left;
  doc.setDrawColor(0); doc.setLineWidth(0.4);
  doc.rect(left, top, width, h);

  // Header strip
  try { doc.addImage(logoUrl, "PNG", left + 2, top + 2, 22, 14); } catch {}
  doc.setFont("helvetica", "bold"); doc.setTextColor(44, 112, 184); doc.setFontSize(13);
  doc.text(COMPANY.name, left + width / 2, top + 7, { align: "center" });
  doc.setTextColor(0); doc.setFontSize(6.4); doc.setFont("helvetica", "normal");
  doc.text(COMPANY.ho, left + width / 2, top + 11, { align: "center", maxWidth: 140 });
  doc.text(`Ph. ${COMPANY.phone} | ${COMPANY.email} | ${COMPANY.web} | GSTIN: ${COMPANY.gstin}`, left + width / 2, top + 14.5, { align: "center" });
  // Copy badge
  doc.setFillColor(44, 112, 184); doc.rect(right - 32, top + 1.5, 30, 5, "F");
  doc.setTextColor(255); doc.setFont("helvetica", "bold"); doc.setFontSize(7);
  doc.text(copyLabel, right - 17, top + 5.2, { align: "center" });
  doc.setTextColor(0);

  // AWB + QR row
  const awbY = top + 18;
  doc.line(left, awbY, right, awbY);
  doc.setFont("helvetica", "bold"); doc.setFontSize(7); doc.text("AWB No.", left + 2, awbY + 5);
  doc.setFontSize(13); doc.text(text(s.awb_number), left + 18, awbY + 6);
  doc.setFontSize(7); doc.text("Booking Date", left + 78, awbY + 5); doc.text(shortDate(s.booking_date), left + 105, awbY + 5);
  doc.text("Mode", left + 130, awbY + 5); doc.text(text(s.transport_mode), left + 145, awbY + 5);
  doc.text("Service", left + 130, awbY + 8.5); doc.text(text(s.service_type), left + 145, awbY + 8.5);
  doc.addImage(qrUrl, "PNG", right - 17, awbY + 1, 15, 15);

  // Sender / Consignee row
  const sy = awbY + 17;
  doc.line(left, sy, right, sy);
  const colW = width / 2;
  doc.line(left + colW, sy, left + colW, sy + 26);
  doc.setFont("helvetica", "bold"); doc.setFontSize(7);
  doc.text("FROM (SHIPPER)", left + 2, sy + 4);
  doc.text("TO (CONSIGNEE)", left + colW + 2, sy + 4);
  doc.setFont("helvetica", "normal"); doc.setFontSize(7);
  doc.text(text(s.sender_name), left + 2, sy + 9, { maxWidth: colW - 4 });
  doc.text(text(s.sender_address), left + 2, sy + 13, { maxWidth: colW - 4 });
  doc.text(`${text(s.sender_city)} - ${text(s.sender_pincode)}  Mob: ${text(s.sender_phone)}`, left + 2, sy + 23, { maxWidth: colW - 4 });
  doc.setFont("helvetica", "bold");
  doc.text(text(s.receiver_name), left + colW + 2, sy + 9, { maxWidth: colW - 4 });
  doc.setFont("helvetica", "normal");
  doc.text(text(s.receiver_address), left + colW + 2, sy + 13, { maxWidth: colW - 4 });
  doc.text(`${text(s.receiver_city)}, ${text(s.receiver_state)} - ${text(s.receiver_pincode)} (${text(s.receiver_country, "India")})`, left + colW + 2, sy + 21, { maxWidth: colW - 4 });
  doc.text(`Mob: ${text(s.receiver_phone)}`, left + colW + 2, sy + 25);

  // Parcel row
  const py = sy + 27;
  doc.line(left, py, right, py);
  const cols = [left, left + 16, left + 32, left + 56, left + 76, left + 96, left + 124, left + 150, right];
  cols.slice(1, -1).forEach((x) => doc.line(x, py, x, py + 16));
  doc.line(left, py + 7, right, py + 7);
  doc.setFont("helvetica", "bold"); doc.setFontSize(6.5);
  ["PCS", "ACT WT", "DIM L×W×H", "VOL WT", "CHG WT", "CONTENTS", "INVOICE", "PAYMENT"].forEach((h, i) => doc.text(h, cols[i] + 1.5, py + 4.5));
  doc.setFont("helvetica", "normal"); doc.setFontSize(7);
  const vals = [
    text(s.pieces, "1"),
    `${text(s.actual_weight, "0")}kg`,
    `${text(s.length_cm, "0")}×${text(s.width_cm, "0")}×${text(s.height_cm, "0")}`,
    `${text(s.volumetric_weight, "0")}kg`,
    `${text(s.chargeable_weight, "0")}kg`,
    text(s.contents),
    text(s.invoice_no || s.reference_no),
    text(s.payment_mode).toUpperCase(),
  ];
  vals.forEach((v, i) => doc.text(v, cols[i] + 1.5, py + 12, { maxWidth: cols[i + 1] - cols[i] - 3 }));

  // Charges + signatures
  const cy = py + 17;
  const bottom = top + h;
  doc.line(left, cy, right, cy);
  doc.line(left + 130, cy, left + 130, bottom - 1);
  doc.setFont("helvetica", "bold"); doc.setFontSize(7);
  doc.text("DECLARATION", left + 2, cy + 4);
  doc.setFont("helvetica", "normal"); doc.setFontSize(5.5);
  doc.text(
    "Shipper declares contents do not contain cash, jewellery, contraband or restricted articles. Liability per company terms. Disputes subject to origin jurisdiction.",
    left + 2, cy + 8, { maxWidth: 124 }
  );
  doc.setFontSize(6);
  doc.text("Sender Sign: __________________", left + 2, bottom - 3);
  doc.text("For Fahad Global: __________________", left + 65, bottom - 3);

  // CHARGES — compact rows that always fit
  doc.setFont("helvetica", "bold"); doc.setFontSize(7);
  doc.text("CHARGES", left + 132, cy + 4);
  doc.setFont("helvetica", "normal"); doc.setFontSize(6.5);
  const ch: [string, any][] = [
    ["Freight", s.freight],
    ["Fuel", s.fuel_charge],
    ["Other", s.other_charges],
    ["GST", s.gst],
    ["COD", s.cod_amount],
  ];
  const rowH = 3.2;
  ch.forEach((r, i) => {
    const yy = cy + 7.5 + i * rowH;
    if (yy > bottom - 6) return;
    doc.text(r[0], left + 132, yy);
    doc.text(`Rs. ${money(r[1])}`, right - 2, yy, { align: "right" });
  });
  // Total line
  doc.setDrawColor(180); doc.line(left + 131, bottom - 8.5, right - 1, bottom - 8.5); doc.setDrawColor(0);
  doc.setFont("helvetica", "bold"); doc.setFontSize(8);
  doc.text("TOTAL", left + 132, bottom - 5);
  doc.text(`Rs. ${money(s.total_amount)}`, right - 2, bottom - 5, { align: "right" });
}

/** A4 docket with 3 horizontal copies (Sender / Consignee / Office) */
export async function generateAwbDocket(s: any) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const qr = await QRCode.toDataURL(`${window.location.origin}/track?awb=${s.awb_number}`, { margin: 0, width: 220 });
  const copyH = 95; // 3 × 95 = 285 (a4 height = 297)
  const labels = ["SENDER COPY", "CONSIGNEE COPY", "OFFICE COPY"];
  for (let i = 0; i < 3; i++) {
    renderCopy(doc, s, qr, 4 + i * (copyH + 0.5), copyH, labels[i]);
    if (i < 2) {
      // dashed cut line
      doc.setLineDashPattern([1.5, 1.5], 0);
      doc.line(8, 4 + (i + 1) * copyH + 0.25, 202, 4 + (i + 1) * copyH + 0.25);
      doc.setLineDashPattern([], 0);
      doc.setFontSize(5); doc.setTextColor(120);
      doc.text("✂  cut here", 105, 4 + (i + 1) * copyH - 0.5, { align: "center" });
      doc.setTextColor(0);
    }
  }
  doc.save(`Docket-${s.awb_number}.pdf`);
}

/** Standard parcel sticker label 100×150 mm */
export async function generateStickerLabel(s: any) {
  const W = 100, H = 150;
  const doc = new jsPDF({ unit: "mm", format: [W, H] });
  const qr = await QRCode.toDataURL(`${window.location.origin}/track?awb=${s.awb_number}`, { margin: 0, width: 240 });
  doc.setDrawColor(0); doc.setLineWidth(0.6); doc.rect(2, 2, W - 4, H - 4);

  // Header
  try { doc.addImage(logoUrl, "PNG", 4, 4, 18, 12); } catch {}
  doc.setFont("helvetica", "bold"); doc.setTextColor(44, 112, 184); doc.setFontSize(12);
  doc.text(COMPANY.name, 60, 9, { align: "center" });
  doc.setTextColor(0); doc.setFontSize(6); doc.setFont("helvetica", "normal");
  doc.text(`Ph. ${COMPANY.phone} | ${COMPANY.web}`, 60, 13.5, { align: "center" });
  doc.line(2, 18, W - 2, 18);

  // AWB
  doc.setFont("helvetica", "bold"); doc.setFontSize(8);
  doc.text("AWB NUMBER", 4, 24);
  doc.setFontSize(20); doc.text(text(s.awb_number), 4, 33);
  doc.addImage(qr, "PNG", W - 28, 20, 24, 24);
  doc.line(2, 47, W - 2, 47);

  // Mode / Service / Pieces strip
  doc.setFontSize(7); doc.setFont("helvetica", "bold");
  doc.text("MODE", 4, 53); doc.text("SERVICE", 36, 53); doc.text("PIECES", 76, 53);
  doc.setFont("helvetica", "normal");
  doc.text(text(s.transport_mode), 4, 58); doc.text(text(s.service_type), 36, 58); doc.text(`1 of ${text(s.pieces, "1")}`, 76, 58);
  doc.line(2, 62, W - 2, 62);

  // Origin
  doc.setFont("helvetica", "bold"); doc.setFontSize(8); doc.text("FROM", 4, 68);
  doc.setFont("helvetica", "normal"); doc.setFontSize(8);
  doc.text(text(s.sender_name), 4, 73, { maxWidth: 92 });
  doc.text(`${text(s.sender_city)} - ${text(s.sender_pincode)}`, 4, 78, { maxWidth: 92 });
  doc.line(2, 82, W - 2, 82);

  // Destination (large)
  doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.text("TO / DELIVER TO", 4, 88);
  doc.setFontSize(13); doc.text(text(s.receiver_name).toUpperCase(), 4, 96, { maxWidth: 92 });
  doc.setFont("helvetica", "normal"); doc.setFontSize(8);
  doc.text(text(s.receiver_address), 4, 102, { maxWidth: 92 });
  doc.setFont("helvetica", "bold"); doc.setFontSize(16);
  doc.text(`${text(s.receiver_city).toUpperCase()}`, 4, 116, { maxWidth: 92 });
  doc.setFontSize(22);
  doc.text(text(s.receiver_pincode), 4, 128);
  doc.setFontSize(8); doc.setFont("helvetica", "normal");
  doc.text(`${text(s.receiver_state)}${s.receiver_country && s.receiver_country !== "India" ? `, ${s.receiver_country}` : ""}`, 50, 128, { maxWidth: 46 });
  doc.text(`Mob: ${text(s.receiver_phone)}`, 4, 134);
  doc.line(2, 138, W - 2, 138);

  // Footer
  doc.setFont("helvetica", "bold"); doc.setFontSize(7);
  doc.text(`Customer Care: ${COMPANY.phone}  |  ${COMPANY.web}`, 50, 144, { align: "center" });
  doc.setFontSize(6); doc.setFont("helvetica", "italic");
  doc.text(`Booked: ${shortDate(s.booking_date)} • ${text(s.payment_mode).toUpperCase()}`, 50, 147.5, { align: "center" });

  doc.save(`Sticker-${s.awb_number}.pdf`);
}

export const generateAwbLabel = generateAwbDocket;
