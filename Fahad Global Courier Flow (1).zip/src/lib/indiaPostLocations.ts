export type IndiaPostLocation = { pincode: string; city: string; state: string; office?: string };

export const INDIA_POST_LOCATIONS: IndiaPostLocation[] = [
  { pincode: "110001", city: "New Delhi", state: "Delhi", office: "Connaught Place" },
  { pincode: "110020", city: "New Delhi", state: "Delhi", office: "Okhla Industrial Estate" },
  { pincode: "201020", city: "Ghaziabad", state: "Uttar Pradesh", office: "Khora Colony" },
  { pincode: "201301", city: "Noida", state: "Uttar Pradesh", office: "Noida Sector 27" },
  { pincode: "122001", city: "Gurugram", state: "Haryana", office: "Gurgaon" },
  { pincode: "400001", city: "Mumbai", state: "Maharashtra", office: "Fort" },
  { pincode: "400059", city: "Mumbai", state: "Maharashtra", office: "Andheri East" },
  { pincode: "411001", city: "Pune", state: "Maharashtra", office: "Pune H.O" },
  { pincode: "380001", city: "Ahmedabad", state: "Gujarat", office: "Ahmedabad G.P.O" },
  { pincode: "395003", city: "Surat", state: "Gujarat", office: "Surat" },
  { pincode: "560001", city: "Bengaluru", state: "Karnataka", office: "Bangalore G.P.O" },
  { pincode: "500001", city: "Hyderabad", state: "Telangana", office: "Hyderabad G.P.O" },
  { pincode: "600001", city: "Chennai", state: "Tamil Nadu", office: "Chennai G.P.O" },
  { pincode: "700001", city: "Kolkata", state: "West Bengal", office: "Kolkata G.P.O" },
  { pincode: "302001", city: "Jaipur", state: "Rajasthan", office: "Jaipur G.P.O" },
  { pincode: "226001", city: "Lucknow", state: "Uttar Pradesh", office: "Lucknow G.P.O" },
  { pincode: "800001", city: "Patna", state: "Bihar", office: "Patna G.P.O" },
  { pincode: "751001", city: "Bhubaneswar", state: "Odisha", office: "Bhubaneswar G.P.O" },
  { pincode: "781001", city: "Guwahati", state: "Assam", office: "Guwahati G.P.O" },
  { pincode: "682001", city: "Kochi", state: "Kerala", office: "Cochin" },
];

export async function lookupIndiaPostPincode(pin: string): Promise<IndiaPostLocation | null> {
  const local = INDIA_POST_LOCATIONS.find((x) => x.pincode === pin);
  if (local) return local;
  try {
    const r = await fetch(`https://api.postalpincode.in/pincode/${pin}`);
    const j = await r.json();
    const po = j?.[0]?.PostOffice?.[0];
    if (!po) return null;
    return { pincode: pin, city: po.District || po.Block || po.Name || "", state: po.State || "", office: po.Name || "" };
  } catch {
    return null;
  }
}