// Client Rate Master — per-customer quotation engine.
// Stores a normalized rate card per client (in client_rate_master.data jsonb)
// and computes billing with strict destination-city matching + REST OF INDIA fallback.

import { supabase } from "@/integrations/supabase/client";

export type ServiceKind = "AIR" | "SURFACE" | "SAMEDAY" | "OVERNIGHT" | "LOCAL";

export interface SlabRate { uptoKg: number; perKg?: number; flat?: number; addPerKg?: number; addBase?: number; }

export interface SurfaceZone { zone: string; rate: number; cities: string[]; states?: string[]; tat?: string; }

export interface ClientRateCard {
  version: 1;
  fuelPct: number;        // e.g. 40
  gstPct: number;         // 18
  fovPctOfDV: number;     // 0.2 → 0.2%
  fovMin: number;         // 100
  insurancePctOfDV: number; // 2 → 2%
  insuranceMin: number;   // 200
  odaPerKg: number;       // 3
  odaMin: number;         // 750
  air: {
    minWeight: number;            // 5
    divisor: number;              // 5000
    cities: Record<string, number>; // lowercased city → ₹/kg
    restOfIndia: number;          // 140
  };
  surface: {
    minWeight: number;            // 20
    divisor: number;              // 4000
    zones: SurfaceZone[];         // North/East/West/South/Central/NE
    restOfIndia: number;          // 50
  };
  sameday: { minWeight: number; slabs: SlabRate[]; };
  overnight: { minWeight: number; slabs: SlabRate[]; };
  local: {
    minWeight: number;            // 0.5
    cities: Record<string, number>; // delhi/noida/...
    restOfIndia?: number;
    priorityMultiplier?: number;  // for same-day local
  };
  airlineDirect?: { perConsignment: number; metroCodes: string[] };
  notes?: string;
}

// Default rate card derived from the Fahad Global B2B quotation
export const DEFAULT_CARD: ClientRateCard = {
  version: 1,
  fuelPct: 40,
  gstPct: 18,
  fovPctOfDV: 0.2,
  fovMin: 100,
  insurancePctOfDV: 2,
  insuranceMin: 200,
  odaPerKg: 3,
  odaMin: 750,
  air: {
    minWeight: 5,
    divisor: 5000,
    cities: {
      mumbai: 90, ahmedabad: 90, bangalore: 95, bengaluru: 95, hyderabad: 95,
      pune: 95, kolkata: 95, chennai: 95, bhubaneswar: 100, patna: 110,
      nagpur: 110, guwahati: 130, goa: 130, cochin: 110, kochi: 110, ranchi: 130,
    },
    restOfIndia: 140,
  },
  surface: {
    minWeight: 20,
    divisor: 4000,
    zones: [
      { zone: "NORTH", rate: 30, tat: "2 Days", cities: ["lucknow","kanpur","varanasi","dehradun","rudrapur","ludhiana","zirakpur","panchkula","mohali","karnal","jalandhar","amritsar","patiala","jaipur","delhi","noida","gurgaon","gurugram","faridabad","ghaziabad","chandigarh"], states: ["delhi","haryana","himachal pradesh","jammu and kashmir","punjab","rajasthan","uttar pradesh","uttarakhand","chandigarh"] },
      { zone: "EAST", rate: 40, tat: "4-5 Days", cities: ["kolkata","ranchi","bhubaneswar","patna","cuttack","ahmedabad"], states: ["bihar","jharkhand","west bengal","odisha"] },
      { zone: "WEST", rate: 40, tat: "4-5 Days", cities: ["vapi","surat","mumbai","pune","bhiwandi","hyderabad","thane","navi mumbai","pimpri","chinchwad"], states: ["maharashtra","gujarat","goa"] },
      { zone: "SOUTH", rate: 45, tat: "4-5 Days", cities: ["chennai","ernakulam","cochin","kochi","kozhikode","secunderabad","visakhapatnam","bangalore","bengaluru"], states: ["andhra pradesh","karnataka","kerala","puducherry","tamil nadu","telangana"] },
      { zone: "CENTRAL", rate: 45, tat: "4-5 Days", cities: ["indore","bhopal","raipur","nagpur"], states: ["madhya pradesh","chhattisgarh"] },
      { zone: "NORTH EAST", rate: 45, tat: "5-6 Days", cities: ["guwahati","imphal","kohima","shillong","itanagar","aizawl","agartala"], states: ["assam","manipur","meghalaya","mizoram","nagaland","tripura","arunachal pradesh","sikkim"] },
    ],
    restOfIndia: 50,
  },
  sameday: {
    minWeight: 5,
    slabs: [
      { uptoKg: 5,  flat: 4500, addBase: 0, addPerKg: 0 },
      { uptoKg: 15, flat: 4500, addPerKg: 330 }, // illustrative; admin can edit
      { uptoKg: 30, perKg: 250 },
      { uptoKg: 50, perKg: 250 },
      { uptoKg: 9999, perKg: 200 },
    ],
  },
  overnight: {
    minWeight: 5,
    slabs: [
      { uptoKg: 5,  flat: 3500 },
      { uptoKg: 15, flat: 3500, addPerKg: 290 },
      { uptoKg: 30, perKg: 250 },
      { uptoKg: 50, perKg: 200 },
      { uptoKg: 9999, perKg: 150 },
    ],
  },
  local: {
    minWeight: 0.5,
    cities: { delhi: 50, noida: 60, faridabad: 60, gurgaon: 60, gurugram: 60, ghaziabad: 60 },
    priorityMultiplier: 4, // 50→200, 60→250 in source quotation
  },
  airlineDirect: { perConsignment: 2500, metroCodes: ["BOM","BLR","DEL","PNQ","AMD","HYD","MAA","JAI","CCU"] },
};

const norm = (s?: string) => (s || "").toLowerCase().trim().replace(/\s+/g, " ");

function mergeCard(raw: any): ClientRateCard {
  const r = raw && typeof raw === "object" ? raw : {};
  return {
    ...DEFAULT_CARD,
    ...r,
    air: { ...DEFAULT_CARD.air, ...(r.air || {}), cities: { ...DEFAULT_CARD.air.cities, ...(r.air?.cities || {}) } },
    surface: { ...DEFAULT_CARD.surface, ...(r.surface || {}), zones: r.surface?.zones || DEFAULT_CARD.surface.zones },
    sameday: { ...DEFAULT_CARD.sameday, ...(r.sameday || {}), slabs: r.sameday?.slabs || DEFAULT_CARD.sameday.slabs },
    overnight: { ...DEFAULT_CARD.overnight, ...(r.overnight || {}), slabs: r.overnight?.slabs || DEFAULT_CARD.overnight.slabs },
    local: { ...DEFAULT_CARD.local, ...(r.local || {}), cities: { ...DEFAULT_CARD.local.cities, ...(r.local?.cities || {}) } },
  } as ClientRateCard;
}

export function detectService(label: string): ServiceKind {
  const s = norm(label);
  if (s.includes("local")) return "LOCAL";
  if (s.includes("same")) return "SAMEDAY";
  // "Overnight" only — "Next Business Day" and "Standard Air" both fall through to AIR
  if (s.includes("overnight")) return "OVERNIGHT";
  if (s.includes("surface") || s.includes("road") || s.includes("train")) return "SURFACE";
  return "AIR";
}

export interface ComputeInput {
  service: ServiceKind;
  city: string;
  state?: string;
  actualWeight: number;
  lengthCm: number; widthCm: number; heightCm: number;
  declaredValue: number;
  fovApplied?: boolean;       // optional toggle (default true)
  insuranceApplied?: boolean; // optional toggle (default false)
  odaApplied?: boolean;
  otherCharges?: number;
  rateOverride?: number;
  fuelPctOverride?: number;
  gstPctOverride?: number;
}

export interface ComputeOutput {
  volumetricWeight: number;
  billableWeight: number;
  rate: number;
  zone: string;
  matched: "city" | "zone" | "rest-of-india";
  freight: number;
  fov: number;
  insurance: number;
  oda: number;
  other: number;
  total: number;
  fuelPct: number;
  fuel: number;
  subTotal: number;
  gstPct: number;
  gst: number;
  grandTotal: number;
}

function slabFreight(slabs: SlabRate[], w: number): number {
  for (const s of slabs) {
    if (w <= s.uptoKg) {
      let amt = s.flat ?? 0;
      if (s.addPerKg) amt += s.addPerKg * w;
      if (s.perKg) amt = s.perKg * w;
      return amt;
    }
  }
  return 0;
}

export function computeBilling(card: ClientRateCard, i: ComputeInput): ComputeOutput {
  const c = norm(i.city);
  const st = norm(i.state);
  const divisor = i.service === "SURFACE" ? card.surface.divisor : (card.air.divisor || 5000);
  const vol = +(((i.lengthCm * i.widthCm * i.heightCm) / divisor) || 0).toFixed(3);
  let bill = Math.max(Number(i.actualWeight || 0), vol);

  let rate = i.rateOverride && i.rateOverride > 0 ? i.rateOverride : 0;
  let zone = "";
  let matched: ComputeOutput["matched"] = "rest-of-india";
  let freight = 0;

  switch (i.service) {
    case "AIR": {
      bill = Math.max(bill, card.air.minWeight);
      if (!rate) {
        if (card.air.cities[c] != null) { rate = card.air.cities[c]; zone = c.toUpperCase(); matched = "city"; }
        else { rate = card.air.restOfIndia; zone = "REST OF INDIA"; matched = "rest-of-india"; }
      } else { zone = c.toUpperCase() || "MANUAL"; matched = "city"; }
      freight = bill * rate;
      break;
    }
    case "SURFACE": {
      bill = Math.max(bill, card.surface.minWeight);
      const found = card.surface.zones.find(z =>
        z.cities.map(norm).includes(c) || (st && (z.states || []).map(norm).includes(st))
      );
      if (found) { rate = rate || found.rate; zone = found.zone; matched = "zone"; }
      else { rate = rate || card.surface.restOfIndia; zone = "REST OF INDIA"; matched = "rest-of-india"; }
      freight = bill * rate;
      break;
    }
    case "SAMEDAY": {
      bill = Math.max(bill, card.sameday.minWeight);
      zone = "SAMEDAY"; matched = "city";
      freight = slabFreight(card.sameday.slabs, bill);
      rate = bill ? +(freight / bill).toFixed(2) : 0;
      break;
    }
    case "OVERNIGHT": {
      bill = Math.max(bill, card.overnight.minWeight);
      zone = "OVERNIGHT"; matched = "city";
      freight = slabFreight(card.overnight.slabs, bill);
      rate = bill ? +(freight / bill).toFixed(2) : 0;
      break;
    }
    case "LOCAL": {
      bill = Math.max(bill, card.local.minWeight);
      if (!rate) {
        if (card.local.cities[c] != null) { rate = card.local.cities[c]; zone = c.toUpperCase(); matched = "city"; }
        else { rate = card.local.restOfIndia ?? 80; zone = "REST OF INDIA"; matched = "rest-of-india"; }
      }
      freight = bill * rate;
      break;
    }
  }

  const dv = Number(i.declaredValue || 0);
  const fov = i.fovApplied === false ? 0 : Math.max(dv * (card.fovPctOfDV / 100), card.fovMin);
  const insurance = i.insuranceApplied ? Math.max(dv * (card.insurancePctOfDV / 100), card.insuranceMin) : 0;
  const oda = i.odaApplied ? Math.max(bill * card.odaPerKg, card.odaMin) : 0;
  const other = Number(i.otherCharges || 0);
  const total = freight + fov + insurance + oda + other;
  const fuelPct = i.fuelPctOverride ?? card.fuelPct;
  const fuel = total * (fuelPct / 100);
  const subTotal = total + fuel;
  const gstPct = i.gstPctOverride ?? card.gstPct;
  const gst = subTotal * (gstPct / 100);
  const grandTotal = subTotal + gst;

  return {
    volumetricWeight: vol,
    billableWeight: +bill.toFixed(3),
    rate: +rate.toFixed(2),
    zone, matched,
    freight: +freight.toFixed(2),
    fov: +fov.toFixed(2),
    insurance: +insurance.toFixed(2),
    oda: +oda.toFixed(2),
    other: +other.toFixed(2),
    total: +total.toFixed(2),
    fuelPct, fuel: +fuel.toFixed(2),
    subTotal: +subTotal.toFixed(2),
    gstPct, gst: +gst.toFixed(2),
    grandTotal: +grandTotal.toFixed(2),
  };
}

export async function loadClientCard(clientId: string): Promise<ClientRateCard> {
  if (!clientId) return DEFAULT_CARD;
  const { data } = await (supabase as any)
    .from("client_rate_master").select("data").eq("client_id", clientId).maybeSingle();
  if (data?.data && typeof data.data === "object" && (data.data as any).version) {
    return mergeCard(data.data);
  }
  return DEFAULT_CARD;
}

export async function loadClientQuotationUrl(clientId: string): Promise<string | null> {
  if (!clientId) return null;
  const { data } = await (supabase as any)
    .from("client_rate_master").select("quotation_url").eq("client_id", clientId).maybeSingle();
  return data?.quotation_url ?? null;
}

export async function deleteClientQuotation(clientId: string, path: string) {
  if (path) await (supabase as any).storage.from("rate-agreements").remove([path]).catch(() => {});
  return (supabase as any).from("client_rate_master")
    .update({ quotation_url: null, updated_at: new Date().toISOString() })
    .eq("client_id", clientId);
}

export async function getQuotationPublicUrl(path: string): Promise<string> {
  // bucket is private — return signed URL valid 1h
  const { data } = await (supabase as any).storage.from("rate-agreements").createSignedUrl(path, 3600);
  return data?.signedUrl || "";
}

export async function saveClientCard(clientId: string, card: ClientRateCard, quotation_url?: string) {
  const { data: { user } } = await supabase.auth.getUser();
  const payload: any = {
    client_id: clientId, data: mergeCard(card) as any, updated_by: user?.id, updated_at: new Date().toISOString(),
  };
  if (quotation_url !== undefined) payload.quotation_url = quotation_url;
  return (supabase as any).from("client_rate_master").upsert(payload, { onConflict: "client_id" });
}