import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import logoUrl from "@/assets/logo.png";
import { COMPANY } from "./awbLabel";
import { inrInWords } from "./numberToWords";

const BLUE: [number, number, number] = [44, 112, 184];
const LIGHT: [number, number, number] = [232, 241, 250];
const LINE: [number, number, number] = [20, 20, 20];
const hexRgb = (hex?: string, fallback: [number, number, number] = BLUE): [number, number, number] => {
  const m = String(hex || "").replace("#", "").match(/^([0-9a-f]{6})$/i);
  return m ? [parseInt(m[1].slice(0, 2), 16), parseInt(m[1].slice(2, 4), 16), parseInt(m[1].slice(4, 6), 16)] : fallback;
};

const money = (v: any) => Number(v || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const text = (v: any, fallback: any = "-") => (v === null || v === undefined || v === "" ? String(fallback) : String(v));
const shortDate = (v: any) => (v ? new Date(v).toLocaleDateString("en-GB") : "-");

function boxedCompanyHeader(doc: jsPDF, title: string, settings?: any) {
  const primary = hexRgb(settings?.primary_color, [11, 30, 91]);
  const accent = hexRgb(settings?.accent_color, [212, 175, 55]);
  doc.setDrawColor(...LINE);
  doc.setLineWidth(0.45);
  doc.rect(12, 10, 186, 31);
  doc.setFillColor(...accent); doc.rect(12, 10, 186, 2.2, "F");
  try { doc.addImage(logoUrl, "PNG", 16, 13, 28, 18); } catch {}
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...primary);
  doc.setFontSize(16);
  doc.text(text(settings?.company_name, COMPANY.name), 105, 18, { align: "center" });
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(8.2);
  doc.text(text(settings?.address, COMPANY.ho).toUpperCase(), 105, 25, { align: "center", maxWidth: 138 });
  doc.setFontSize(8.5);
  doc.text(`Ph. ${text(settings?.phone, COMPANY.phone)} | ${text(settings?.email, COMPANY.email)} | ${text(settings?.web, COMPANY.web)}`, 105, 35, { align: "center", maxWidth: 146 });
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text(title, 105, 48, { align: "center" });
  doc.setLineWidth(0.35);
  doc.line(12, 50, 198, 50);
}

function plainHeader(doc: jsPDF, title: string, sub?: string) {
  boxedCompanyHeader(doc, title);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  if (sub) doc.text(sub, 12, 53);
  doc.text(`Printed: ${new Date().toLocaleString()}`, 198, 53, { align: "right" });
}

function footer(doc: jsPDF) {
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setDrawColor(120, 120, 120);
    doc.line(12, 286, 198, 286);
    doc.setFontSize(7);
    doc.setFont("helvetica", "italic");
    doc.text(`${COMPANY.web} | ${COMPANY.email} | ${COMPANY.phone}`, 105, 291, { align: "center" });
    doc.text(`Page ${i} of ${pages}`, 198, 291, { align: "right" });
  }
}

export function printManifest(m: any, items: any[]) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  plainHeader(doc, `${text(m.manifest_type).toUpperCase()} MANIFEST`, `Manifest No: ${text(m.manifest_no)} | Date: ${shortDate(m.manifest_date)} | Route: ${text(m.origin)} to ${text(m.destination)}`);
  autoTable(doc, {
    startY: 60,
    head: [["S/N", "AWB", "Receiver", "Address", "City", "Pin", "Pcs", "Wt"]],
    body: items.map((s, i) => [i + 1, text(s.awb_number), text(s.receiver_name), text(s.receiver_address, "").slice(0, 42), text(s.receiver_city), text(s.receiver_pincode), text(s.pieces, "1"), text(s.chargeable_weight, "0")]),
    styles: { fontSize: 7.5, lineColor: LINE, lineWidth: 0.15, cellPadding: 1.4, valign: "middle" },
    headStyles: { fillColor: BLUE, textColor: [255, 255, 255], halign: "center", fontStyle: "bold" },
    columnStyles: { 0: { halign: "center", cellWidth: 10 }, 1: { cellWidth: 26 }, 2: { cellWidth: 30 }, 3: { cellWidth: 48 }, 6: { halign: "center" }, 7: { halign: "right" } },
    margin: { left: 12, right: 12 },
  });
  const y = Math.min(((doc as any).lastAutoTable.finalY || 70) + 7, 255);
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.text(`Total Pieces: ${text(m.total_pieces, String(items.length))}    Total Weight: ${money(m.total_weight)} kg`, 12, y);
  doc.setFont("helvetica", "normal");
  doc.text(`Vehicle: ${text(m.vehicle_no)}    Driver: ${text(m.driver_name)}    Phone: ${text(m.driver_phone)}`, 12, y + 7);
  doc.text("Dispatch Staff Signature: ____________________", 12, y + 22);
  doc.text("Receiving Branch Signature: ____________________", 112, y + 22);
  footer(doc);
  doc.save(`Manifest-${m.manifest_no}.pdf`);
}

export function printDRS(d: any, items: any[]) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  plainHeader(doc, "DELIVERY RUN SHEET (DRS)", `DRS No: ${text(d.drs_no)} | Date: ${shortDate(d.drs_date)} | Delivery Boy: ${text(d.delivery_boy)} | Area: ${text(d.area)}`);
  autoTable(doc, {
    startY: 60,
    head: [["S/N", "AWB", "Receiver", "Full Address", "City / Pin", "Pcs", "Receiver Sign / Remarks"]],
    body: items.map((s, i) => [i + 1, text(s.awb_number), text(s.receiver_name), text(s.receiver_address), `${text(s.receiver_city)} - ${text(s.receiver_pincode)}`, text(s.pieces, "1"), ""]),
    styles: { fontSize: 7.4, lineColor: LINE, lineWidth: 0.15, cellPadding: 1.4, minCellHeight: 13, valign: "middle" },
    headStyles: { fillColor: BLUE, textColor: [255, 255, 255], halign: "center", fontStyle: "bold" },
    columnStyles: { 0: { halign: "center", cellWidth: 10 }, 1: { cellWidth: 24 }, 2: { cellWidth: 30 }, 3: { cellWidth: 58 }, 4: { cellWidth: 25 }, 5: { halign: "center", cellWidth: 12 }, 6: { cellWidth: 27 } },
    margin: { left: 12, right: 12 },
  });
  const y = Math.min(((doc as any).lastAutoTable.finalY || 70) + 10, 260);
  doc.setFontSize(9);
  doc.text(`Phone: ${text(d.delivery_boy_phone)}   Remarks: ${text(d.remarks)}`, 12, y);
  doc.text("Delivery Boy Signature: ____________________", 12, y + 14);
  doc.text("Supervisor Signature: ____________________", 120, y + 14);
  footer(doc);
  doc.save(`DRS-${d.drs_no}.pdf`);
}

export function printInvoice(inv: any, client: any, items: any[]) {
  return printInvoiceDetailed(inv, client, items);
}

export function printInvoiceDetailed(inv: any, client: any, items: any[], settings?: any) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const s = settings || {};
  const primary = hexRgb(s.primary_color, [11, 30, 91]);
  const accent = hexRgb(s.accent_color, [212, 175, 55]);
  const baseFont = Number(s.font_size || 8);
  boxedCompanyHeader(doc, "TAX INVOICE", s);

  // Strip with state / GSTIN / PAN — placed below title, never crashes into logo
  doc.setFontSize(baseFont);
  doc.setFont("helvetica", "bold");
  doc.setFillColor(...LIGHT);
  doc.rect(12, 49, 186, 4.6, "F");
  doc.setTextColor(0);
  doc.text(`State : ${text(s.state, "UTTAR PRADESH")}  (${text(s.state_code, "09")})`, 14, 52.2);
  doc.text(`GSTIN : ${text(s.gstin, COMPANY.gstin)}`, 96, 52.2);
  doc.text(`PAN : ${text(s.pan, "AEXPF5632E")}`, 158, 52.2);

  doc.setDrawColor(...LINE);
  doc.setLineWidth(0.35);
  doc.rect(12, 56, 89, 40);
  doc.rect(109, 56, 89, 40);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text("Bill To,", 15, 61);
  doc.setFontSize(baseFont + 1.5);
  const nameLines = doc.splitTextToSize(text(client?.name).toUpperCase(), 84) as string[];
  doc.text(nameLines.slice(0, 2), 15, 66);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(baseFont);
  const addrLines = doc.splitTextToSize(text(client?.address), 84) as string[];
  let aY = 66 + nameLines.slice(0, 2).length * 4.2;
  addrLines.slice(0, 5).forEach((ln) => { doc.text(ln, 15, aY); aY += 3.8; });
  aY = Math.max(aY, 84);
  doc.text(`City: ${text(client?.city)}   State: ${text(client?.state)}`, 15, aY); aY += 3.6;
  doc.text(`GSTIN: ${text(client?.gstin)}   PAN: ${text(client?.pan)}`, 15, aY, { maxWidth: 84 });

  const rightRows = [
    ["Customer Code", text(client?.client_code)],
    ["Invoice Number", text(inv.invoice_no)],
    ["Invoice Date", shortDate(inv.invoice_date)],
    ["Period From", `${shortDate(inv.period_from)} To ${shortDate(inv.period_to)}`],
    ["No of Pages", "1"],
    ["Due Days", text(inv.due_days, "05 Days")],
  ];
  doc.setFont("helvetica", "bold"); doc.setFontSize(8);
  doc.text("Invoice Details", 112, 61);
  doc.setFontSize(7.2);
  rightRows.forEach((r, i) => {
    doc.setFont("helvetica", "normal"); doc.text(r[0], 112, 66 + i * 4);
    doc.setFont("helvetica", "bold"); doc.text(":", 142, 66 + i * 4);
    doc.text(text(r[1]), 145, 66 + i * 4, { maxWidth: 50 });
  });

  const rows = items.map((it, i) => {
    const s = it.shipments || it;
    const amount = Number(it.amount ?? s.total_amount ?? 0);
    const gst = Number(s.gst ?? 0);
    const freight = Math.max(0, amount - gst);
    return [
      i + 1,
      shortDate(s.booking_date || it.booking_date),
      text(s.awb_number || it.awb_number),
      text(s.sender_city || it.origin || "New Delhi"),
      text(s.receiver_city || it.destination),
      text(s.chargeable_weight || it.chargeable_weight || 0),
      text(s.transport_mode || "SELF"),
      text(s.service_type || "Courier"),
      text(s.contents || "Non Docs"),
      money(freight),
      money(Number(s.other_charges || 0)),
      money(gst),
      money(amount),
    ];
  });
  autoTable(doc, {
    startY: 94,
    head: [["S/N", "BKG DATE", "C. NO", "ORIGIN", "DESTINATION", "CHRG WT(KG)", "CARRIER", "SERVICES", "PKG-TYP", "FRT", "FOV+OTH", "GST", "AMOUNT"]],
    body: rows,
    styles: { fontSize: 6.4, lineColor: LINE, lineWidth: 0.16, cellPadding: 1.1, halign: "center", valign: "middle" },
    headStyles: { fillColor: primary, textColor: [255, 255, 255], fontStyle: "bold", lineColor: LINE, lineWidth: 0.2, fontSize: 6.8 },
    foot: [["", "", "", "", "", "", "", "", "Total", money(inv.subtotal), money(items.reduce((a, it) => a + Number((it.shipments || it).other_charges || 0), 0)), money(inv.gst), money(inv.total)]],
    footStyles: { fillColor: LIGHT, textColor: [0, 0, 0], fontStyle: "bold", lineColor: LINE, lineWidth: 0.2 },
    columnStyles: { 9: { halign: "right" }, 10: { halign: "right" }, 11: { halign: "right" }, 12: { halign: "right" } },
    margin: { left: 12, right: 12 },
  });

  const fy = ((doc as any).lastAutoTable.finalY || 130) + 4;
  // Two-column footer: left = SAC + amount in words, right = totals box
  doc.setDrawColor(...LINE);
  doc.setLineWidth(0.3);
  doc.rect(12, fy, 100, 32);
  doc.rect(112, fy, 86, 32);
  doc.setFontSize(8); doc.setFont("helvetica", "bold");
  doc.text(`HSN/SAC : ${text(s.sac, "996812")}`, 15, fy + 6);
  doc.setFont("helvetica", "normal"); doc.setFontSize(7.5);
  doc.text(`Amount in Words:`, 15, fy + 13);
  doc.setFont("helvetica", "bold"); doc.setFontSize(7.4);
  const words = (inv.amount_words || inrInWords(inv.total)).toUpperCase();
  const wLines = doc.splitTextToSize(words, 94) as string[];
  let wY = fy + 18;
  wLines.slice(0, 3).forEach((ln) => { doc.text(ln, 15, wY); wY += 3.6; });

  doc.setFont("helvetica", "bold");
  const intra = !!s.intra_state;
  const cgst = intra ? Number(inv.gst || 0) / 2 : 0;
  const sgst = intra ? Number(inv.gst || 0) / 2 : 0;
  const totalRows: any[] = [["Sub Total", inv.subtotal]];
  if (intra) {
    totalRows.push([`CGST @ of ${text(s.cgst_pct, 9)}%`, cgst]);
    totalRows.push([`SGST @ of ${text(s.sgst_pct, 9)}%`, sgst]);
  } else {
    totalRows.push([`IGST @ ${text(s.igst_pct, 18)}%`, inv.gst]);
  }
  totalRows.push(["Grand Total (Rounded)", Math.round(Number(inv.total || 0))]);
  doc.setFontSize(7.6);
  totalRows.forEach((r, i) => {
    const yy = fy + 6 + i * 5;
    doc.text(String(r[0]), 115, yy);
    doc.text(`Rs. ${money(r[1])}`, 196, yy, { align: "right" });
  });
  // Highlight Grand Total
  const gtY = fy + 6 + (totalRows.length - 1) * 5;
  doc.setFillColor(...accent);
  doc.rect(112, gtY - 3.8, 86, 5.8, "F");
  doc.setTextColor(255); doc.setFontSize(8.6); doc.setFont("helvetica", "bold");
  doc.text(String(totalRows[totalRows.length - 1][0]), 115, gtY);
  doc.text(`Rs. ${money(totalRows[totalRows.length - 1][1])}`, 196, gtY, { align: "right" });
  doc.setTextColor(0);

  // Bank details + Terms wrapped block
  const by0 = fy + 36;
  const bH = 46;
  doc.setDrawColor(...LINE); doc.rect(12, by0, 100, bH); doc.rect(112, by0, 86, bH);
  doc.setFont("helvetica", "bold"); doc.setFontSize(8.5); doc.setTextColor(...BLUE);
  doc.text("Bank Details", 15, by0 + 5);
  doc.setTextColor(0); doc.setFont("helvetica", "normal"); doc.setFontSize(7.5);
  let by = by0 + 10;
  doc.text(`Bank   : ${text(s.bank_name)}`, 15, by, { maxWidth: 92 }); by += 4.5;
  doc.text(`A/c No : ${text(s.bank_account)}`, 15, by, { maxWidth: 92 }); by += 4.5;
  doc.text(`Branch : ${text(s.bank_branch)}`, 15, by, { maxWidth: 92 }); by += 4.5;
  doc.text(`IFSC   : ${text(s.bank_ifsc)}`, 15, by, { maxWidth: 92 }); by += 4.5;
  if (s.swift_code) { doc.text(`SWIFT  : ${s.swift_code}`, 15, by, { maxWidth: 92 }); by += 4.5; }
  doc.text(`PAN    : ${text(s.pan)}`, 15, by); by += 4.5;
  doc.text(`GSTIN  : ${text(s.gstin)}`, 15, by, { maxWidth: 92 });

  doc.setFont("helvetica", "bold"); doc.setFontSize(8.5); doc.setTextColor(...BLUE);
  doc.text("Terms & Conditions", 115, by0 + 5);
  doc.setTextColor(0); doc.setFont("helvetica", "normal"); doc.setFontSize(6.6);
  const notes: string[] = (s.terms && Array.isArray(s.terms) && s.terms.length) ? s.terms : [
    "SELF=Self, DHL=DHL, FDX=FEDEX, ARX=ARAMEX, FE=Front End.",
    "Payment Terms: Payment to be made to the cashier & official receipt must be obtained.",
    "Cheque / Demand Draft must be crossed A/C Payee only drawn in favour of FAHAD GLOBAL LOGISTICS.",
    "This is a computer generated statement. No signature required.",
  ];
  let ny = by0 + 10;
  notes.slice(0, 7).forEach((n, i) => {
    const lns = doc.splitTextToSize(`${i + 1}. ${n}`, 82) as string[];
    lns.forEach((ln) => { doc.text(ln, 115, ny); ny += 3.2; });
    ny += 0.6;
  });

  // Signature
  const sigY = by0 + bH + 4;
  doc.setFont("helvetica", "bold"); doc.setFontSize(8);
  doc.text(`for ${text(s.company_name, COMPANY.name)}`, 196, sigY, { align: "right" });
  doc.setFont("helvetica", "normal"); doc.text("Authorised Signatory", 196, sigY + 12, { align: "right" });

  footer(doc);
  doc.save(`Invoice-${inv.invoice_no}.pdf`);
}

/** Tally-style summary invoice (Buyer / Consignee blocks + single freight line + tax breakdown). */
export function printInvoiceSummary(inv: any, client: any, items: any[], settings?: any) {
  const s = settings || {};
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  // Top banner
  doc.setDrawColor(...LINE); doc.setLineWidth(0.4);
  doc.rect(10, 10, 190, 14);
  doc.setFont("helvetica", "bold"); doc.setFontSize(13);
  doc.text("Tax Invoice", 105, 19, { align: "center" });

  // Company block (top-left)
  doc.rect(10, 24, 110, 36);
  doc.setFontSize(11); doc.setFont("helvetica", "bold");
  doc.text(text(s.company_name, COMPANY.name), 12, 30);
  doc.setFont("helvetica", "normal"); doc.setFontSize(7.5);
  doc.text(text(s.address, COMPANY.ho), 12, 35, { maxWidth: 106 });
  let yy = 44;
  if (s.udyam) { doc.text(`UDYAM : ${s.udyam}`, 12, yy); yy += 4; }
  doc.text(`GSTIN/UIN : ${text(s.gstin)}`, 12, yy); yy += 4;
  doc.text(`State Name : ${text(s.state)}, Code : ${text(s.state_code)}`, 12, yy); yy += 4;
  doc.text(`Contact : ${text(s.phone)}   E-Mail : ${text(s.email)}`, 12, yy);

  // Invoice meta block (top-right)
  doc.rect(120, 24, 80, 36);
  doc.setFontSize(8);
  doc.setFont("helvetica", "normal"); doc.text("Invoice No.", 122, 30);
  doc.text("Dated", 162, 30);
  doc.setFont("helvetica", "bold");
  doc.text(text(inv.invoice_no), 122, 35);
  doc.text(shortDate(inv.invoice_date), 162, 35);
  doc.setFont("helvetica", "normal");
  doc.text("Reference No.", 122, 44); doc.text("Other References", 162, 44);
  doc.setFont("helvetica", "bold");
  doc.text(text(inv.invoice_no), 122, 49);
  doc.setFont("helvetica", "normal");
  doc.text("Terms of Payment", 122, 56);
  doc.setFont("helvetica", "bold"); doc.text(text(s.due_days, "10 Days"), 162, 56);

  // Consignee + Buyer (two boxes)
  doc.rect(10, 60, 95, 36);
  doc.rect(105, 60, 95, 36);
  doc.setFontSize(8); doc.setFont("helvetica", "bold");
  doc.text("Consignee (Ship to)", 12, 65);
  doc.text("Buyer (Bill to)", 107, 65);
  doc.setFontSize(9);
  doc.text(text(client?.name).toUpperCase(), 12, 71, { maxWidth: 91 });
  doc.text(text(client?.name).toUpperCase(), 107, 71, { maxWidth: 91 });
  doc.setFont("helvetica", "normal"); doc.setFontSize(7.5);
  doc.text(text(client?.address), 12, 77, { maxWidth: 91 });
  doc.text(text(client?.address), 107, 77, { maxWidth: 91 });
  doc.text(`GSTIN/UIN : ${text(client?.gstin)}`, 12, 90);
  doc.text(`GSTIN/UIN : ${text(client?.gstin)}`, 107, 90);
  doc.text(`State : ${text(client?.state)}`, 12, 94);
  doc.text(`State : ${text(client?.state)}`, 107, 94);

  // Particulars table (single summary line)
  const subtotal = Number(inv.subtotal || 0);
  const intra = !!s.intra_state;
  const totalGst = Number(inv.gst || 0);
  const cgst = intra ? totalGst / 2 : 0;
  const sgst = intra ? totalGst / 2 : 0;
  const igst = intra ? 0 : totalGst;
  const grand = Number(inv.total || subtotal + totalGst);
  const roundOff = +(grand - (subtotal + totalGst)).toFixed(2);

  const body: any[] = [[1, "Freight Charges", text(s.sac, "996812"), `${text(s.gst_pct, 18)} %`, "", "", "", money(subtotal)]];
  if (intra) {
    body.push(["", `CGST @ ${text(s.cgst_pct, 9)}%`, "", "", "", "", "", money(cgst)]);
    body.push(["", `SGST @ ${text(s.sgst_pct, 9)}%`, "", "", "", "", "", money(sgst)]);
  } else {
    body.push(["", `IGST @ ${text(s.igst_pct, 18)}%`, "", "", "", "", "", money(igst)]);
  }
  if (Math.abs(roundOff) >= 0.01) body.push(["", "Round Off", "", "", "", "", "", money(roundOff)]);

  autoTable(doc, {
    startY: 100,
    head: [["Sl No.", "Particulars", "HSN/SAC", "GST Rate", "Quantity", "Rate", "per", "Amount"]],
    body,
    foot: [["", "Total", "", "", "", "", "", `INR ${money(grand)}`]],
    styles: { fontSize: 8, lineColor: LINE, lineWidth: 0.2, cellPadding: 1.6, halign: "center" },
    headStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: "bold", lineColor: LINE, lineWidth: 0.2 },
    footStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: "bold", lineColor: LINE, lineWidth: 0.2, halign: "right" },
    columnStyles: { 1: { halign: "left", cellWidth: 60 }, 7: { halign: "right" } },
    margin: { left: 10, right: 10 },
  });

  let y = ((doc as any).lastAutoTable.finalY || 150) + 4;
  doc.setFontSize(8); doc.setFont("helvetica", "italic");
  doc.text("Amount Chargeable (in words)                                                            E. & O.E", 12, y);
  y += 5;
  doc.setFont("helvetica", "bold");
  const sumWords = inv.amount_words || inrInWords(inv.total);
  doc.splitTextToSize(`INR ${sumWords}`, 188).forEach((ln: string, i: number) => { doc.text(ln, 12, y + i * 4); });
  y += Math.max(5, (doc.splitTextToSize(`INR ${sumWords}`, 188) as string[]).length * 4);
  y += 5;

  // Tax breakup block
  autoTable(doc, {
    startY: y + 2,
    head: [["Taxable Value", "CGST Rate", "CGST Amount", "SGST/UTGST Rate", "SGST Amount", "IGST Rate", "IGST Amount", "Total Tax"]],
    body: [[money(subtotal), intra ? `${text(s.cgst_pct, 9)}%` : "-", intra ? money(cgst) : "-", intra ? `${text(s.sgst_pct, 9)}%` : "-", intra ? money(sgst) : "-", intra ? "-" : `${text(s.igst_pct, 18)}%`, intra ? "-" : money(igst), money(totalGst)]],
    styles: { fontSize: 7.5, lineColor: LINE, lineWidth: 0.2, halign: "center", cellPadding: 1.4 },
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], fontStyle: "bold" },
    margin: { left: 10, right: 10 },
  });
  y = ((doc as any).lastAutoTable.finalY || y) + 4;
  doc.setFont("helvetica", "italic"); doc.setFontSize(8);
  doc.text(`Tax Amount (in words) : INR ${money(totalGst)} Only`, 12, y);
  y += 8;

  // Bank + Declaration block — taller box, IFSC/Branch on separate lines
  const bankH = 46;
  doc.setDrawColor(...LINE); doc.rect(10, y, 130, bankH);
  doc.setFont("helvetica", "bold"); doc.setFontSize(8.5); doc.text("Company's Bank Details", 12, y + 5);
  doc.setFont("helvetica", "normal"); doc.setFontSize(7.8);
  let by = y + 10;
  doc.text(`A/c Holder : ${text(s.company_name, COMPANY.name)}`, 12, by); by += 4.5;
  doc.text(`Bank Name  : ${text(s.bank_name)}`, 12, by); by += 4.5;
  doc.text(`A/c No.    : ${text(s.bank_account)}`, 12, by); by += 4.5;
  doc.text(`Branch     : ${text(s.bank_branch)}`, 12, by, { maxWidth: 126 }); by += 4.5;
  doc.text(`IFSC       : ${text(s.bank_ifsc)}`, 12, by); by += 4.5;
  if (s.swift_code) { doc.text(`SWIFT      : ${s.swift_code}`, 12, by); by += 4.5; }

  doc.rect(140, y, 60, bankH);
  doc.setFont("helvetica", "bold"); doc.text("Company's PAN :", 142, y + 5);
  doc.setFont("helvetica", "normal"); doc.text(text(s.pan), 175, y + 5);
  doc.setFont("helvetica", "bold"); doc.text("Declaration", 142, y + 12);
  doc.setFont("helvetica", "normal"); doc.setFontSize(7);
  doc.text(text(s.declaration), 142, y + 16, { maxWidth: 56 });
  doc.setFontSize(7); doc.setFont("helvetica", "italic");
  doc.text(text(s.computer_generated, "This is a Computer Generated Invoice"), 142, y + bankH - 5, { maxWidth: 56 });

  const sigY = y + bankH + 6;
  doc.setFont("helvetica", "bold"); doc.setFontSize(8);
  doc.text(`for ${text(s.company_name, COMPANY.name)}`, 198, sigY, { align: "right" });
  doc.setFont("helvetica", "normal"); doc.text("Authorised Signatory", 198, sigY + 12, { align: "right" });
  footer(doc);
  doc.save(`Invoice-Summary-${inv.invoice_no}.pdf`);
}

export function exportInvoiceExcel(inv: any, client: any, items: any[]) {
  const rows = items.map((it, i) => {
    const s = it.shipments || it;
    const amount = Number(it.amount ?? s.total_amount ?? 0);
    const gst = Number(s.gst ?? 0);
    return `<tr><td>${i + 1}</td><td>${shortDate(s.booking_date || it.booking_date)}</td><td>${text(s.awb_number || it.awb_number)}</td><td>${text(s.sender_city || "New Delhi")}</td><td>${text(s.receiver_city)}</td><td>${text(s.chargeable_weight || 0)}</td><td>${text(s.transport_mode || "SELF")}</td><td>${text(s.service_type || "Courier")}</td><td>${money(amount - gst)}</td><td>${money(gst)}</td><td>${money(amount)}</td></tr>`;
  }).join("");
  const html = `<html><head><meta charset="UTF-8"><style>table{border-collapse:collapse;font-family:Arial;font-size:12px}td,th{border:1px solid #000;padding:5px}h2,h3{text-align:center;margin:4px}</style></head><body><h2>${COMPANY.name}</h2><h3>TAX INVOICE</h3><p><b>GSTIN:</b> ${COMPANY.gstin} | <b>Phone:</b> ${COMPANY.phone}</p><p><b>Bill To:</b> ${text(client?.client_code)} - ${text(client?.name)}<br/>${text(client?.address)}<br/>GST: ${text(client?.gstin)}</p><p><b>Invoice:</b> ${text(inv.invoice_no)} | <b>Date:</b> ${shortDate(inv.invoice_date)} | <b>Period:</b> ${shortDate(inv.period_from)} to ${shortDate(inv.period_to)}</p><table><thead><tr><th>S/N</th><th>BKG DATE</th><th>C. NO</th><th>ORIGIN</th><th>DESTINATION</th><th>CHRG WT</th><th>CARRIER</th><th>SERVICES</th><th>FRT</th><th>GST</th><th>AMOUNT</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><th colspan="8">Total</th><th>${money(inv.subtotal)}</th><th>${money(inv.gst)}</th><th>${money(inv.total)}</th></tr></tfoot></table></body></html>`;
  const blob = new Blob([html], { type: "application/vnd.ms-excel" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Invoice-${inv.invoice_no}.xls`;
  a.click();
  URL.revokeObjectURL(url);
}

export function printLedger(client: any, entries: any[]) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  plainHeader(doc, "CLIENT LEDGER", `Client: ${text(client?.client_code)} - ${text(client?.name)} | Printed: ${new Date().toLocaleString()}`);
  let bal = 0;
  autoTable(doc, {
    startY: 60,
    head: [["Date", "Description", "Reference", "Debit", "Credit", "Balance"]],
    body: entries.map((e) => {
      bal += Number(e.debit) - Number(e.credit);
      return [shortDate(e.entry_date), text(e.description), text(e.reference), Number(e.debit) ? money(e.debit) : "-", Number(e.credit) ? money(e.credit) : "-", money(bal)];
    }),
    styles: { fontSize: 8.5, lineColor: LINE, lineWidth: 0.15, cellPadding: 1.8 },
    headStyles: { fillColor: BLUE, textColor: [255, 255, 255], halign: "center" },
    columnStyles: { 3: { halign: "right" }, 4: { halign: "right" }, 5: { halign: "right", fontStyle: "bold" } },
    margin: { left: 12, right: 12 },
  });
  const y = ((doc as any).lastAutoTable.finalY || 70) + 8;
  doc.setFont("helvetica", "bold"); doc.setFontSize(10);
  doc.text(`Closing Balance: Rs. ${money(bal)}`, 198, y, { align: "right" });
  doc.setFont("helvetica", "normal"); doc.setFontSize(8);
  doc.text("Payment Received By: ____________________     Customer Signature: ____________________", 12, y + 18);
  footer(doc);
  doc.save(`Ledger-${client?.client_code || "client"}.pdf`);
}
