import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import logoUrl from "@/assets/logo.png";
import { COMPANY } from "./awbLabel";

const BLUE: [number, number, number] = [44, 112, 184];
const LIGHT: [number, number, number] = [232, 241, 250];
const CYAN: [number, number, number] = [120, 207, 216];

export interface QuotationData {
  date: string;
  companyName: string;
  address: string;
  kindAttn: string;
  gstin: string;
  pan: string;
  stateName: string;
  placeOfSupply: string;
  intro: string;
  serviceOfferings: string[];
  tat: string[];
  commercialTerms: string[];
  paymentTerms: string[];
  liability: string;
  claims: string;
  onboarding: string;
  // Rate tables
  airCities: { city: string; rate: number }[];
  airMinWeight: number;
  airRestRate: number;
  surfaceZones: { region: string; locations: string; rate: number; tat: string }[];
  surfaceMinWeight: number;
  metro: { weight: string; sameDay: string; overnight: string }[];
  metroMinWeight: number;
  airlinesDirect: number;
  metroCities: string;
  localCities: { city: string; rate: number }[];
  localPriorityRates: { city: string; rate: number }[];
  // Toggleable charges
  insuranceEnabled: boolean;
  insurancePct: number;
  insuranceMin: number;
  fovEnabled: boolean;
  fovPct: number;
  fovMin: number;
  fuelPct: number;
  odaPerKg: number;
  odaMin: number;
  volAirDiv: number;
  volSurfaceDiv: number;
  gstPct: number;
  // Custom terms
  extraTerms: string[];
}

function header(doc: jsPDF) {
  doc.setDrawColor(0); doc.setLineWidth(0.3);
  try { doc.addImage(logoUrl, "PNG", 14, 10, 20, 14); } catch {}
  doc.setFont("helvetica", "bold"); doc.setTextColor(...BLUE); doc.setFontSize(15);
  doc.text(COMPANY.name, 105, 16, { align: "center" });
  doc.setTextColor(0); doc.setFontSize(7.5); doc.setFont("helvetica", "normal");
  doc.text(`Branch: ${COMPANY.branch}`, 105, 21, { align: "center", maxWidth: 150 });
  doc.setFont("helvetica", "italic"); doc.setFontSize(8.5); doc.setTextColor(...BLUE);
  doc.text("Worldwide Freight & Logistics Solutions", 105, 27, { align: "center" });
  doc.setTextColor(0); doc.setDrawColor(...BLUE); doc.setLineWidth(0.6);
  doc.line(14, 30, 196, 30);
}

function footer(doc: jsPDF) {
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setDrawColor(...BLUE); doc.setLineWidth(0.5);
    doc.line(14, 280, 196, 280);
    doc.setFont("helvetica", "bold"); doc.setFontSize(10); doc.setTextColor(...BLUE);
    doc.text(COMPANY.name, 105, 285, { align: "center" });
    doc.setFont("helvetica", "normal"); doc.setFontSize(7); doc.setTextColor(80);
    doc.text(`Regd. Office: ${COMPANY.ho}`, 105, 289, { align: "center", maxWidth: 180 });
    doc.text(`Ph. ${COMPANY.phone} | ${COMPANY.email} | ${COMPANY.web} | GSTIN: ${COMPANY.gstin}`, 105, 293, { align: "center", maxWidth: 180 });
  }
}

export function generateQuotationPDF(q: QuotationData) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  // ----- PAGE 1 -----
  header(doc);
  let y = 38;
  doc.setFont("helvetica", "normal"); doc.setFontSize(9.5);
  doc.text(`Date: ${q.date}`, 14, y); y += 5;
  doc.text(`Company Name: ${q.companyName}`, 14, y); y += 5;
  const addr = doc.splitTextToSize(`Address: ${q.address}`, 182);
  doc.text(addr, 14, y); y += addr.length * 4.5;
  doc.text(`Kind Attn: ${q.kindAttn}`, 14, y); y += 6;

  autoTable(doc, {
    startY: y, theme: "grid", styles: { fontSize: 8.5, cellPadding: 1.5 },
    body: [
      ["GSTIN/UIN", q.gstin, "PAN/IT NO", q.pan],
      ["State Name", q.stateName, "Place of Supply", q.placeOfSupply],
    ],
    columnStyles: { 0: { fontStyle: "bold", fillColor: LIGHT }, 2: { fontStyle: "bold", fillColor: LIGHT } },
  });
  y = (doc as any).lastAutoTable.finalY + 5;

  doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor(...BLUE);
  doc.text("Proposal: B2B Courier and Cargo Services & Rates", 14, y); y += 5;
  doc.setTextColor(0); doc.setFont("helvetica", "normal"); doc.setFontSize(9);
  doc.text("Dear Sir / Mam,", 14, y); y += 5;
  const intro = doc.splitTextToSize(q.intro, 182);
  doc.text(intro, 14, y); y += intro.length * 4 + 3;
  doc.setFont("helvetica", "bold"); doc.text("Our main inter-city service offerings are:", 14, y); y += 5;
  doc.setFont("helvetica", "normal");
  q.serviceOfferings.forEach(s => {
    const lines = doc.splitTextToSize(`•  ${s}`, 178);
    doc.text(lines, 16, y); y += lines.length * 4;
  });

  // ----- PAGE 2 -----
  doc.addPage(); header(doc); y = 38;
  const block = (title: string, lines: string[]) => {
    doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor(...BLUE);
    doc.text(title, 14, y); y += 5;
    doc.setTextColor(0); doc.setFont("helvetica", "normal"); doc.setFontSize(9);
    lines.forEach(l => {
      const w = doc.splitTextToSize(l.startsWith("•") ? l : `•  ${l}`, 178);
      doc.text(w, 16, y); y += w.length * 4;
    });
    y += 3;
  };
  block("Transit Time (TAT):", q.tat);
  block("Commercial Terms & Validity:", q.commercialTerms);
  block("Payment Terms:", q.paymentTerms);

  doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor(...BLUE);
  doc.text("Liability & Limitation of Responsibility:", 14, y); y += 5;
  doc.setTextColor(0); doc.setFont("helvetica", "normal"); doc.setFontSize(9);
  const lib = doc.splitTextToSize(q.liability, 182); doc.text(lib, 14, y); y += lib.length * 4 + 3;

  doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor(...BLUE);
  doc.text("Shipment Handling & Claims Policy:", 14, y); y += 5;
  doc.setTextColor(0); doc.setFont("helvetica", "normal"); doc.setFontSize(9);
  const cl = doc.splitTextToSize(q.claims, 182); doc.text(cl, 14, y); y += cl.length * 4 + 3;

  doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor(...BLUE);
  doc.text("Onboarding & Compliance:", 14, y); y += 5;
  doc.setTextColor(0); doc.setFont("helvetica", "normal"); doc.setFontSize(9);
  const ob = doc.splitTextToSize(q.onboarding, 182); doc.text(ob, 14, y); y += ob.length * 4;

  // ----- PAGE 3: RATES -----
  doc.addPage(); header(doc); y = 36;
  doc.setFont("helvetica", "bold"); doc.setFontSize(11); doc.setTextColor(...BLUE);
  doc.text("AIR B2B RATE STRUCTURE", 105, y, { align: "center" }); y += 5;
  doc.setFontSize(8.5); doc.setTextColor(0); doc.setFont("helvetica", "italic");
  doc.text("Standard Service: Next Business Day (24 - 48 Hours Delivery)", 105, y, { align: "center" }); y += 4;

  // Split AIR cities into chunks of 7
  const chunks: typeof q.airCities[] = [];
  for (let i = 0; i < q.airCities.length; i += 7) chunks.push(q.airCities.slice(i, i + 7));
  chunks.forEach(ch => {
    autoTable(doc, {
      startY: y, theme: "grid", styles: { fontSize: 8.5, halign: "center", cellPadding: 1.5 },
      head: [["NON DOC / 0.5 To 01 KG", ...ch.map(c => c.city)]],
      body: [["Rate (Rs/Kg)", ...ch.map(c => String(c.rate))]],
      headStyles: { fillColor: BLUE, textColor: 255 },
    });
    y = (doc as any).lastAutoTable.finalY + 2;
  });
  doc.setFont("helvetica", "bold"); doc.setFontSize(9);
  doc.text(`Minimum Chargeable Weight: ${q.airMinWeight} kg.   Rest of India: Rs ${q.airRestRate} per Kg.`, 14, y + 3);
  y += 8;

  doc.setFont("helvetica", "bold"); doc.setFontSize(11); doc.setTextColor(...BLUE);
  doc.text("DOMESTIC SURFACE FREIGHT CHARGES", 105, y, { align: "center" }); y += 5;
  autoTable(doc, {
    startY: y, theme: "grid", styles: { fontSize: 8.5, cellPadding: 1.5 },
    head: [["Region", "Locations", "Rate", "TAT"]],
    body: q.surfaceZones.map(z => [z.region, z.locations, String(z.rate), z.tat]),
    headStyles: { fillColor: BLUE, textColor: 255 },
  });
  y = (doc as any).lastAutoTable.finalY + 2;
  doc.setFont("helvetica", "bold"); doc.setTextColor(0); doc.setFontSize(9);
  doc.text(`Minimum chargeable weight: ${q.surfaceMinWeight} kg.`, 14, y + 3); y += 7;

  doc.setFont("helvetica", "bold"); doc.setFontSize(11); doc.setTextColor(...BLUE);
  doc.text("TIME-CRITICAL METRO DELIVERY", 105, y, { align: "center" }); y += 5;
  autoTable(doc, {
    startY: y, theme: "grid", styles: { fontSize: 8.5, halign: "center", cellPadding: 1.5 },
    head: [["WEIGHT", "SAME DAY DELIVERY", "OVERNIGHT DELIVERY"]],
    body: q.metro.map(m => [m.weight, m.sameDay, m.overnight]),
    headStyles: { fillColor: BLUE, textColor: 255 },
  });
  y = (doc as any).lastAutoTable.finalY + 2;
  doc.setTextColor(0); doc.setFont("helvetica", "bold"); doc.setFontSize(9);
  doc.text(`Minimum Chargeable Weight: ${q.metroMinWeight} KG.`, 14, y + 3); y += 7;
  doc.setFont("helvetica", "bold").text(`AIRLINES DIRECT CONSIGNMENT CHARGES @ Rs ${q.airlinesDirect}/- PER CONSIGNMENT.`, 14, y); y += 4;
  doc.setFont("helvetica", "normal").text(`METRO CITIES: ${q.metroCities}`, 14, y);

  // ----- PAGE 4: LOCAL + TERMS -----
  doc.addPage(); header(doc); y = 36;
  doc.setFont("helvetica", "bold"); doc.setFontSize(11); doc.setTextColor(...BLUE);
  doc.text("LOCAL DELIVERY SOLUTIONS (Standard & Priority)", 105, y, { align: "center" }); y += 5;

  autoTable(doc, {
    startY: y, theme: "grid", styles: { fontSize: 8.5, halign: "center", cellPadding: 1.5 },
    head: [["Weight Slab", "Zone", ...q.localCities.map(c => c.city)]],
    body: [
      ["0.5 GMS To 05 KG (Standard)", "DELHI / NCR", ...q.localCities.map(c => String(c.rate))],
      ["Same Day / Overnight (Priority)", "DELHI / NCR", ...q.localPriorityRates.map(c => String(c.rate))],
    ],
    headStyles: { fillColor: BLUE, textColor: 255 },
  });
  y = (doc as any).lastAutoTable.finalY + 6;

  doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor(...BLUE);
  doc.text("Terms and Conditions:", 14, y); y += 5;
  doc.setTextColor(0); doc.setFont("helvetica", "normal"); doc.setFontSize(9);
  const tc: string[] = [];
  if (q.insuranceEnabled) tc.push(`Insurance ${q.insurancePct}% or Rs. ${q.insuranceMin} whichever is higher on declared value. (If insured through "${COMPANY.name}")`);
  if (q.fovEnabled) tc.push(`FOV ${q.fovPct}% or Rs. ${q.fovMin} whichever is higher (If Consignment is Insured by the Consignor).`);
  tc.push(`${q.fuelPct}% Fuel Charge is Applicable.`);
  tc.push(`ODA charges will be applicable outside municipal limit - Rs. ${q.odaPerKg}/kg or Rs. ${q.odaMin} whichever is higher.`);
  tc.push("Credit Terms: 15 Days Billing Cycle.");
  tc.push("Payment Terms: within 07 Days. (After submission of bills)");
  tc.push(`Volumetric weight charge - Calculated by (L x B x H) / ${q.volAirDiv} (BY AIR)`);
  tc.push(`Volumetric weight charge - Calculated by (L x B x H) / ${q.volSurfaceDiv} (BY SURFACE)`);
  tc.push("TAT will be calculated excluding of booking date.");
  tc.push(`Additional ${q.gstPct}% of GST is applicable as per govt. norms.`);
  tc.push(`Payment will be made in Favour of "${COMPANY.name}"`);
  q.extraTerms.filter(t => t.trim()).forEach(t => tc.push(t));
  tc.forEach((t, i) => {
    const lines = doc.splitTextToSize(`${i + 1}. ${t}`, 178);
    doc.text(lines, 16, y); y += lines.length * 4 + 0.5;
  });

  y += 8;
  doc.setFont("helvetica", "bold").setFontSize(9);
  doc.text("For FAHAD GLOBAL LOGISTICS:", 14, y);
  doc.text("AGREEMENT SIGNED BY:", 120, y);
  doc.setFont("helvetica", "normal").setFontSize(8);
  doc.text("(Sign & Stamp)", 14, y + 14);
  doc.text("(Sign & Stamp)", 120, y + 14);

  footer(doc);
  doc.save(`Quotation_${q.companyName.replace(/\s+/g, "_")}_${Date.now()}.pdf`);
}

// Helper: compute chargeable weight (max of actual vs volumetric) and freight
export function computeFreight(opts: {
  mode: "AIR" | "SURFACE" | "SAMEDAY" | "OVERNIGHT" | "LOCAL";
  actualKg: number; l: number; b: number; h: number;
  ratePerKg: number; minWeight: number; volDiv: number;
}) {
  const vol = (opts.l * opts.b * opts.h) / (opts.volDiv || 5000);
  const chargeable = Math.max(opts.actualKg, vol, opts.minWeight);
  const freight = chargeable * opts.ratePerKg;
  return { volumetric: +vol.toFixed(2), chargeable: +chargeable.toFixed(2), freight: +freight.toFixed(2) };
}

export const DEFAULT_QUOTATION: QuotationData = {
  date: new Date().toLocaleDateString("en-GB"),
  companyName: "",
  address: "",
  kindAttn: "",
  gstin: "",
  pan: "",
  stateName: "",
  placeOfSupply: "",
  intro: "Thank you for your interest in Fahad Global Logistics. We sincerely appreciate the opportunity to engage with your esteemed organization. With reference to our recent discussion, we are pleased to submit our formal proposal for Domestic Courier and Cargo Services. Fahad Global Logistics is a professionally driven express logistics organization specializing in time-critical, secure, and efficient door-to-door delivery solutions across India.",
  serviceOfferings: [
    "Same Day Courier Service – Time-bound pickup and delivery within the same business day",
    "Overnight Express Service – Late evening pickup with assured next-day morning delivery",
    "Hand Carry (On-Board Courier) – Dedicated onboard handling for urgent, high-value consignments",
    "Customized Logistics Solutions – Flexible and scalable solutions tailored to specific business needs",
    "Sunday & Holiday Operations – Continuous service availability, 365 days a year",
    "Standard Courier Services – Reliable, day-definite deliveries across all serviceable locations in India.",
  ],
  tat: ["Surface Mode: 2-7 business days, depending on destination", "Air Mode: 24-48 hours, depending on destination"],
  commercialTerms: [
    "The proposed commercial structure is based on volume-driven business and mutually agreed service scope",
    "Validity Period: 01 May 2026 to 31 March 2027",
    "Rates are subject to annual revision effective 1st April, with prior written intimation",
  ],
  paymentTerms: [
    "Billing Cycle: 15 days",
    "Payment Terms: Payment to be made within 07 days from the date of invoice",
    "All invoices shall be paid strictly within the agreed period.",
    "Fahad Global Logistics reserves the unconditional right to suspend services and hold all shipments until full and final payment is received.",
  ],
  liability: "Fahad Global Logistics shall not be held liable for any indirect, incidental, or consequential damages, including but not limited to loss of business, revenue, or profits arising from delays in pickup, transportation, or delivery of shipments. In the case of non-insured shipments, the maximum liability shall be limited to Rs. 2,000 or the declared invoice value, whichever is lower.",
  claims: "All consignments are accepted in sealed and properly packed condition and are delivered in the same condition to the consignee. Any claim for damage or loss shall not be entertained in the absence of specific remarks recorded at the time of delivery on the POD or DRS.",
  onboarding: "To initiate operations, the client is required to complete the onboarding process, which includes execution of a service agreement, submission of necessary documentation, and registration within our operational system for seamless coordination.",
  airCities: [
    { city: "Mumbai", rate: 90 }, { city: "Ahmedabad", rate: 90 }, { city: "Bangalore", rate: 95 },
    { city: "Hyderabad", rate: 95 }, { city: "Pune", rate: 95 }, { city: "Kolkata", rate: 95 },
    { city: "Chennai", rate: 95 }, { city: "Bhubaneswar", rate: 100 }, { city: "Patna", rate: 110 },
    { city: "Nagpur", rate: 110 }, { city: "Guwahati", rate: 130 }, { city: "Goa", rate: 130 },
    { city: "Cochin", rate: 110 }, { city: "Ranchi", rate: 130 },
  ],
  airMinWeight: 5, airRestRate: 150,
  surfaceZones: [
    { region: "North", locations: "Lucknow, Kanpur, Varanasi, Dehradun, Ludhiana, Mohali, Karnal, Jalandhar, Amritsar, Patiala, Jaipur", rate: 30, tat: "2 Days" },
    { region: "East", locations: "Kolkata, Ranchi, Bhubaneshwar, Patna, Orissa, Ahmedabad", rate: 40, tat: "4-5 Days" },
    { region: "West", locations: "Vapi, Surat, Mumbai, Pune, Bhiwandi, Hyderabad", rate: 40, tat: "4-5 Days" },
    { region: "South", locations: "Chennai, Ernakulam, Cochin, Kozhikode, Secunderabad, Vishakhapatnam", rate: 45, tat: "4-5 Days" },
    { region: "Central", locations: "Indore, Bhopal, Raipur, Nagpur", rate: 45, tat: "4-5 Days" },
    { region: "North-East", locations: "Guwahati, Manipur, Nagaland, Meghalaya, Arunachal Pradesh, Mizoram, Tripura", rate: 45, tat: "5-6 Days" },
  ],
  surfaceMinWeight: 20,
  metro: [
    { weight: "Up to 500 GMS TO 15 KG", sameDay: "Rs. 350 + 2500", overnight: "Rs. 300 + 2500" },
    { weight: "16 KG TO 30 KG", sameDay: "Rs. 250", overnight: "Rs. 250" },
    { weight: "31 KG TO 50 KG", sameDay: "Rs. 250", overnight: "Rs. 200" },
    { weight: "51 KG TO 100 KG & Above", sameDay: "Rs. 200", overnight: "Rs. 150" },
  ],
  metroMinWeight: 5,
  airlinesDirect: 2500,
  metroCities: "BOM / BLR / DEL / PNQ / AMD / HYD / MAA / JAI / CCU",
  localCities: [
    { city: "Delhi", rate: 50 }, { city: "Noida", rate: 60 }, { city: "Faridabad", rate: 60 },
    { city: "Gurgaon", rate: 60 }, { city: "Ghaziabad", rate: 60 },
  ],
  localPriorityRates: [
    { city: "Delhi", rate: 200 }, { city: "Noida", rate: 250 }, { city: "Faridabad", rate: 250 },
    { city: "Gurgaon", rate: 250 }, { city: "Ghaziabad", rate: 250 },
  ],
  insuranceEnabled: true, insurancePct: 2.0, insuranceMin: 200,
  fovEnabled: true, fovPct: 0.2, fovMin: 100,
  fuelPct: 40, odaPerKg: 3, odaMin: 750,
  volAirDiv: 5000, volSurfaceDiv: 4000, gstPct: 18,
  extraTerms: [],
};