// Auto-billing logic per specification.
// Service types: AIR | SURFACE | SAMEDAY | OVERNIGHT | LOCAL

export type ServiceKind = "AIR" | "SURFACE" | "SAMEDAY" | "OVERNIGHT" | "LOCAL";

export function detectService(label: string): ServiceKind {
  const s = (label || "").toLowerCase();
  if (s.includes("local")) return "LOCAL";
  if (s.includes("same")) return "SAMEDAY";
  if (s.includes("overnight") || s.includes("next business")) return "OVERNIGHT";
  if (s.includes("surface") || s.includes("road") || s.includes("train")) return "SURFACE";
  return "AIR";
}

// Default city rate tables (admin-editable via CMS later)
export const AIR_RATES: Record<string, number> = {
  mumbai: 90, ahmedabad: 90, bangalore: 95, bengaluru: 95, hyderabad: 95, pune: 95,
  kolkata: 95, chennai: 95, bhubaneswar: 100, patna: 110, nagpur: 110,
  guwahati: 130, goa: 130, cochin: 110, kochi: 110, ranchi: 130,
};
export const AIR_DEFAULT = 140;

export const SURFACE_ZONE_RATES: Record<string, number> = {
  NORTH: 30, EAST: 40, WEST: 40, SOUTH: 45, CENTRAL: 45, "NORTH EAST": 45,
};
export const SURFACE_DEFAULT = 50;

export const LOCAL_RATES: Record<string, number> = {
  delhi: 50, noida: 60, faridabad: 60, gurgaon: 60, gurugram: 60, ghaziabad: 60,
};

// State → surface zone map (subset; unknown → REST OF INDIA)
const STATE_ZONE: Record<string, keyof typeof SURFACE_ZONE_RATES> = {
  "delhi": "NORTH", "haryana": "NORTH", "punjab": "NORTH", "uttar pradesh": "NORTH",
  "uttarakhand": "NORTH", "himachal pradesh": "NORTH", "jammu and kashmir": "NORTH",
  "rajasthan": "NORTH", "chandigarh": "NORTH",
  "west bengal": "EAST", "bihar": "EAST", "jharkhand": "EAST", "odisha": "EAST",
  "maharashtra": "WEST", "gujarat": "WEST", "goa": "WEST",
  "karnataka": "SOUTH", "kerala": "SOUTH", "tamil nadu": "SOUTH",
  "andhra pradesh": "SOUTH", "telangana": "SOUTH", "puducherry": "SOUTH",
  "madhya pradesh": "CENTRAL", "chhattisgarh": "CENTRAL",
  "assam": "NORTH EAST", "meghalaya": "NORTH EAST", "manipur": "NORTH EAST",
  "tripura": "NORTH EAST", "mizoram": "NORTH EAST", "nagaland": "NORTH EAST",
  "arunachal pradesh": "NORTH EAST", "sikkim": "NORTH EAST",
};

export function surfaceZoneForState(state?: string): string {
  if (!state) return "REST OF INDIA";
  return STATE_ZONE[state.toLowerCase().trim()] || "REST OF INDIA";
}

export interface BillingInput {
  service: ServiceKind;
  city: string;
  state?: string;
  actualWeight: number;
  lengthCm: number; widthCm: number; heightCm: number;
  declaredValue: number;
  odaApplied: boolean;
  insuranceApplied: boolean;
  otherCharges: number;
  fuelPct?: number;      // default 40
  gstPct?: number;       // default 18
  rateOverride?: number; // manual rate override (per kg)
}

export interface BillingOutput {
  volumetricWeight: number;
  billableWeight: number;
  rate: number;
  zone: string;
  freight: number;
  fov: number;
  insurance: number;
  oda: number;
  other: number;
  total: number;       // Freight + FOV + Insurance + ODA + Other
  fuelPct: number;
  fuel: number;        // = Total * fuelPct%
  subTotal: number;    // Total + Fuel
  gstPct: number;
  gst: number;
  grandTotal: number;
}

export function autoBill(i: BillingInput): BillingOutput {
  const city = (i.city || "").toLowerCase().trim();
  const divisor = i.service === "SURFACE" ? 4000 : 5000;
  const vol = +(((i.lengthCm * i.widthCm * i.heightCm) / divisor) || 0).toFixed(3);
  let bill = Math.max(Number(i.actualWeight || 0), vol);
  if (i.service === "AIR") bill = Math.max(bill, 5);
  if (i.service === "SURFACE") bill = Math.max(bill, 20);

  let rate = i.rateOverride && i.rateOverride > 0 ? i.rateOverride : 0;
  let zone = "";
  let freight = 0;

  switch (i.service) {
    case "AIR": {
      if (!rate) rate = AIR_RATES[city] ?? AIR_DEFAULT;
      zone = AIR_RATES[city] ? city.toUpperCase() : "REST OF INDIA";
      freight = bill * rate;
      break;
    }
    case "SURFACE": {
      const z = surfaceZoneForState(i.state) as keyof typeof SURFACE_ZONE_RATES;
      zone = z as string;
      if (!rate) rate = SURFACE_ZONE_RATES[z as string] ?? SURFACE_DEFAULT;
      freight = bill * rate;
      break;
    }
    case "SAMEDAY": {
      zone = "SAMEDAY";
      const w = bill;
      if (w <= 15) freight = w * 330 + 2500;
      else if (w <= 30) freight = w * 250;
      else if (w <= 50) freight = w * 250;
      else freight = w * 200;
      rate = w ? +(freight / w).toFixed(2) : 0;
      break;
    }
    case "OVERNIGHT": {
      zone = "OVERNIGHT";
      const w = bill;
      if (w <= 15) freight = w * 290 + 2500;
      else if (w <= 30) freight = w * 250;
      else if (w <= 50) freight = w * 200;
      else freight = w * 150;
      rate = w ? +(freight / w).toFixed(2) : 0;
      break;
    }
    case "LOCAL": {
      if (!rate) rate = LOCAL_RATES[city] ?? 80;
      zone = LOCAL_RATES[city] ? city.toUpperCase() : "LOCAL";
      freight = bill * rate;
      break;
    }
  }

  const dv = Number(i.declaredValue || 0);
  const fov = Math.max(dv * 0.002, 100);
  const insurance = i.insuranceApplied ? Math.max(dv * 0.02, 200) : 0;
  const oda = i.odaApplied ? Math.max(bill * 3, 750) : 0;
  const other = Number(i.otherCharges || 0);
  const total = freight + fov + insurance + oda + other;

  const fuelPct = i.fuelPct ?? 40;
  const fuel = total * (fuelPct / 100);
  const subTotal = total + fuel;
  const gstPct = i.gstPct ?? 18;
  const gst = subTotal * (gstPct / 100);
  const grandTotal = subTotal + gst;

  return {
    volumetricWeight: vol,
    billableWeight: +bill.toFixed(3),
    rate, zone,
    freight: +freight.toFixed(2),
    fov: +fov.toFixed(2),
    insurance: +insurance.toFixed(2),
    oda: +oda.toFixed(2),
    other: +other.toFixed(2),
    total: +total.toFixed(2),
    fuelPct,
    fuel: +fuel.toFixed(2),
    subTotal: +subTotal.toFixed(2),
    gstPct,
    gst: +gst.toFixed(2),
    grandTotal: +grandTotal.toFixed(2),
  };
}